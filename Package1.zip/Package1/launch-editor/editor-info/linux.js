module.exports = {
  atom: 'atom',
  Brackets: 'brackets',
  'code-insiders': 'code-insiders',
  code: 'code',
  vscodium: 'vscodium',
  codium: 'codium',
  emacs: 'emacs',
  gvim: 'gvim',
  'idea.sh': 'idea',
  'phpstorm.sh': 'phpstorm',
  'pycharm.sh': 'pycharm',
  'rubymine.sh': 'rubymine',
  sublime_text: 'subl',
  vim: 'vim',
  'webstorm.sh': 'webstorm',
  'goland.sh': 'goland',
  'rider.sh': 'rider'
}
