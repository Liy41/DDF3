# [Less.js](http://lesscss.org)

> The **dynamic** stylesheet language. [http://lesscss.org](http://lesscss.org).

This is the JavaScript, official, stable version of Less.


## Getting Started

Add Less.js to your project:
```sh
npm install less
```
