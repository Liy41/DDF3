var less = {
    strictUnits: true,
    math: 'strict-legacy',
    logLevel: 4,
    javascriptEnabled: true
};
