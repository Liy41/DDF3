<template> 
<div class="customer-dialog">
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="cancel"
    width="52.5%"
    :destroy-on-close="true"
    :close-on-click-modal="false"
  >
    <el-form
      ref="form"
      class="customer-form"
      :model="form"
      label-width="97px"
      :inline="true"
      :rules="rules"
      label-suffix=":"
    >
      <el-form-item label="客户名称" prop="customerName" class="form-style">
        <el-input v-model.trim="form.customerName" placeholder="请输入" maxlength="30" size="small" class="input-style" />
      </el-form-item>
      <el-form-item label="客户代码" prop="customerCode" class="form-style">
        <el-input v-model.trim="form.customerCode" placeholder="请输入" maxlength="30" size="small" class="input-style" />
      </el-form-item>
      <el-form-item label="账期" prop="payment" class="form-style">
        <el-input v-model.trim="form.payment" placeholder="请输入" maxlength="30" size="small" class="input-style" />
      </el-form-item>

      <el-form-item label="结算币种" prop="" class="form-style">
        <el-select v-model="form.currency" placeholder="请选择" size="small">
          <el-option
            v-for="item in currencyTypeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="所属地区" prop="" class="form-style">
        <el-select v-model="form.currency" placeholder="请选择" size="small">
          <el-option
            v-for="item in currencyTypeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="开户行" prop="" class="address form-style" style="width:100%">
        <el-input v-model.trim="form.phone" placeholder="请输入" maxlength="50" size="small" style="width:100%" />
      </el-form-item>

      <el-form-item label="账号" prop="" class="address form-style" style="width:100%">
        <el-input v-model.trim="form.phone" placeholder="请输入" maxlength="50" size="small" style="width:100%" />
      </el-form-item>

      <el-form-item label="税号" prop="" class="address form-style" style="width:100%">
        <el-input v-model.trim="form.phone" placeholder="请输入" maxlength="50" size="small" style="width:100%" />
      </el-form-item>

      <!-- 特殊表单 -->
      <div v-for="(item, index) in form.dynamicItem" :key="index" style="height: 51px">
        <el-form-item label="联系人" class="form-style">
          <el-input v-model="item.name" size="small" class="special-style" />
        </el-form-item>
        <el-form-item
          label="联系电话"
          class="form-style"
          :prop="'dynamicItem.' + index + '.phone'"
          :rules="[
            {required: false, message: '手机号不能为空', trigger: 'blur'},
            { pattern: /^1[34578]\d{9}$/, message: '目前只支持中国大陆的手机号码' }
          ]"
        >
          <el-input v-model="item.phone" size="small" class="special-style" />
        </el-form-item>
        <el-form-item label="收货地址" class="form-style">
          <el-input v-model="item.address" size="small" class="special-style" />
        </el-form-item>
        <el-form-item>
          <el-button v-if="index+1 == form.dynamicItem.length" type="primary" size="mini" @click="addItem(form.dynamicItem.length)">+</el-button>
          <el-button v-if="index !== 0" type="danger" size="mini" @click="deleteItem(item, index)">-</el-button>
        </el-form-item>
      </div>
      <!-- *** -->
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="cancel">取 消</el-button>
      <el-button size="small" type="primary" @click="handleSave('form')">保 存</el-button>
    </div>
  </el-dialog>
</div>
</template>
 <script>
 export default {
data(){
	return{
		form: {
        dynamicItem: [
        //默认显示一条
          {
            name: '',
            phone: '',
            address: ''
          }
        ]
      }
	};
}
 }}

methods:{
	//新增方法
	addItem(length) {
      if (length >= 10) {
        this.$message({
          type: 'warning',
          message: '最多可新增10条!'
        })
      } else {
        this.form.dynamicItem.push({
          name: '',
          phone: '',
          address: ''
        })
      }
    },
    //删除方法
    deleteItem(item, index) {
      this.form.dynamicItem.splice(index, 1)
    },
}
