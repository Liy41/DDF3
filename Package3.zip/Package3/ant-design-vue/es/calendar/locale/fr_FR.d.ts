import frFR from '../../date-picker/locale/fr_FR';
export default frFR;
