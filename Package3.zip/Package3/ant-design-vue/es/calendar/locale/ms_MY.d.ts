import msMY from '../../date-picker/locale/ms_MY';
export default msMY;
