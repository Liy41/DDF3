import esES from '../../date-picker/locale/es_ES';
export default esES;
