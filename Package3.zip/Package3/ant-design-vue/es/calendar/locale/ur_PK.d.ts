import urPK from '../../date-picker/locale/ur_PK';
export default urPK;
