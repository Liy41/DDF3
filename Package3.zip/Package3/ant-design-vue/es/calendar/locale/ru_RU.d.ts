import ruRU from '../../date-picker/locale/ru_RU';
export default ruRU;
