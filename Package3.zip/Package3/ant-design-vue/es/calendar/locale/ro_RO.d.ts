import roRO from '../../date-picker/locale/ro_RO';
export default roRO;
