import nbNO from '../../date-picker/locale/nb_NO';
export default nbNO;
