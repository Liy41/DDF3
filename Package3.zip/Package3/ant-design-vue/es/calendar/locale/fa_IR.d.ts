import faIR from '../../date-picker/locale/fa_IR';
export default faIR;
