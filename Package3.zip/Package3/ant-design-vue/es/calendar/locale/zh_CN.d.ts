import zhCN from '../../date-picker/locale/zh_CN';
export default zhCN;
