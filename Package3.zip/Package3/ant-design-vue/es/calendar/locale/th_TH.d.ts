import thTH from '../../date-picker/locale/th_TH';
export default thTH;
