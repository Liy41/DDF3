import frCA from '../../date-picker/locale/fr_CA';
export default frCA;
