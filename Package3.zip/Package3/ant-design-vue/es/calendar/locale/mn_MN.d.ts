import mnMN from '../../date-picker/locale/mn_MN';
export default mnMN;
