import bgBG from '../../date-picker/locale/bg_BG';
export default bgBG;
