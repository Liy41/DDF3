import frBE from '../../date-picker/locale/fr_BE';
export default frBE;
