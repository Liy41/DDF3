/** Created by Andrey Gayvoronsky on 13/04/16. */
import type { PickerLocale } from '../generatePicker';
declare const locale: PickerLocale;
export default locale;
