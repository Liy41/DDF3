declare const Simple: {
    (): JSX.Element;
    PRESENTED_IMAGE_SIMPLE: boolean;
};
export default Simple;
