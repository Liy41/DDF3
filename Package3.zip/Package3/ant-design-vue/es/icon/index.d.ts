declare const _default: {
    (): any;
    displayName: string;
} & import("@vue/runtime-core").Plugin<any[]>;
export default _default;
