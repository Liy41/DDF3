export declare function toArray<T>(value?: T | T[] | null): T[];
