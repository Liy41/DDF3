export declare function supportBigInt(): boolean;
