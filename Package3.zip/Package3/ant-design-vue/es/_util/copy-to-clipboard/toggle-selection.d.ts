declare const deselectCurrent: () => (() => void);
export default deselectCurrent;
