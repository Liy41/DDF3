import type { Ref } from 'vue';
export declare function useSupported(callback: () => unknown, sync?: boolean): Ref<boolean>;
