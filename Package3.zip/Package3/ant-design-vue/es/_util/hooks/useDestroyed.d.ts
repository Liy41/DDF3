declare const useDestroyed: () => import("vue").Ref<boolean>;
export default useDestroyed;
