declare const _default: () => import("vue").Ref<boolean>;
export default _default;
