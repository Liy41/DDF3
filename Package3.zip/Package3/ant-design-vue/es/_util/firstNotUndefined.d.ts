declare function firstNotUndefined<T>(arr?: T[]): T;
export default firstNotUndefined;
