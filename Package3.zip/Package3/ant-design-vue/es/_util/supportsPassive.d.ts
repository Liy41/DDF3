export default supportsPassive;
declare let supportsPassive: boolean;
