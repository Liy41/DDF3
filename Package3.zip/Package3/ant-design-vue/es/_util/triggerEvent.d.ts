export default function triggerEvent(el: Element, type: string): void;
