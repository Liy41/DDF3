export function getComponentLocale(props: any, context: any, componentName: any, getDefaultLocale: any): any;
export function getLocaleCode(context: any): any;
