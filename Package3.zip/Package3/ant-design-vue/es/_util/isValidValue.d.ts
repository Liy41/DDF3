export default function (val: any): boolean;
