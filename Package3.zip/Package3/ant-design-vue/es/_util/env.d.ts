export declare const inBrowser: boolean;
export declare const UA: string;
export declare const isIE: boolean;
export declare const isIE9: boolean;
export declare const isEdge: boolean;
export declare const isChrome: boolean;
export declare const isPhantomJS: boolean;
export declare const isFF: RegExpMatchArray;
