declare const isValid: (value: any) => boolean;
export default isValid;
