export default function _default(query: any): string;
