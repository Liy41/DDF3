declare const _default: (close?: boolean) => void;
export default _default;
