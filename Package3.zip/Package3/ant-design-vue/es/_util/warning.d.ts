export { resetWarned };
declare function _default(valid: any, component: any, message?: string): void;
export default _default;
import { resetWarned } from "../vc-util/warning";
