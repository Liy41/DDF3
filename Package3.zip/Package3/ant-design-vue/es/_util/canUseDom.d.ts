declare function canUseDom(): boolean;
export default canUseDom;
