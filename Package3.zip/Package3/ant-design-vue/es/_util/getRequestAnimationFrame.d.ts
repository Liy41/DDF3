export default function getRequestAnimationFrame(): any;
export function cancelRequestAnimationFrame(id: any): any;
