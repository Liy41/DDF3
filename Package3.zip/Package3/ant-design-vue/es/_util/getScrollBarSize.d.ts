export default function getScrollBarSize(fresh?: boolean): number;
export declare function getTargetScrollBarSize(target: HTMLElement): {
    width: number;
    height: number;
};
