declare function classNames(...args: any[]): string;
export default classNames;
