export default isCssAnimationSupported;
declare function isCssAnimationSupported(): any;
