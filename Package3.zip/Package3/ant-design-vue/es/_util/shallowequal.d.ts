export default function _default(value: any, other: any, customizer: any, thisArg: any): boolean;
