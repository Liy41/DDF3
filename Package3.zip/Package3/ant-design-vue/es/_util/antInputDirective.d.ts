export function addEventListener(el: any, event: any, handler: any, options: any): void;
export default antInput;
declare namespace antInput {
    function created(el: any, binding: any): void;
    function created(el: any, binding: any): void;
}
