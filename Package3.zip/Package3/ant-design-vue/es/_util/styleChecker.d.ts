export declare const canUseDocElement: () => HTMLElement;
export declare function isStyleSupport(styleName: string | string[], styleValue?: any): boolean;
export declare const detectFlexGapSupported: () => boolean;
export default isStyleSupport;
