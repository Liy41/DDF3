export function cancelAnimationTimeout(frame: any): any;
export function requestAnimationTimeout(callback: any, delay?: number): {
    id: any;
};
