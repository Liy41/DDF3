export declare function isWindow(obj: any): boolean;
export default function getScroll(target: HTMLElement | Window | Document | null, top: boolean): number;
