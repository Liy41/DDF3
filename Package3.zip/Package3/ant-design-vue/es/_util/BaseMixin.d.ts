declare namespace _default {
    namespace methods {
        function setState(state: {}, callback: any): void;
        function setState(state: {}, callback: any): void;
        function __emit(...args: any[]): void;
        function __emit(...args: any[]): void;
    }
}
export default _default;
