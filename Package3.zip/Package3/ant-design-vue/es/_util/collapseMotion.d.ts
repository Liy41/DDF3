import type { CSSMotionProps } from './transition';
declare const collapseMotion: (name?: string, appear?: boolean) => CSSMotionProps;
export default collapseMotion;
