export function spyElementPrototypes(Element: any, properties: any): {
    mockRestore(): void;
};
export function spyElementPrototype(Element: any, propName: any, property: any): {
    mockRestore(): void;
};
