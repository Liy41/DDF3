
declare function arch(): 'x64' | 'x86';

export = arch;
