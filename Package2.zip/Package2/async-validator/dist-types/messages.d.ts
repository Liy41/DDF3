import { InternalValidateMessages } from './interface';
export declare function newMessages(): InternalValidateMessages;
export declare const messages: InternalValidateMessages;
