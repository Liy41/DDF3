import { ExecuteValidator } from '../interface';
declare const number: ExecuteValidator;
export default number;
