import { ExecuteValidator } from '../interface';
declare const integer: ExecuteValidator;
export default integer;
