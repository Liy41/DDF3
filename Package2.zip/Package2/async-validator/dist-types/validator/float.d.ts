import { ExecuteValidator } from '../interface';
declare const floatFn: ExecuteValidator;
export default floatFn;
