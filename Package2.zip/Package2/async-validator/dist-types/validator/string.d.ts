import { ExecuteValidator } from '../interface';
declare const string: ExecuteValidator;
export default string;
