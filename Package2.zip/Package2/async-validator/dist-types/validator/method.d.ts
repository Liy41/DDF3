import { ExecuteValidator } from '../interface';
declare const method: ExecuteValidator;
export default method;
