import { ExecuteValidator } from '../interface';
declare const pattern: ExecuteValidator;
export default pattern;
