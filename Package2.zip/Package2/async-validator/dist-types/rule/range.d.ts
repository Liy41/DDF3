import { ExecuteRule } from '../interface';
declare const range: ExecuteRule;
export default range;
