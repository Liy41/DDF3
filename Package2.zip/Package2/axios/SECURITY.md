# Security Policy

## Reporting a Vulnerability

Please report security issues to jasonsaayman@gmail.com
