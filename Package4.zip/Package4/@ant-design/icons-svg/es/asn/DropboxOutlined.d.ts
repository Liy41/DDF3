import { IconDefinition } from '../types';
declare const DropboxOutlined: IconDefinition;
export default DropboxOutlined;
