import { IconDefinition } from '../types';
declare const LineChartOutlined: IconDefinition;
export default LineChartOutlined;
