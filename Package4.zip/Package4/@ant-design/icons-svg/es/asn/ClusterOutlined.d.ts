import { IconDefinition } from '../types';
declare const ClusterOutlined: IconDefinition;
export default ClusterOutlined;
