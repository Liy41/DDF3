import { IconDefinition } from '../types';
declare const IdcardOutlined: IconDefinition;
export default IdcardOutlined;
