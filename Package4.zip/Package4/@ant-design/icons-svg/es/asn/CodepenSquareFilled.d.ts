import { IconDefinition } from '../types';
declare const CodepenSquareFilled: IconDefinition;
export default CodepenSquareFilled;
