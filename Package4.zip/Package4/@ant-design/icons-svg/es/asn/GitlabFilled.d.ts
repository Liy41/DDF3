import { IconDefinition } from '../types';
declare const GitlabFilled: IconDefinition;
export default GitlabFilled;
