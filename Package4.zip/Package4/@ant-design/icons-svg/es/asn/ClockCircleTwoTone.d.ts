import { IconDefinition } from '../types';
declare const ClockCircleTwoTone: IconDefinition;
export default ClockCircleTwoTone;
