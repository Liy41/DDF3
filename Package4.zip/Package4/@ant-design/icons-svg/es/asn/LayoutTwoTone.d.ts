import { IconDefinition } from '../types';
declare const LayoutTwoTone: IconDefinition;
export default LayoutTwoTone;
