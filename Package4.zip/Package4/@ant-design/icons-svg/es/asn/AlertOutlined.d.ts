import { IconDefinition } from '../types';
declare const AlertOutlined: IconDefinition;
export default AlertOutlined;
