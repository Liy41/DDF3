import { IconDefinition } from '../types';
declare const DragOutlined: IconDefinition;
export default DragOutlined;
