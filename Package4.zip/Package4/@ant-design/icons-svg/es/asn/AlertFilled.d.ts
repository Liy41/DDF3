import { IconDefinition } from '../types';
declare const AlertFilled: IconDefinition;
export default AlertFilled;
