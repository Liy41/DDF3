import { IconDefinition } from '../types';
declare const AlignRightOutlined: IconDefinition;
export default AlignRightOutlined;
