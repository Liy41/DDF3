import { IconDefinition } from '../types';
declare const ExclamationCircleOutlined: IconDefinition;
export default ExclamationCircleOutlined;
