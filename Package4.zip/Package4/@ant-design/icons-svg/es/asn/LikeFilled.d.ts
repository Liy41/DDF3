import { IconDefinition } from '../types';
declare const LikeFilled: IconDefinition;
export default LikeFilled;
