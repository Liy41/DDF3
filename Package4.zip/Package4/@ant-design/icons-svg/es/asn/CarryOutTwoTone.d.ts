import { IconDefinition } from '../types';
declare const CarryOutTwoTone: IconDefinition;
export default CarryOutTwoTone;
