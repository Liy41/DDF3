import { IconDefinition } from '../types';
declare const CarryOutOutlined: IconDefinition;
export default CarryOutOutlined;
