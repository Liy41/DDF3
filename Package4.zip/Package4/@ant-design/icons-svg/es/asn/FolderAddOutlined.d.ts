import { IconDefinition } from '../types';
declare const FolderAddOutlined: IconDefinition;
export default FolderAddOutlined;
