import { IconDefinition } from '../types';
declare const FileAddTwoTone: IconDefinition;
export default FileAddTwoTone;
