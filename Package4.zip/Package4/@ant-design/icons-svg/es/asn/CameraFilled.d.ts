import { IconDefinition } from '../types';
declare const CameraFilled: IconDefinition;
export default CameraFilled;
