import { IconDefinition } from '../types';
declare const HighlightTwoTone: IconDefinition;
export default HighlightTwoTone;
