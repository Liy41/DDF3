import { IconDefinition } from '../types';
declare const GiftFilled: IconDefinition;
export default GiftFilled;
