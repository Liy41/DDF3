import { IconDefinition } from '../types';
declare const AndroidFilled: IconDefinition;
export default AndroidFilled;
