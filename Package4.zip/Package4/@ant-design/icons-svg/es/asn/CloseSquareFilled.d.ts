import { IconDefinition } from '../types';
declare const CloseSquareFilled: IconDefinition;
export default CloseSquareFilled;
