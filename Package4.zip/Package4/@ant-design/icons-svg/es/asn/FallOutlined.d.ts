import { IconDefinition } from '../types';
declare const FallOutlined: IconDefinition;
export default FallOutlined;
