import { IconDefinition } from '../types';
declare const BugFilled: IconDefinition;
export default BugFilled;
