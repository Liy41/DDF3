import { IconDefinition } from '../types';
declare const FileProtectOutlined: IconDefinition;
export default FileProtectOutlined;
