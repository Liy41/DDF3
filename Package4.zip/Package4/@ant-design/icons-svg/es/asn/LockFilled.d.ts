import { IconDefinition } from '../types';
declare const LockFilled: IconDefinition;
export default LockFilled;
