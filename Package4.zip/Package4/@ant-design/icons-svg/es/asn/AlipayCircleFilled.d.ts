import { IconDefinition } from '../types';
declare const AlipayCircleFilled: IconDefinition;
export default AlipayCircleFilled;
