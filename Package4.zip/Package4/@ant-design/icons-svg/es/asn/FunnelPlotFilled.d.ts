import { IconDefinition } from '../types';
declare const FunnelPlotFilled: IconDefinition;
export default FunnelPlotFilled;
