import { IconDefinition } from '../types';
declare const CodeSandboxOutlined: IconDefinition;
export default CodeSandboxOutlined;
