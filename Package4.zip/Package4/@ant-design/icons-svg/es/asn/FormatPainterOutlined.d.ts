import { IconDefinition } from '../types';
declare const FormatPainterOutlined: IconDefinition;
export default FormatPainterOutlined;
