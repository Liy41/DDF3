import { IconDefinition } from '../types';
declare const ItalicOutlined: IconDefinition;
export default ItalicOutlined;
