import { IconDefinition } from '../types';
declare const CheckCircleTwoTone: IconDefinition;
export default CheckCircleTwoTone;
