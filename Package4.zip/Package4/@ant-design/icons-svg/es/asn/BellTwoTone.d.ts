import { IconDefinition } from '../types';
declare const BellTwoTone: IconDefinition;
export default BellTwoTone;
