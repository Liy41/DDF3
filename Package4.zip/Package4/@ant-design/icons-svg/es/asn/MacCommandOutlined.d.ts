import { IconDefinition } from '../types';
declare const MacCommandOutlined: IconDefinition;
export default MacCommandOutlined;
