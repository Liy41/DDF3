import { IconDefinition } from '../types';
declare const JavaScriptOutlined: IconDefinition;
export default JavaScriptOutlined;
