import { IconDefinition } from '../types';
declare const ConsoleSqlOutlined: IconDefinition;
export default ConsoleSqlOutlined;
