import { IconDefinition } from '../types';
declare const IeOutlined: IconDefinition;
export default IeOutlined;
