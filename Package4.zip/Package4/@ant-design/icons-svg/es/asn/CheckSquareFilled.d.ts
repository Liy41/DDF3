import { IconDefinition } from '../types';
declare const CheckSquareFilled: IconDefinition;
export default CheckSquareFilled;
