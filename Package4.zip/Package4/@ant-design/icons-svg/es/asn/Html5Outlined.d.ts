import { IconDefinition } from '../types';
declare const Html5Outlined: IconDefinition;
export default Html5Outlined;
