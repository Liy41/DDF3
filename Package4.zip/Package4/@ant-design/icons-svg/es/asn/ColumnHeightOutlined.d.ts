import { IconDefinition } from '../types';
declare const ColumnHeightOutlined: IconDefinition;
export default ColumnHeightOutlined;
