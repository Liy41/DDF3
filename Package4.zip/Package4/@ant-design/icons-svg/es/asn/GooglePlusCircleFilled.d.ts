import { IconDefinition } from '../types';
declare const GooglePlusCircleFilled: IconDefinition;
export default GooglePlusCircleFilled;
