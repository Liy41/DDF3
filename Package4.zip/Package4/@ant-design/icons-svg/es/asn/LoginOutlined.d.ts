import { IconDefinition } from '../types';
declare const LoginOutlined: IconDefinition;
export default LoginOutlined;
