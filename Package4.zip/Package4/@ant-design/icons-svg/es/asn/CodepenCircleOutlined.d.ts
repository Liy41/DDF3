import { IconDefinition } from '../types';
declare const CodepenCircleOutlined: IconDefinition;
export default CodepenCircleOutlined;
