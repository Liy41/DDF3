import { IconDefinition } from '../types';
declare const InsuranceTwoTone: IconDefinition;
export default InsuranceTwoTone;
