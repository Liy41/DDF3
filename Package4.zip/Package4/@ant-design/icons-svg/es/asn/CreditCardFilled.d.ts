import { IconDefinition } from '../types';
declare const CreditCardFilled: IconDefinition;
export default CreditCardFilled;
