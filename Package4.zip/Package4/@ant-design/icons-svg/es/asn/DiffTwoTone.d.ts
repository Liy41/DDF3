import { IconDefinition } from '../types';
declare const DiffTwoTone: IconDefinition;
export default DiffTwoTone;
