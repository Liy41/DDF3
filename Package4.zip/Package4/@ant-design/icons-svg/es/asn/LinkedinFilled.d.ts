import { IconDefinition } from '../types';
declare const LinkedinFilled: IconDefinition;
export default LinkedinFilled;
