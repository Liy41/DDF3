import { IconDefinition } from '../types';
declare const Html5TwoTone: IconDefinition;
export default Html5TwoTone;
