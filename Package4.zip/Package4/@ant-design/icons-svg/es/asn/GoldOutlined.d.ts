import { IconDefinition } from '../types';
declare const GoldOutlined: IconDefinition;
export default GoldOutlined;
