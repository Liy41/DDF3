import { IconDefinition } from '../types';
declare const DollarCircleTwoTone: IconDefinition;
export default DollarCircleTwoTone;
