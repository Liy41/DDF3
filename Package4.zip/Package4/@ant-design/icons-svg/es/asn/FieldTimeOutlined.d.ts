import { IconDefinition } from '../types';
declare const FieldTimeOutlined: IconDefinition;
export default FieldTimeOutlined;
