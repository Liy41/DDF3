import { IconDefinition } from '../types';
declare const AudioFilled: IconDefinition;
export default AudioFilled;
