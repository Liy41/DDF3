import { IconDefinition } from '../types';
declare const LockOutlined: IconDefinition;
export default LockOutlined;
