import { IconDefinition } from '../types';
declare const FastBackwardOutlined: IconDefinition;
export default FastBackwardOutlined;
