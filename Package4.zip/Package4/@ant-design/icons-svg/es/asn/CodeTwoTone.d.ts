import { IconDefinition } from '../types';
declare const CodeTwoTone: IconDefinition;
export default CodeTwoTone;
