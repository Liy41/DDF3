import { IconDefinition } from '../types';
declare const LockTwoTone: IconDefinition;
export default LockTwoTone;
