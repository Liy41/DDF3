import { IconDefinition } from '../types';
declare const DoubleRightOutlined: IconDefinition;
export default DoubleRightOutlined;
