import { IconDefinition } from '../types';
declare const CloudDownloadOutlined: IconDefinition;
export default CloudDownloadOutlined;
