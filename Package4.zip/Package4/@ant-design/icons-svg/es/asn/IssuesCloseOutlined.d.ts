import { IconDefinition } from '../types';
declare const IssuesCloseOutlined: IconDefinition;
export default IssuesCloseOutlined;
