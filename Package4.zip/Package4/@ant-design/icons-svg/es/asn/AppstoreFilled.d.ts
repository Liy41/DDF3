import { IconDefinition } from '../types';
declare const AppstoreFilled: IconDefinition;
export default AppstoreFilled;
