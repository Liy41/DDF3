import { IconDefinition } from '../types';
declare const FileTwoTone: IconDefinition;
export default FileTwoTone;
