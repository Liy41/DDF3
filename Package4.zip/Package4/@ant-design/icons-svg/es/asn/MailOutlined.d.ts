import { IconDefinition } from '../types';
declare const MailOutlined: IconDefinition;
export default MailOutlined;
