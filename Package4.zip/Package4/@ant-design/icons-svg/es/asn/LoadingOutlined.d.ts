import { IconDefinition } from '../types';
declare const LoadingOutlined: IconDefinition;
export default LoadingOutlined;
