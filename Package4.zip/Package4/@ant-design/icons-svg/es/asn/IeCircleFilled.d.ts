import { IconDefinition } from '../types';
declare const IeCircleFilled: IconDefinition;
export default IeCircleFilled;
