import { IconDefinition } from '../types';
declare const BorderInnerOutlined: IconDefinition;
export default BorderInnerOutlined;
