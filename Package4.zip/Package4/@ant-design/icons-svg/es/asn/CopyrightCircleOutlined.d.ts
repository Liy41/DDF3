import { IconDefinition } from '../types';
declare const CopyrightCircleOutlined: IconDefinition;
export default CopyrightCircleOutlined;
