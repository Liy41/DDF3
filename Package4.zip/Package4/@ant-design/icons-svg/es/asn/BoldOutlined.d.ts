import { IconDefinition } from '../types';
declare const BoldOutlined: IconDefinition;
export default BoldOutlined;
