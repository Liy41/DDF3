import { IconDefinition } from '../types';
declare const CloudTwoTone: IconDefinition;
export default CloudTwoTone;
