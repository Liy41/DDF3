import { IconDefinition } from '../types';
declare const ExpandOutlined: IconDefinition;
export default ExpandOutlined;
