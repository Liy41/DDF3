import { IconDefinition } from '../types';
declare const KubernetesOutlined: IconDefinition;
export default KubernetesOutlined;
