import { IconDefinition } from '../types';
declare const JavaOutlined: IconDefinition;
export default JavaOutlined;
