import { IconDefinition } from '../types';
declare const BugOutlined: IconDefinition;
export default BugOutlined;
