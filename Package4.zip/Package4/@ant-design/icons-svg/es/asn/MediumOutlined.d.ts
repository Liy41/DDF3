import { IconDefinition } from '../types';
declare const MediumOutlined: IconDefinition;
export default MediumOutlined;
