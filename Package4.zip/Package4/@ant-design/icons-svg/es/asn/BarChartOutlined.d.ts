import { IconDefinition } from '../types';
declare const BarChartOutlined: IconDefinition;
export default BarChartOutlined;
