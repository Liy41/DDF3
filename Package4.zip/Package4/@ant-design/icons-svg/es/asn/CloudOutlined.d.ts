import { IconDefinition } from '../types';
declare const CloudOutlined: IconDefinition;
export default CloudOutlined;
