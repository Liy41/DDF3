import { IconDefinition } from '../types';
declare const AntDesignOutlined: IconDefinition;
export default AntDesignOutlined;
