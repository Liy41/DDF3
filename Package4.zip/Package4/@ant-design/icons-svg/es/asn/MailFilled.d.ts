import { IconDefinition } from '../types';
declare const MailFilled: IconDefinition;
export default MailFilled;
