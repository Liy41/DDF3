import { IconDefinition } from '../types';
declare const DisconnectOutlined: IconDefinition;
export default DisconnectOutlined;
