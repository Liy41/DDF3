import { IconDefinition } from '../types';
declare const AudioOutlined: IconDefinition;
export default AudioOutlined;
