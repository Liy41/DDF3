import { IconDefinition } from '../types';
declare const LeftSquareFilled: IconDefinition;
export default LeftSquareFilled;
