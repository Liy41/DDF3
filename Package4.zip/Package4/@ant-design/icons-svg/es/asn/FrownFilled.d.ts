import { IconDefinition } from '../types';
declare const FrownFilled: IconDefinition;
export default FrownFilled;
