import { IconDefinition } from '../types';
declare const ArrowsAltOutlined: IconDefinition;
export default ArrowsAltOutlined;
