import { IconDefinition } from '../types';
declare const CloseCircleOutlined: IconDefinition;
export default CloseCircleOutlined;
