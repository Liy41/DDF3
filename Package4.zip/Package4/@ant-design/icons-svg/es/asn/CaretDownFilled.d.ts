import { IconDefinition } from '../types';
declare const CaretDownFilled: IconDefinition;
export default CaretDownFilled;
