import { IconDefinition } from '../types';
declare const FilterOutlined: IconDefinition;
export default FilterOutlined;
