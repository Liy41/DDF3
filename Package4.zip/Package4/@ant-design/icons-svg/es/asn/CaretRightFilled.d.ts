import { IconDefinition } from '../types';
declare const CaretRightFilled: IconDefinition;
export default CaretRightFilled;
