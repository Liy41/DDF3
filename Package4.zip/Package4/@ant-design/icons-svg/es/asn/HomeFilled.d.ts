import { IconDefinition } from '../types';
declare const HomeFilled: IconDefinition;
export default HomeFilled;
