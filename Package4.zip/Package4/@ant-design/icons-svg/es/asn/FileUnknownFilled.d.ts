import { IconDefinition } from '../types';
declare const FileUnknownFilled: IconDefinition;
export default FileUnknownFilled;
