import { IconDefinition } from '../types';
declare const FunctionOutlined: IconDefinition;
export default FunctionOutlined;
