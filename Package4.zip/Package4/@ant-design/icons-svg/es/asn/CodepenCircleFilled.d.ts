import { IconDefinition } from '../types';
declare const CodepenCircleFilled: IconDefinition;
export default CodepenCircleFilled;
