import { IconDefinition } from '../types';
declare const FileWordOutlined: IconDefinition;
export default FileWordOutlined;
