import { IconDefinition } from '../types';
declare const FolderAddFilled: IconDefinition;
export default FolderAddFilled;
