import { IconDefinition } from '../types';
declare const AuditOutlined: IconDefinition;
export default AuditOutlined;
