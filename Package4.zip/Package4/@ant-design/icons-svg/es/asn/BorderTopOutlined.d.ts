import { IconDefinition } from '../types';
declare const BorderTopOutlined: IconDefinition;
export default BorderTopOutlined;
