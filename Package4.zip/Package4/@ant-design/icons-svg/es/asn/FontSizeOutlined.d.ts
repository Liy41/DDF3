import { IconDefinition } from '../types';
declare const FontSizeOutlined: IconDefinition;
export default FontSizeOutlined;
