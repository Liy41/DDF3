import { IconDefinition } from '../types';
declare const ControlTwoTone: IconDefinition;
export default ControlTwoTone;
