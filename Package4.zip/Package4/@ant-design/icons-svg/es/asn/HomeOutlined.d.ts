import { IconDefinition } from '../types';
declare const HomeOutlined: IconDefinition;
export default HomeOutlined;
