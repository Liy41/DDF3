import { IconDefinition } from '../types';
declare const LinuxOutlined: IconDefinition;
export default LinuxOutlined;
