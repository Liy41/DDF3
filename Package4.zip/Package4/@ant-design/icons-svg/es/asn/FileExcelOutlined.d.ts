import { IconDefinition } from '../types';
declare const FileExcelOutlined: IconDefinition;
export default FileExcelOutlined;
