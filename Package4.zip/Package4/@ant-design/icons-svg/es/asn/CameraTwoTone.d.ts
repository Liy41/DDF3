import { IconDefinition } from '../types';
declare const CameraTwoTone: IconDefinition;
export default CameraTwoTone;
