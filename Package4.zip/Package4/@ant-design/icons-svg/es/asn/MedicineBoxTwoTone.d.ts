import { IconDefinition } from '../types';
declare const MedicineBoxTwoTone: IconDefinition;
export default MedicineBoxTwoTone;
