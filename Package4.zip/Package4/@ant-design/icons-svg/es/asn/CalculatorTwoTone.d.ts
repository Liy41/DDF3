import { IconDefinition } from '../types';
declare const CalculatorTwoTone: IconDefinition;
export default CalculatorTwoTone;
