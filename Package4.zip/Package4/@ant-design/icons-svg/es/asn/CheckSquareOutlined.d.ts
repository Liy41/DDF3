import { IconDefinition } from '../types';
declare const CheckSquareOutlined: IconDefinition;
export default CheckSquareOutlined;
