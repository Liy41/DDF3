import { IconDefinition } from '../types';
declare const FileSyncOutlined: IconDefinition;
export default FileSyncOutlined;
