import { IconDefinition } from '../types';
declare const DashOutlined: IconDefinition;
export default DashOutlined;
