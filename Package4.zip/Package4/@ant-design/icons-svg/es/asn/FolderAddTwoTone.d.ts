import { IconDefinition } from '../types';
declare const FolderAddTwoTone: IconDefinition;
export default FolderAddTwoTone;
