import { IconDefinition } from '../types';
declare const GooglePlusSquareFilled: IconDefinition;
export default GooglePlusSquareFilled;
