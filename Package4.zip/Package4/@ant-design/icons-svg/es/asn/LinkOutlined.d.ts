import { IconDefinition } from '../types';
declare const LinkOutlined: IconDefinition;
export default LinkOutlined;
