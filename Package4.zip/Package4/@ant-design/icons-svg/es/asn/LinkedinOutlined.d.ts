import { IconDefinition } from '../types';
declare const LinkedinOutlined: IconDefinition;
export default LinkedinOutlined;
