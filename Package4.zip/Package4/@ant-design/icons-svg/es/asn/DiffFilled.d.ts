import { IconDefinition } from '../types';
declare const DiffFilled: IconDefinition;
export default DiffFilled;
