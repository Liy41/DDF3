import { IconDefinition } from '../types';
declare const HomeTwoTone: IconDefinition;
export default HomeTwoTone;
