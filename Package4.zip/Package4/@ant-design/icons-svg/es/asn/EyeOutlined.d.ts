import { IconDefinition } from '../types';
declare const EyeOutlined: IconDefinition;
export default EyeOutlined;
