import { IconDefinition } from '../types';
declare const FormatPainterFilled: IconDefinition;
export default FormatPainterFilled;
