import { IconDefinition } from '../types';
declare const ForwardFilled: IconDefinition;
export default ForwardFilled;
