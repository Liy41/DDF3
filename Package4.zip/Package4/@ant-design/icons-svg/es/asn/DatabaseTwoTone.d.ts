import { IconDefinition } from '../types';
declare const DatabaseTwoTone: IconDefinition;
export default DatabaseTwoTone;
