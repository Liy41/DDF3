import { IconDefinition } from '../types';
declare const BilibiliOutlined: IconDefinition;
export default BilibiliOutlined;
