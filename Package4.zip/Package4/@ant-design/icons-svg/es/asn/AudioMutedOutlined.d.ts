import { IconDefinition } from '../types';
declare const AudioMutedOutlined: IconDefinition;
export default AudioMutedOutlined;
