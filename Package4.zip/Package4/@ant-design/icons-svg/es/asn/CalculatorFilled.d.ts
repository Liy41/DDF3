import { IconDefinition } from '../types';
declare const CalculatorFilled: IconDefinition;
export default CalculatorFilled;
