import { IconDefinition } from '../types';
declare const DockerOutlined: IconDefinition;
export default DockerOutlined;
