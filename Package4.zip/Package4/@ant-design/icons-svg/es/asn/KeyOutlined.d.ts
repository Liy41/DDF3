import { IconDefinition } from '../types';
declare const KeyOutlined: IconDefinition;
export default KeyOutlined;
