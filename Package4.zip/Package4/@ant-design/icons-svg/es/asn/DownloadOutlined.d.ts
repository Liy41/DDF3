import { IconDefinition } from '../types';
declare const DownloadOutlined: IconDefinition;
export default DownloadOutlined;
