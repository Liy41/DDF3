import { IconDefinition } from '../types';
declare const FileImageTwoTone: IconDefinition;
export default FileImageTwoTone;
