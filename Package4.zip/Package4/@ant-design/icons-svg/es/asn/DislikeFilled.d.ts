import { IconDefinition } from '../types';
declare const DislikeFilled: IconDefinition;
export default DislikeFilled;
