import { IconDefinition } from '../types';
declare const BorderHorizontalOutlined: IconDefinition;
export default BorderHorizontalOutlined;
