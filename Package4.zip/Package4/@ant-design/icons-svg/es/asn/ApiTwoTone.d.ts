import { IconDefinition } from '../types';
declare const ApiTwoTone: IconDefinition;
export default ApiTwoTone;
