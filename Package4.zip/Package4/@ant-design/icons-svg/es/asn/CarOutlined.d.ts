import { IconDefinition } from '../types';
declare const CarOutlined: IconDefinition;
export default CarOutlined;
