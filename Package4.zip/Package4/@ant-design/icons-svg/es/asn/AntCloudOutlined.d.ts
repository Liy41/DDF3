import { IconDefinition } from '../types';
declare const AntCloudOutlined: IconDefinition;
export default AntCloudOutlined;
