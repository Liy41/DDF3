import { IconDefinition } from '../types';
declare const CloseSquareTwoTone: IconDefinition;
export default CloseSquareTwoTone;
