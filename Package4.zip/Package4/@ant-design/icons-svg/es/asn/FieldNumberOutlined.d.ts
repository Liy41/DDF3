import { IconDefinition } from '../types';
declare const FieldNumberOutlined: IconDefinition;
export default FieldNumberOutlined;
