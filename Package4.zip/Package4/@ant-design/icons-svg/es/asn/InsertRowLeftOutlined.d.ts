import { IconDefinition } from '../types';
declare const InsertRowLeftOutlined: IconDefinition;
export default InsertRowLeftOutlined;
