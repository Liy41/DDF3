import { IconDefinition } from '../types';
declare const CommentOutlined: IconDefinition;
export default CommentOutlined;
