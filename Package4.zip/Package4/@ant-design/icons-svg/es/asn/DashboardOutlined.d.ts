import { IconDefinition } from '../types';
declare const DashboardOutlined: IconDefinition;
export default DashboardOutlined;
