import { IconDefinition } from '../types';
declare const BuildFilled: IconDefinition;
export default BuildFilled;
