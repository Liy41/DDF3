import { IconDefinition } from '../types';
declare const GlobalOutlined: IconDefinition;
export default GlobalOutlined;
