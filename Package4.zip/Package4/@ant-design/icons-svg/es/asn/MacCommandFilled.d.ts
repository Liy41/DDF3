import { IconDefinition } from '../types';
declare const MacCommandFilled: IconDefinition;
export default MacCommandFilled;
