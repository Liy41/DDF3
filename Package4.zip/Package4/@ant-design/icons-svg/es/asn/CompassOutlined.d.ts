import { IconDefinition } from '../types';
declare const CompassOutlined: IconDefinition;
export default CompassOutlined;
