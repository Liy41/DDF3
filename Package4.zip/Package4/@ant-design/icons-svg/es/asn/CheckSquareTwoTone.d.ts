import { IconDefinition } from '../types';
declare const CheckSquareTwoTone: IconDefinition;
export default CheckSquareTwoTone;
