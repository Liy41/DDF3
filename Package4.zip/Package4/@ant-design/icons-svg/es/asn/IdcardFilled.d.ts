import { IconDefinition } from '../types';
declare const IdcardFilled: IconDefinition;
export default IdcardFilled;
