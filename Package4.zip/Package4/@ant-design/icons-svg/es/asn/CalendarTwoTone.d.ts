import { IconDefinition } from '../types';
declare const CalendarTwoTone: IconDefinition;
export default CalendarTwoTone;
