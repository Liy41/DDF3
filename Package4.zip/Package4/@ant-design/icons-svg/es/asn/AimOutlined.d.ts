import { IconDefinition } from '../types';
declare const AimOutlined: IconDefinition;
export default AimOutlined;
