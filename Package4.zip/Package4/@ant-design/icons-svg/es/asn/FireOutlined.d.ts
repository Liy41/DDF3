import { IconDefinition } from '../types';
declare const FireOutlined: IconDefinition;
export default FireOutlined;
