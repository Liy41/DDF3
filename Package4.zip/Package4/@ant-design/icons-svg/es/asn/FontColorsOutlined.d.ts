import { IconDefinition } from '../types';
declare const FontColorsOutlined: IconDefinition;
export default FontColorsOutlined;
