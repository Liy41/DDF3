import { IconDefinition } from '../types';
declare const BuildOutlined: IconDefinition;
export default BuildOutlined;
