import { IconDefinition } from '../types';
declare const BuildTwoTone: IconDefinition;
export default BuildTwoTone;
