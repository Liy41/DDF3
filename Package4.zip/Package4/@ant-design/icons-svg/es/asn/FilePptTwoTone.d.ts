import { IconDefinition } from '../types';
declare const FilePptTwoTone: IconDefinition;
export default FilePptTwoTone;
