import { IconDefinition } from '../types';
declare const LeftSquareOutlined: IconDefinition;
export default LeftSquareOutlined;
