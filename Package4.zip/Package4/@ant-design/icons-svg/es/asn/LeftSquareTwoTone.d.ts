import { IconDefinition } from '../types';
declare const LeftSquareTwoTone: IconDefinition;
export default LeftSquareTwoTone;
