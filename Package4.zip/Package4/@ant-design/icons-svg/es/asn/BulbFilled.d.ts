import { IconDefinition } from '../types';
declare const BulbFilled: IconDefinition;
export default BulbFilled;
