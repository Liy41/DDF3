import { IconDefinition } from '../types';
declare const ChromeFilled: IconDefinition;
export default ChromeFilled;
