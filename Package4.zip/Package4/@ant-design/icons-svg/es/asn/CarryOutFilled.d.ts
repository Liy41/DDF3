import { IconDefinition } from '../types';
declare const CarryOutFilled: IconDefinition;
export default CarryOutFilled;
