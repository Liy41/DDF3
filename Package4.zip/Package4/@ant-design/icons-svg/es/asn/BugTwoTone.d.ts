import { IconDefinition } from '../types';
declare const BugTwoTone: IconDefinition;
export default BugTwoTone;
