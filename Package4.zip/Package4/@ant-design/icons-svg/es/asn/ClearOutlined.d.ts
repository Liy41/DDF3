import { IconDefinition } from '../types';
declare const ClearOutlined: IconDefinition;
export default ClearOutlined;
