import { IconDefinition } from '../types';
declare const BookTwoTone: IconDefinition;
export default BookTwoTone;
