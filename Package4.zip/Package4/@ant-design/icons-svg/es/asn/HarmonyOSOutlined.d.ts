import { IconDefinition } from '../types';
declare const HarmonyOSOutlined: IconDefinition;
export default HarmonyOSOutlined;
