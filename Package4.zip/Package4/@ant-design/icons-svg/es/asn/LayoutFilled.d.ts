import { IconDefinition } from '../types';
declare const LayoutFilled: IconDefinition;
export default LayoutFilled;
