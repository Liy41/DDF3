import { IconDefinition } from '../types';
declare const BgColorsOutlined: IconDefinition;
export default BgColorsOutlined;
