import { IconDefinition } from '../types';
declare const ExportOutlined: IconDefinition;
export default ExportOutlined;
