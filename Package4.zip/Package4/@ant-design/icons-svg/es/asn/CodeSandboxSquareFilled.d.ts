import { IconDefinition } from '../types';
declare const CodeSandboxSquareFilled: IconDefinition;
export default CodeSandboxSquareFilled;
