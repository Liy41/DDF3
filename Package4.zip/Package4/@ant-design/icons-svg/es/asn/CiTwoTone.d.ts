import { IconDefinition } from '../types';
declare const CiTwoTone: IconDefinition;
export default CiTwoTone;
