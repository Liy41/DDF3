import { IconDefinition } from '../types';
declare const LineHeightOutlined: IconDefinition;
export default LineHeightOutlined;
