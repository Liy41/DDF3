import { IconDefinition } from '../types';
declare const FileOutlined: IconDefinition;
export default FileOutlined;
