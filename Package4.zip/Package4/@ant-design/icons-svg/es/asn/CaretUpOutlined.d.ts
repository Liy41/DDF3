import { IconDefinition } from '../types';
declare const CaretUpOutlined: IconDefinition;
export default CaretUpOutlined;
