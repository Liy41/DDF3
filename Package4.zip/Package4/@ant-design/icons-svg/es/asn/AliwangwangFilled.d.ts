import { IconDefinition } from '../types';
declare const AliwangwangFilled: IconDefinition;
export default AliwangwangFilled;
