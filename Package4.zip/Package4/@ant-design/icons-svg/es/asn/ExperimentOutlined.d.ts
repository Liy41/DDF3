import { IconDefinition } from '../types';
declare const ExperimentOutlined: IconDefinition;
export default ExperimentOutlined;
