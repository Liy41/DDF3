import { IconDefinition } from '../types';
declare const DingdingOutlined: IconDefinition;
export default DingdingOutlined;
