import { IconDefinition } from '../types';
declare const HourglassFilled: IconDefinition;
export default HourglassFilled;
