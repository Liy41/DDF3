import { IconDefinition } from '../types';
declare const BellFilled: IconDefinition;
export default BellFilled;
