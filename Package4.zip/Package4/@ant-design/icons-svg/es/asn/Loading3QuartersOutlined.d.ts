import { IconDefinition } from '../types';
declare const Loading3QuartersOutlined: IconDefinition;
export default Loading3QuartersOutlined;
