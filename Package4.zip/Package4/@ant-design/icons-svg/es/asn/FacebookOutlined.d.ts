import { IconDefinition } from '../types';
declare const FacebookOutlined: IconDefinition;
export default FacebookOutlined;
