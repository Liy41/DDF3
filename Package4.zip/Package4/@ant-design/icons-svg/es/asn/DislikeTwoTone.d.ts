import { IconDefinition } from '../types';
declare const DislikeTwoTone: IconDefinition;
export default DislikeTwoTone;
