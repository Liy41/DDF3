import { IconDefinition } from '../types';
declare const FundViewOutlined: IconDefinition;
export default FundViewOutlined;
