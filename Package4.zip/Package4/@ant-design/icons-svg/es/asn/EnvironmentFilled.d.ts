import { IconDefinition } from '../types';
declare const EnvironmentFilled: IconDefinition;
export default EnvironmentFilled;
