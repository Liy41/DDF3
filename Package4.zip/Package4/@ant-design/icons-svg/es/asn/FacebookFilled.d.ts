import { IconDefinition } from '../types';
declare const FacebookFilled: IconDefinition;
export default FacebookFilled;
