import { IconDefinition } from '../types';
declare const AliyunOutlined: IconDefinition;
export default AliyunOutlined;
