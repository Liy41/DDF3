import { IconDefinition } from '../types';
declare const CarFilled: IconDefinition;
export default CarFilled;
