import { IconDefinition } from '../types';
declare const ControlOutlined: IconDefinition;
export default ControlOutlined;
