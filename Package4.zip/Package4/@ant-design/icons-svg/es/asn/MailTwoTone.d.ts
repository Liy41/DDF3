import { IconDefinition } from '../types';
declare const MailTwoTone: IconDefinition;
export default MailTwoTone;
