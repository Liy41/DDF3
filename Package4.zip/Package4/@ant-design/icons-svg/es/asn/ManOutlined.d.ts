import { IconDefinition } from '../types';
declare const ManOutlined: IconDefinition;
export default ManOutlined;
