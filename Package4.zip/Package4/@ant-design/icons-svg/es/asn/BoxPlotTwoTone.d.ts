import { IconDefinition } from '../types';
declare const BoxPlotTwoTone: IconDefinition;
export default BoxPlotTwoTone;
