import { IconDefinition } from '../types';
declare const InstagramOutlined: IconDefinition;
export default InstagramOutlined;
