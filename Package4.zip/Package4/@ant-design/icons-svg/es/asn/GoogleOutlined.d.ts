import { IconDefinition } from '../types';
declare const GoogleOutlined: IconDefinition;
export default GoogleOutlined;
