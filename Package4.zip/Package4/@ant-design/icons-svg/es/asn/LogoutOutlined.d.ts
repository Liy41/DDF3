import { IconDefinition } from '../types';
declare const LogoutOutlined: IconDefinition;
export default LogoutOutlined;
