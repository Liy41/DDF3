import { IconDefinition } from '../types';
declare const MedicineBoxFilled: IconDefinition;
export default MedicineBoxFilled;
