import { IconDefinition } from '../types';
declare const EuroCircleTwoTone: IconDefinition;
export default EuroCircleTwoTone;
