import { IconDefinition } from '../types';
declare const AlipaySquareFilled: IconDefinition;
export default AlipaySquareFilled;
