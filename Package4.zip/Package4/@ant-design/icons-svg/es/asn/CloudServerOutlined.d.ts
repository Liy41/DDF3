import { IconDefinition } from '../types';
declare const CloudServerOutlined: IconDefinition;
export default CloudServerOutlined;
