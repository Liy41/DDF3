import { IconDefinition } from '../types';
declare const CheckCircleFilled: IconDefinition;
export default CheckCircleFilled;
