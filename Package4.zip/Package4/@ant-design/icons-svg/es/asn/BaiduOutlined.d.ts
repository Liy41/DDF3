import { IconDefinition } from '../types';
declare const BaiduOutlined: IconDefinition;
export default BaiduOutlined;
