import { IconDefinition } from '../types';
declare const ExclamationCircleFilled: IconDefinition;
export default ExclamationCircleFilled;
