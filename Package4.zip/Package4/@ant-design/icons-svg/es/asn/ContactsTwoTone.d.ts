import { IconDefinition } from '../types';
declare const ContactsTwoTone: IconDefinition;
export default ContactsTwoTone;
