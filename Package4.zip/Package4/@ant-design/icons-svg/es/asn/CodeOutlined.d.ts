import { IconDefinition } from '../types';
declare const CodeOutlined: IconDefinition;
export default CodeOutlined;
