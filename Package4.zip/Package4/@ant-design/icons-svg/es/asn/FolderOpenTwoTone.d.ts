import { IconDefinition } from '../types';
declare const FolderOpenTwoTone: IconDefinition;
export default FolderOpenTwoTone;
