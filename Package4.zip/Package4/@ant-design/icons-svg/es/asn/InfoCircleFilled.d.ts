import { IconDefinition } from '../types';
declare const InfoCircleFilled: IconDefinition;
export default InfoCircleFilled;
