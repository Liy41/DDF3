import { IconDefinition } from '../types';
declare const BarcodeOutlined: IconDefinition;
export default BarcodeOutlined;
