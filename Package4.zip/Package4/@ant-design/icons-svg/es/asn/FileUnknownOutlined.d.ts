import { IconDefinition } from '../types';
declare const FileUnknownOutlined: IconDefinition;
export default FileUnknownOutlined;
