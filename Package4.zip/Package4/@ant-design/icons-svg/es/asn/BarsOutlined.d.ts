import { IconDefinition } from '../types';
declare const BarsOutlined: IconDefinition;
export default BarsOutlined;
