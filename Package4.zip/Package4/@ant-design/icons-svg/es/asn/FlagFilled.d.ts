import { IconDefinition } from '../types';
declare const FlagFilled: IconDefinition;
export default FlagFilled;
