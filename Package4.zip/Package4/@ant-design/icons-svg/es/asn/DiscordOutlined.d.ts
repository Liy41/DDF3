import { IconDefinition } from '../types';
declare const DiscordOutlined: IconDefinition;
export default DiscordOutlined;
