import { IconDefinition } from '../types';
declare const CloseSquareOutlined: IconDefinition;
export default CloseSquareOutlined;
