import { IconDefinition } from '../types';
declare const MediumSquareFilled: IconDefinition;
export default MediumSquareFilled;
