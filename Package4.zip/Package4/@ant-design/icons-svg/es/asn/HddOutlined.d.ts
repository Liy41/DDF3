import { IconDefinition } from '../types';
declare const HddOutlined: IconDefinition;
export default HddOutlined;
