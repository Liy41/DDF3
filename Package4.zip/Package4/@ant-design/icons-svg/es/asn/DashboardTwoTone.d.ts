import { IconDefinition } from '../types';
declare const DashboardTwoTone: IconDefinition;
export default DashboardTwoTone;
