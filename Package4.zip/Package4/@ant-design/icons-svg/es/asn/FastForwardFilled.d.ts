import { IconDefinition } from '../types';
declare const FastForwardFilled: IconDefinition;
export default FastForwardFilled;
