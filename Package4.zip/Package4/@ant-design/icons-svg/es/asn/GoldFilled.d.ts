import { IconDefinition } from '../types';
declare const GoldFilled: IconDefinition;
export default GoldFilled;
