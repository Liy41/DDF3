import { IconDefinition } from '../types';
declare const DiscordFilled: IconDefinition;
export default DiscordFilled;
