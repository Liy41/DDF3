import { IconDefinition } from '../types';
declare const CloseCircleTwoTone: IconDefinition;
export default CloseCircleTwoTone;
