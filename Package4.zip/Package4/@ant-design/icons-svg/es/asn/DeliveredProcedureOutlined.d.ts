import { IconDefinition } from '../types';
declare const DeliveredProcedureOutlined: IconDefinition;
export default DeliveredProcedureOutlined;
