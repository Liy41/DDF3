import { IconDefinition } from '../types';
declare const AliwangwangOutlined: IconDefinition;
export default AliwangwangOutlined;
