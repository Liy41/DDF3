import { IconDefinition } from '../types';
declare const BorderBottomOutlined: IconDefinition;
export default BorderBottomOutlined;
