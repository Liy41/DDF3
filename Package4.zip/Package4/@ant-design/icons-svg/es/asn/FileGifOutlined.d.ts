import { IconDefinition } from '../types';
declare const FileGifOutlined: IconDefinition;
export default FileGifOutlined;
