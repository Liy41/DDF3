import { IconDefinition } from '../types';
declare const InteractionFilled: IconDefinition;
export default InteractionFilled;
