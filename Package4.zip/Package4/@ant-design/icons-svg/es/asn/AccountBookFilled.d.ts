import { IconDefinition } from '../types';
declare const AccountBookFilled: IconDefinition;
export default AccountBookFilled;
