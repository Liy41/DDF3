import { IconDefinition } from '../types';
declare const BilibiliFilled: IconDefinition;
export default BilibiliFilled;
