import { IconDefinition } from '../types';
declare const LikeOutlined: IconDefinition;
export default LikeOutlined;
