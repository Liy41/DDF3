import { IconDefinition } from '../types';
declare const LikeTwoTone: IconDefinition;
export default LikeTwoTone;
