import { IconDefinition } from '../types';
declare const FileExclamationOutlined: IconDefinition;
export default FileExclamationOutlined;
