import { IconDefinition } from '../types';
declare const BackwardFilled: IconDefinition;
export default BackwardFilled;
