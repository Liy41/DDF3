import { IconDefinition } from '../types';
declare const GroupOutlined: IconDefinition;
export default GroupOutlined;
