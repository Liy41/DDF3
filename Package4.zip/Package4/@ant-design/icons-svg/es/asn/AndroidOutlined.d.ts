import { IconDefinition } from '../types';
declare const AndroidOutlined: IconDefinition;
export default AndroidOutlined;
