import { IconDefinition } from '../types';
declare const DotNetOutlined: IconDefinition;
export default DotNetOutlined;
