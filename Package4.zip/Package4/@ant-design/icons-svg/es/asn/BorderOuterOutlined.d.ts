import { IconDefinition } from '../types';
declare const BorderOuterOutlined: IconDefinition;
export default BorderOuterOutlined;
