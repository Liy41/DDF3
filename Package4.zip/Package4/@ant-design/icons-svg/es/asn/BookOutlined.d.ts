import { IconDefinition } from '../types';
declare const BookOutlined: IconDefinition;
export default BookOutlined;
