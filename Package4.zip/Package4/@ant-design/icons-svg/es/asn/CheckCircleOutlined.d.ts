import { IconDefinition } from '../types';
declare const CheckCircleOutlined: IconDefinition;
export default CheckCircleOutlined;
