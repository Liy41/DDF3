import { IconDefinition } from '../types';
declare const CheckOutlined: IconDefinition;
export default CheckOutlined;
