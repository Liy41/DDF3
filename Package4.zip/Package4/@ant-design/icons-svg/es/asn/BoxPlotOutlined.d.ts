import { IconDefinition } from '../types';
declare const BoxPlotOutlined: IconDefinition;
export default BoxPlotOutlined;
