import { IconDefinition } from '../types';
declare const CustomerServiceFilled: IconDefinition;
export default CustomerServiceFilled;
