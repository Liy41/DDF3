import { IconDefinition } from '../types';
declare const MedicineBoxOutlined: IconDefinition;
export default MedicineBoxOutlined;
