import { IconDefinition } from '../types';
declare const LineOutlined: IconDefinition;
export default LineOutlined;
