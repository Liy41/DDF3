import { IconDefinition } from '../types';
declare const DownCircleTwoTone: IconDefinition;
export default DownCircleTwoTone;
