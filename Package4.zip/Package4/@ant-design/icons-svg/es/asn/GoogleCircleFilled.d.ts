import { IconDefinition } from '../types';
declare const GoogleCircleFilled: IconDefinition;
export default GoogleCircleFilled;
