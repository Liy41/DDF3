import { IconDefinition } from '../types';
declare const DiffOutlined: IconDefinition;
export default DiffOutlined;
