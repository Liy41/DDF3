import { IconDefinition } from '../types';
declare const FileAddOutlined: IconDefinition;
export default FileAddOutlined;
