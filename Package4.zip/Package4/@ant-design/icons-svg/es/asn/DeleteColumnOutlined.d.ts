import { IconDefinition } from '../types';
declare const DeleteColumnOutlined: IconDefinition;
export default DeleteColumnOutlined;
