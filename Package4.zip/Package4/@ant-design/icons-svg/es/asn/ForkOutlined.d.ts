import { IconDefinition } from '../types';
declare const ForkOutlined: IconDefinition;
export default ForkOutlined;
