import { IconDefinition } from '../types';
declare const AppleOutlined: IconDefinition;
export default AppleOutlined;
