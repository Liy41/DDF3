import { IconDefinition } from '../types';
declare const DeleteRowOutlined: IconDefinition;
export default DeleteRowOutlined;
