import { IconDefinition } from '../types';
declare const FilePptFilled: IconDefinition;
export default FilePptFilled;
