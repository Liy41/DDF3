import { IconDefinition } from '../types';
declare const CopyOutlined: IconDefinition;
export default CopyOutlined;
