import { IconDefinition } from '../types';
declare const ArrowDownOutlined: IconDefinition;
export default ArrowDownOutlined;
