import { IconDefinition } from '../types';
declare const BorderOutlined: IconDefinition;
export default BorderOutlined;
