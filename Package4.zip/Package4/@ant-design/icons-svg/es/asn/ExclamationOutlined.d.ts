import { IconDefinition } from '../types';
declare const ExclamationOutlined: IconDefinition;
export default ExclamationOutlined;
