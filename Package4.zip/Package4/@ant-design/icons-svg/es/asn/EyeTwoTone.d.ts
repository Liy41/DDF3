import { IconDefinition } from '../types';
declare const EyeTwoTone: IconDefinition;
export default EyeTwoTone;
