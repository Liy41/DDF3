import { IconDefinition } from '../types';
declare const BookFilled: IconDefinition;
export default BookFilled;
