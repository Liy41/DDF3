import { IconDefinition } from '../types';
declare const ApiOutlined: IconDefinition;
export default ApiOutlined;
