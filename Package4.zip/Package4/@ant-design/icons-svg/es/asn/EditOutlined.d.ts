import { IconDefinition } from '../types';
declare const EditOutlined: IconDefinition;
export default EditOutlined;
