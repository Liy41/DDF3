import { IconDefinition } from '../types';
declare const FundOutlined: IconDefinition;
export default FundOutlined;
