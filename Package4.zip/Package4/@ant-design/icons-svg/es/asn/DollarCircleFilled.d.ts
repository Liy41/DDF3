import { IconDefinition } from '../types';
declare const DollarCircleFilled: IconDefinition;
export default DollarCircleFilled;
