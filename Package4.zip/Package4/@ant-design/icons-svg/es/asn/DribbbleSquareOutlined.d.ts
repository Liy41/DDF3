import { IconDefinition } from '../types';
declare const DribbbleSquareOutlined: IconDefinition;
export default DribbbleSquareOutlined;
