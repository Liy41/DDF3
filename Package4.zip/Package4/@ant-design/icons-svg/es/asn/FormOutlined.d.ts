import { IconDefinition } from '../types';
declare const FormOutlined: IconDefinition;
export default FormOutlined;
