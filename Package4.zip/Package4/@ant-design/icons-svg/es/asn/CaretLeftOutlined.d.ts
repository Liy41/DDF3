import { IconDefinition } from '../types';
declare const CaretLeftOutlined: IconDefinition;
export default CaretLeftOutlined;
