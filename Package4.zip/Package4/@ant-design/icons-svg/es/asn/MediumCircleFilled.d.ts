import { IconDefinition } from '../types';
declare const MediumCircleFilled: IconDefinition;
export default MediumCircleFilled;
