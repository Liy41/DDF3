import { IconDefinition } from '../types';
declare const ContactsOutlined: IconDefinition;
export default ContactsOutlined;
