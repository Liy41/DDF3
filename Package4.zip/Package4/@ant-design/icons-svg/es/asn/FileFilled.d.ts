import { IconDefinition } from '../types';
declare const FileFilled: IconDefinition;
export default FileFilled;
