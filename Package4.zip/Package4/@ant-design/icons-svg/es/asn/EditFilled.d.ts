import { IconDefinition } from '../types';
declare const EditFilled: IconDefinition;
export default EditFilled;
