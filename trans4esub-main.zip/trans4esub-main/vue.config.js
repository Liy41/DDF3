module.exports = {
    outputDir: 'C://projects/release/nmpa',   //build输出目录
    assetsDir: 'assets', //静态资源目录（js, css, img）
    lintOnSave: false, //是否开启eslint
    publicPath: process.env.VUE_APP_baseURL,
    // publicPath: process.env.environment === 'development' ? '/' : '/',
    productionSourceMap: false,
    devServer: {
        open: false, //是否自动弹出浏览器页面
        host: "localhost", 
        port: '8081', 
        https: false,   //是否使用https协议
        hotOnly: true, //是否开启热更新
        proxy: {
            '/api': {
                target: `https://data42.cn`, //API服务器的地址
                ws: true,  //代理websockets
                changeOrigin: true, // 虚拟的站点需要更管origin
                pathRewrite: {   //重写路径 比如'/api/aaa/ccc'重写为'/aaa/ccc'
                    '^/api': ''
                }
            }
        },
    },

    //webpack配置
	configureWebpack: {
	    //关闭 webpack 的性能提示
	    // performance: {
		//     hints:false
	    // },
 
	    //或者
        output: {
            filename: process.env.production ? `bundle-[chunkHash].js` : `bundle-[hash].js`
        },
	    //警告 webpack 的性能提示
	    performance: {
	    	hints:'warning',
	    	//入口起点的最大体积
	    	maxEntrypointSize: 50000000,
	    	//生成文件的最大体积
	    	maxAssetSize: 50000000,
	    	//只给出 js 文件的性能提示
	    	assetFilter: function(assetFilename) {
	    		return assetFilename.endsWith('.js');
	    	}
	    },
    }

}
