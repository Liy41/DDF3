<?php

include "../config/_init_.php";

cors();
chkJWT();

// Create connection
$conn = new mysqli(JWT_SERVERNAME, JWT_USERID, JWT_PASSWORD, JWT_DBNAME);
$conn->set_charset("utf8");

$res = array('error' => true);

$xltest="OCT dat1e";

$result = $conn->query("SELECT * FROM " . $tbname . " utf8 " . 				
		  " where xltest = '" . $xltest . "'");
		  

$no=$result->num_rows;

if ($no==0){
	$res['Count']=$no;	
}
else
{
	$res['Count']=$no;
}

//close connection and output json object;
$conn -> close();
header("Content-type: application/json");
echo json_encode($res,JSON_UNESCAPED_UNICODE);
die();

?>