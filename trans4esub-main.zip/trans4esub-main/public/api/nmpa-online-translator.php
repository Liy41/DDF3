<?php

    include "../config/_init_.php";

    cors();

    chkJWT();

    $host = "https://free.niutrans.com";
    $path = "/NiuTransServer/translation";
    $apikey = "eb65376772d4b6ee195a8a8e23a582a1";
	$dictNo = "eed8d9d5d4";
	$memoryNo="71c53902f8";
    $src_text=$_POST["src_text"];
    $durl = $host.$path."?from=en&src_text=".urlencode($src_text)."&to=zh&apikey=".$apikey."&dictNo=".$dictNo."&memoryNo=".$memoryNo;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $durl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $res = curl_exec($ch);
	
    curl_close($ch);
	
	//var_dump($res);
		
	header("Content-type: application/json");
	echo json_encode($res,JSON_UNESCAPED_UNICODE);
	die();
?>