import axios from '@/axios';

export default {
    
    handleOnlineTranslation: function (dsorigin, dsclone, record, tbname, index, obj) {
        // console.log(record);
        // var formData = this.toFormData(this.clickedItem);
        // console.log(obj);
        var params = new URLSearchParams();
        params.append("from", "en");
        params.append("to", "zh");
        let xlmodify_pre = record.xlmodify;
        params.append("src_text", record.xltest.replaceAll('####','\n'));
        // params.append(
        //     "jwt-token",
        //     encodeURIComponent(localStorage.getItem("accessToken"))
        //   );
        params.append(
            "Content-Type",
            "“application/x-www-form-urlencoded;charset=utf-8”"
        );

        axios
            .post(`https://data42.cn/api/terms/nmpa-online-translator.php`, params)
            .then((response) => {
                // console.log(JSON.parse(response.data).tgt_text);

                let run_dt = new Date().Format("yyyy-MM-ddThh:mm:ss");
                record.xlmodify = JSON.parse(response.data).tgt_text; //from API return result
                // if (record.xlmodify != xlmodify_pre) {
                    // console.log(record.xlauditlog);
                    // if (record.xlauditlog == null) {
                    //     record.xlauditlog = "Test: ".concat(
                    //         "\n",
                    //         run_dt,
                    //         " machine translated from ",
                    //         xlmodify_pre,
                    //         " ===> ",
                    //         record.xlmodify
                    //     );
                    // }
                    // else {
                    //     record.xlauditlog = record.xlauditlog.concat(
                    //         "\n",
                    //         run_dt,
                    //         " machine translated from ",
                    //         xlmodify_pre,
                    //         " ===> ",
                    //         record.xlmodify
                    //     );
                    // }

                    // this.clickedItem = {};
                    if (response.data.error) {
                        this.errorMessage = response.data.message;
                        // console.log("this is ERROR");
                    } else {
                        this.successMessage = response.data.message;

                        //this.getAllObservations();
                        //save to database in auto save option checked;

                        var params = new URLSearchParams(record);
                        params.append("action", "api-update");
                        params.append("original-term", xlmodify_pre);
                        params.append("userid",localStorage.getItem("userid"));
                        params.append("keytablename", encodeURIComponent(tbname));
                        // params.append(
                        //     "jwt-token",
                        //     encodeURIComponent(localStorage.getItem("accessToken"))
                        //   );
                        // console.log("this is OK");
                        axios
                            .post(
                                `terms/nmpa-dict-update-cell.php`,
                                params
                            )
                            .then((response) => {
                                // console.log(response.data);
                                // console.log(this.dataSource);
                                // this.clickedItem = this.editRow;
                                if (response.data.error) {
                                    this.errorMessage = response.data.message;
                                } else {
                                    this.successMessage = response.data.message;                                 //this.dataSource[index].loading = true;
                                    Object.assign(
                                        dsorigin.filter((item) => item.id === record.id)[0], record);
                                    this.indexClicked = index;

                                    dsclone.filter((item) => item.id === record.id)[0].xlauditlog=response.data.auditlog;
                                    dsclone.filter((item) => item.id === record.id)[0].xlstat='API';
                                    
                                    //console.log(this.dataSource);
                                    //this.$set(this.dataSource, index, this.dataSource[index]);
                                    // this.getAllObservations();
                                }
                            });
                    }
                // }
            });

    },

    handleDictionaryTranslation: function (dsorigin, dsclone, record, tbname, index, obj) {
        // console.log(record);
        // var formData = this.toFormData(this.clickedItem);
        // console.log(obj);
        var params = new URLSearchParams();
        params.append("action", "match-query");
        params.append("from", "en");
        params.append("to", "zh");
        params.append("keytablename", encodeURIComponent(tbname));
        let xlmodify_pre = record.xlmodify;
        params.append("term", encodeURIComponent(record.xltest));
        // params.append(
        //     "jwt-token",
        //     encodeURIComponent(localStorage.getItem("accessToken"))
        //   );
        params.append(
            "Content-Type",
            "“application/x-www-form-urlencoded;charset=utf-8”"
        );

        axios
            .post(`terms/nmpa-dict-translator-match.php`, params)
            .then((response) => {
                // console.log(response.data.records[0]["xlmodify"]);                
                if (response.data.count == 1) {
                    // let run_dt = new Date().Format("yyyy-MM-ddThh:mm:ss");
                    // console.log(response.data);
                    // alert(response.data.count);
                    record.xlmodify = response.data.records[0]["xlmodify"]; //from API return result
                    if (record.xlmodify != xlmodify_pre) {
                        // console.log(record.xlauditlog);
                        // if (record.xlauditlog == null) {
                        //     record.xlauditlog = "Test: ".concat(
                        //         "\n",
                        //         run_dt,
                        //         " dictionary translated from ",
                        //         xlmodify_pre,
                        //         " ===> ",
                        //         record.xlmodify
                        //     );
                        // }
                        // else {
                        //     record.xlauditlog = record.xlauditlog.concat(
                        //         "\n",
                        //         run_dt,
                        //         " dictionary translated from ",
                        //         xlmodify_pre,
                        //         " ===> ",
                        //         record.xlmodify
                        //     );
                        // }

                        this.successMessage = response.data.message;

                        //this.getAllObservations();
                        //save to database in auto save option checked;

                        var params = new URLSearchParams(record);
                        params.append("action", "dict-update");
                        params.append("original-term", xlmodify_pre);
                        params.append("userid",localStorage.getItem("userid"));
                        params.append("keytablename", encodeURIComponent(tbname));
                        // params.append(
                        //     "jwt-token",
                        //     encodeURIComponent(localStorage.getItem("accessToken"))
                        //   );
                        // console.log("this is OK");
                        axios
                            .post(
                                `terms/nmpa-dict-update-cell.php`,
                                params
                            )
                            .then((response) => {
                                // console.log(response.data);
                                // console.log(this.dataSource);
                                // this.clickedItem = this.editRow;
                                if (response.data.error) {
                                    this.errorMessage = response.data.message;
                                } else {
                                    // this.successMessage = response.data.message;                                 //this.dataSource[index].loading = true;
                                    Object.assign(
                                        dsorigin.filter((item) => item.id === record.id)[0], record);                                        
                                        dsclone.filter((item) => item.id === record.id)[0].xlstat='LIBRARY';
                                        dsclone.filter((item) => item.id === record.id)[0].xlauditlog=response.data.auditlog;
                                    // this.indexClicked = index;
                                    //console.log(this.dataSource);
                                    //this.$set(this.dataSource, index, this.dataSource[index]);
                                    // this.getAllObservations();
                                }
                            });

                    }

                }
                else {
                    this.errorMessage = response.data.message;
                }
            });

    },

    getAPIRecords: function (strSearchItem) {
        axios
            .get(
                `nmpa-dict-query.php?action=read&user_name=${encodeURIComponent(
                    strSearchItem
                )}`
            )
            .then((response) => {
                //   console.log(response);
                this.dataSource = response.data.records;
                console.log(this.dataSource);
                //   this.successMessage = response.data.message;
            })
            .catch((error) => {
                console.log(error);
                this.errorMessage = error.data.message;
            });
    },

}

// export default { statusList };



