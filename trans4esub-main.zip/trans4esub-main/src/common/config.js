import axios from "axios";
import moment from 'moment';
export default {

    data() {
        return {
            menuItems: [],
            letterList: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
        }
    },

    columnTermsCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "名称",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "日期",
        //     dataIndex: "xlmodtc",
        //     key: "xlmodtc",
        //     width: 350,
        //     slots: {
        //         customRender: "xlmodtc",
        //     },
        // },
                {
            title: "操作",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnTermsEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Name",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "English Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese Label",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "Date",
        //     dataIndex: "xlmodtc",
        //     key: "xlmodtc",
        //     width: 350,
        //     slots: {
        //         customRender: "xlmodtc",
        //     },
        // },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnGlobalTermsEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Name",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Source",
            dataIndex: "xltest",
            width: 300,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Target",
            dataIndex: "xlmodify",
            width: 300,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            // sortDirections: ['descend', 'ascend'],
            // sorter: (a, b) => a.name.length - b.name.length,
            // sortOrder: sorted.columnKey === 'xlmodify' && sorted.order,
        },

        {
            title: "Create Date",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },     
    ],

    columnGlobalTermsCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "名称",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 300,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 300,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 80,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
            filters:[
                {
                    text:"进行中",
                    value:"ACTIVE"
                },
                {
                    text:"锁定",
                    value:"LOCKED"
                },
                {
                    text:"待定",
                    value:"PENDING"
                },
                {
                    text:"已批",
                    value:"APPROVED"
                },
            ],
            onFilter: (value, record) => record.xlstat.toUpperCase().includes(value),
        },
        {
            title: "更新时间",
            dataIndex: "xlmodtc",
            width: 130,
            key: "xlmodtc",
            slots: {
                customRender: "xlmodtc",
            },
            sorter: (a, b) => {
                a = a.xlmodtc || '';
                b = b.xlmodtc || '';
                return a.localeCompare(b);
            },
            sortDirections: ['descend', 'ascend'],
        },  
        {
            title: "操作",
            dataIndex: "action",
            width: 200,
            slots: {
                customRender: "action",
            },
        },
    ],

    statusList: [
        {
            key: "0-xlstat-label",
            value: "Show All",
            name_cn: "显示全部",
            name_en: "Show All",
        },
        {
            key: "1-xlstat-label",
            value: "Initial",
            name_cn: "初始化",
            name_en: "Initialized",
        },
        // {
        //     key: "2-xlstat-label",
        //     value: "Library",
        //     name_cn: "已库翻",
        //     name_en: "Library Translation",
        // },       
        {
            key: "3-xlstat-label",
            value: "API",
            name_cn: "已机翻",
            name_en: "API Translation",
            
        },
        {
            key: "4-xlstat-label",
            value: "Active",
            name_cn: "进行中",
            name_en: "Ongoing",
        },
        {
            key: "5-xlstat-label",
            value: "Pending",
            name_cn: "待定",
            name_en: "Pending for inputs",
        },
        {
            key: "7-xlstat-label",
            value: "Ready",
            name_cn: "待审核",
            name_en: "Ready for lock",
        },
        {
            key: "8-xlstat-label",
            value: "Locked",
            name_cn: "已锁定",
            name_en: "Locked",
        },
        {
            key: "9-xlstat-label",
            value: "Deleted",
            name_cn: "已删除",
            name_en: "Deleted",
        },
        {
            key: "10-xlstat-label",
            value: "Archived",
            name_cn: "已归档",
            name_en: "Archived",
        },
    ],

    termsCategoryList: [
        {
            key: "1-xltype-dataset-label",
            name_en: "Dataset Labels",
            value: "DS-LABEL",
            name_cn: "数据集标签",
        },
        {
            key: "2-xltype-variable-label",
            name_en: "Variable Labels",
            value: "VAR-LABEL",
            name_cn: "变量标签",
        },{
            key: "3-xltype-variable-logic",
            value: "VAR-LOGIC",
            name_en: "Variable Logics",
            name_cn: "变量衍生逻辑",
        },
        {
            key: "4-xltype-variable-codelist",
            value: "VAR-CODELIST",
            name_en: "Variable Codelist",
            name_cn: "编码列表",
        },
        {
            key: "5-xltype-ct-drugname",
            value: "CT-DRUGNAME",
            name_en: "Drug Terms",
            name_cn: "药品名称集",
        },
        {
            key: "6-xltype-crf-question",
            value: "CRF-Question",
            name_en: "CRF Questions",
            name_cn: "CRF问卷库",
        },
        {
            key: "7-xltype-ct-other",
            name_en: "Other Terms",
            value: "CT-OTHER",
            name_cn: "其他术语集",
        },
        {
            key: "8-xlstat-terms-pending",
            name_en: "Pending Terms",
            value: "TERM-PENDING",
            name_cn: "待审核术语集",
        },
    ],

    columnGlobalVariableLabelCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "名称",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
            slots: {
                filterDropdown: 'filterDropdown',
                filterIcon: 'filterIcon',
                customRender: 'customRender',
              },
              onFilter: (value, record) =>
                record.name.toString().toLowerCase().includes(value.toLowerCase()),
              onFilterDropdownVisibleChange: visible => {
                // if (visible) {
                //   setTimeout(() => {
                //     console.log(searchInput.value);
                //     searchInput.value.focus();
                //   }, 0);
                // }
              },


        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            // sortDirections: ['descend', 'ascend'],
            // sorter: (a, b) => a.name.length - b.name.length,
            // sortOrder: sorted.columnKey === 'xlmodify' && sorted.order,
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "添加时间",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },


        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "操作",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnGlobalVariableLabelEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            // sortDirections: ['descend', 'ascend'],
            // sorter: (a, b) => a.name.length - b.name.length,
            // sortOrder: sorted.columnKey === 'xlmodify' && sorted.order,
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "Create Date",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },


        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "Operation",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],


    columnGlobalTermsPendingCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "名称",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
            slots: {
                filterDropdown: 'filterDropdown',
                filterIcon: 'filterIcon',
                customRender: 'customRender',
              },
            //   onFilter: (value, record) =>
            //     record.name.toString().toLowerCase().includes(value.toLowerCase()),
            //   onFilterDropdownVisibleChange: visible => {
            //     // if (visible) {
            //     //   setTimeout(() => {
            //     //     console.log(searchInput.value);
            //     //     searchInput.value.focus();
            //     //   }, 0);
            //     // }
            //   },

        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            // sortDirections: ['descend', 'ascend'],
            // sorter: (a, b) => a.name.length - b.name.length,
            // sortOrder: sorted.columnKey === 'xlmodify' && sorted.order,
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "更新时间",
            dataIndex: "xlmodtc",
            width: 200,
            key: "xlmodtc",
            slots: {
                customRender: "xlmodtc",
            },
            sorter: (a, b) => {
                a = a.xlmodtc || '';
                b = b.xlmodtc || '';
                return a.localeCompare(b);
            },
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "操作",
            dataIndex: "action",
            width: 150,
            slots: {
                customRender: "action",
            },
        },
    ],

    
    columnGlobalTermsPendingEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Name",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            // sortDirections: ['descend', 'ascend'],
            // sorter: (a, b) => a.name.length - b.name.length,
            // sortOrder: sorted.columnKey === 'xlmodify' && sorted.order,
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "Create Date",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },

        {
            title: "Operation",
            dataIndex: "action",
            width: 150,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnCRFQuestionCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "项目编号",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "研究编号",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        // {
        //     title: "变量名",
        //     dataIndex: "xltestcd",
        //     width: 120,
        //     key: "xltestcd",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "xltestcd",
        //     },
        //     sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
        //     sortDirections: ['descend', 'ascend'],
        // },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "操作",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    
    columnCRFQuestionEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },

        {
            title: "Source",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Target",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnGlobalCRFQuestionCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "添加时间",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "操作",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnVariableLabelCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "项目编号",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "研究编号",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "变量名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文标签",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文标签",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "操作",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnVariableLabelEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "Protocol ID",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "Study ID",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnGlobalVariableLogicCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "变量名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文逻辑",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文逻辑",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "添加时间",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },


        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "操作",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnGlobalVariableLogicEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        // {
        //     title: "Status",
        //     dataIndex: "xlstat",
        //     width: 95,
        //     key: "xlstat",
        //     slots: {
        //         customRender: "xlstat",
        //     },
        // },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "Operation",
        //     dataIndex: "action",
        //     // width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnVariableLogicCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "项目编号",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "研究编号",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },
        {
            title: "变量名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文逻辑",
            dataIndex: "xltest",
            width: 450,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文逻辑",
            dataIndex: "xlmodify",
            width: 450,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 75,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "操作",
            dataIndex: "action",
            width: 150,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnVariableLogicEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "Protocol ID",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "Study ID",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },
        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Logic",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "Operation",
            dataIndex: "action",
            // width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnGlobalVariableLogicCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "变量名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文逻辑",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文逻辑",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "添加时间",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "操作",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnGlobalVariableLogicEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Source",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Target",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "Create Date",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "Operation",
        //     dataIndex: "action",
        //     // width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnGlobalDatasetLabelCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "数据集名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文标签",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文标签",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "添加时间",
            dataIndex: "xlcrdtc",
            width: 200,
            key: "xlcrdtc",
            slots: {
                customRender: "xlcrdtc",
            },
        },

        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "操作",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnGlobalDatasetLabelEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Dataset",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        // {
        //     title: "Status",
        //     dataIndex: "xlstat",
        //     width: 95,
        //     key: "xlstat",
        //     slots: {
        //         customRender: "xlstat",
        //     },
        // },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        // {
        //     title: "Operation",
        //     dataIndex: "action",
        //     width: 350,
        //     slots: {
        //         customRender: "action",
        //     },
        // },
    ],

    columnDatasetLabelCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "项目编号",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "研究编号",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "数据集名",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文标签",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文标签",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "操作",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnDatasetLabelEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "Protocol ID",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "Study ID",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "Variable",
            dataIndex: "xltestcd",
            width: 120,
            key: "xltestcd",
            // ellipsis: true,
            slots: {
                customRender: "xltestcd",
            },
            sorter: (a, b) => a.xltestcd.localeCompare(b.xltestcd),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Label",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Chinese",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        // {
        //     title: "注释",
        //     dataIndex: "xlcomment",
        //     width: 250,
        //     key: "xlcomment",
        // },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],


    columnOtherTermCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "项目编号",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "研究编号",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "英文",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "中文",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "操作",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnOtherTermEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        // {
        //     title: "Protocol ID",
        //     dataIndex: "protocolid",
        //     width: 120,
        //     key: "protocolid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "protocolid",
        //     },
        // },

        // {
        //     title: "Study ID",
        //     dataIndex: "studyid",
        //     width: 120,
        //     key: "studyid",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studyid",
        //     },
        // },

        {
            title: "Source",
            dataIndex: "xltest",
            width: 350,
            key: "xltest",
            // ellipsis: true,
            slots: {
                customRender: "xltest",
            },
            sorter: (a, b) => a.xltest.localeCompare(b.xltest),
            sortDirections: ['descend', 'ascend'],
        },

        {
            title: "Target",
            dataIndex: "xlmodify",
            width: 350,
            key: "xlmodify",
            slots: {
                customRender: "xlmodify",
            },
            sorter: (a, b) => a.xlmodify.localeCompare(b.xlmodify),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Status",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],


    getMenuItems: function () {
        axios.get(`https://data42.cn/api/terms/nmpa-dict-menuitem-list.php`)
            .then(response => {
                // console.log(response);
                menuItems = response.data.records;
                console.log(menuItems);
                //   this.successMessage = response.data.message;
            }).catch(error => {
                console.log(error);
                // this.errorMessage = error.data.message;
            })
    },

    configList: [
        {
            key: "1-user-list",
            value: "user_list",
            name_cn: "用户",
            name_en: "User",
        },
        // {
        //     key: "2-study-info",
        //     value: "study_info",
        //     name_cn: "项目",
        //     name_en: "Project",
        // },     
        // {
        //     key: "3-study-task",
        //     value: "study_task",
        //     name_cn: "任务",
        //     name_en: "Task",
        // },      
        {
            key: "9-user-log",
            value: "user_log_view",
            name_cn: "日志",
            name_en: "Log File",
        },     
    ],

    studyTracker: [
        {
            key: "2-study-info",
            value: "study_info",
            name_cn: "项目",
            name_en: "Project",
        },     
        {
            key: "3-study-task",
            value: "study_task",
            name_cn: "任务",
            name_en: "Task",
        },      
        // {
        //     key: "9-user-log",
        //     value: "user_log_view",
        //     name_cn: "日志",
        //     name_en: "Log File",
        // },     
    ],

    columnUserList: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "用户ID",
            dataIndex: "userid",
            width: 95,
            key: "userid",
            slots: {
                customRender: "userid",
            },
        },
        {
            title: "用户名",
            dataIndex: "username",
            width: 150,
            key: "username",
            // ellipsis: true,
            slots: {
                customRender: "username",
            },
            sorter: (a, b) => a.username.length - b.username.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "注册日期",
            dataIndex: "regdate",
            width: 200,
            key: "regdate",
            slots: {
                customRender: "regdate",
            },
        },
        {
            title: "电子邮件",
            dataIndex: "email",
            width: 250,
            key: "email",
            slots: {
                customRender: "email",
            },
            sorter: (a, b) => a.email.length - b.email.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "部门",
            dataIndex: "department",
            width: 350,
            key: "department",
            slots: {
                customRender: "department",
            },
        },
        {
            title: "管理员",
            dataIndex: "isadmin",
            width: 95,
            key: "isadmin",
            slots: {
                customRender: "isadmin",
            },
        },
        {
            title: "Operation",
            dataIndex: "action",
            width: 350,
            slots: {
                customRender: "action",
            },
        },
    ],
    

    columnUserListEN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "Employee ID",
            dataIndex: "employeeid",
            width: 120,
            key: "employeeid",
            slots: {
                customRender: "employeeid",
            },
            sorter: (a, b) => a.employeeid.length - b.employeeid.length,
            sortDirections: ['descend', 'ascend'],
        },        
        {
            title: "5-2-1 ID",
            dataIndex: "userid",
            width: 100,
            key: "userid",
            slots: {
                customRender: "userid",
            },
            sorter: (a, b) => a.userid.length - b.userid.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Full Name",
            dataIndex: "username",
            width: 120,
            key: "username",
            // ellipsis: true,
            slots: {
                customRender: "username",
            },
            sorter: (a, b) => a.username.length - b.username.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Chinese Name",
            dataIndex: "username_cn",
            width: 120,
            key: "username_cn",
            // ellipsis: true,
            slots: {
                customRender: "username_cn",
            },
            sorter: (a, b) => a.username_cn.length - b.username_cn.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Title",
            dataIndex: "title",
            width: 100,
            key: "title",
            slots: {
                customRender: "title",
            },
            sorter: (a, b) => a.title.length - b.title.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Join Date",
            dataIndex: "hire_dtc",
            width: 200,
            key: "hire_dtc",
            slots: {
                customRender: "hire_dtc",
            },
            sorter: (a, b) => a.hire_dtc.length - b.hire_dtc.length,
            sortDirections: ['descend', 'ascend'],
        },
        // {
        //     title: "E-mail",
        //     dataIndex: "email",
        //     width: 250,
        //     key: "email",
        //     slots: {
        //         customRender: "email",
        //     },
        // },
        {
            title: "Cell Phone",
            dataIndex: "cellphone",
            width: 150,
            key: "cellphone",
            slots: {
                customRender: "cellphone",
            },
        },
        // {
        //     title: "Group",
        //     dataIndex: "department",
        //     width: 120,
        //     key: "department",
        //     slots: {
        //         customRender: "department",
        //     },
        // },
        {
            title: "Manager",
            dataIndex: "opmid",
            width: 100,
            key: "opmid",
            slots: {
                customRender: "opmid",
            },
            sorter: (a, b) => a.opmid.localeCompare(b.opmid),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "Country",
            dataIndex: "country_code",
            width: 75,
            key: "country_code",
            slots: {
                customRender: "country_code",
            },
        },
        {
            title: "Operation",
            dataIndex: "action",
            width: 100,
            slots: {
                customRender: "action",
            },
        },
    ],

    
    columnUserListCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "员工号",
            dataIndex: "employeeid",
            width: 120,
            key: "employeeid",
            slots: {
                customRender: "employeeid",
            },
            sorter: (a, b) => a.employeeid.localeCompare(b.employeeid),
            sortDirections: ['descend', 'ascend'],
        },        
        {
            title: "用户ID",
            dataIndex: "userid",
            width: 100,
            key: "userid",
            slots: {
                customRender: "userid",
            },
            sorter: (a, b) => a.userid.localeCompare(b.userid),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "英文名",
            dataIndex: "username",
            width: 120,
            key: "username",
            // ellipsis: true,
            slots: {
                customRender: "username",
            },
            sorter: (a, b) => a.username.localeCompare(b.username),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "中文名",
            dataIndex: "username_cn",
            width: 120,
            key: "username_cn",
            // ellipsis: true,
            slots: {
                customRender: "username_cn",
            },
            sorter: (a, b) => a.username_cn.localeCompare(b.username_cn),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "职位",
            dataIndex: "title",
            width: 100,
            key: "title",
            slots: {
                customRender: "title",
            },
            sorter: (a, b) =>  a.title.localeCompare(b.title),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "工作日期",
            dataIndex: "hire_dtc",
            width: 200,
            key: "hire_dtc",
            slots: {
                customRender: "hire_dtc",
            },
            sorter: (a, b) =>  moment(a.hire_dtc).unix() - moment(b.hire_dtc).unix(),
            sortDirections: ['descend', 'ascend'],
        },
        // {
        //     title: "E-mail",
        //     dataIndex: "email",
        //     width: 250,
        //     key: "email",
        //     slots: {
        //         customRender: "email",
        //     },
        // },
        {
            title: "联系电话",
            dataIndex: "cellphone",
            width: 150,
            key: "cellphone",
            slots: {
                customRender: "cellphone",
            },
        },
        // {
        //     title: "Group",
        //     dataIndex: "department",
        //     width: 120,
        //     key: "department",
        //     slots: {
        //         customRender: "department",
        //     },
        // },
        {
            title: "直线经理",
            dataIndex: "opmid",
            width: 100,
            key: "opmid",
            slots: {
                customRender: "opmid",
            },
            sorter: (a, b) => a.opmid.localeCompare(b.opmid),
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "国家",
            dataIndex: "country_code",
            width: 75,
            key: "country_code",
            slots: {
                customRender: "country_code",
            },
        },
        {
            title: "操作",
            dataIndex: "action",
            width: 100,
            slots: {
                customRender: "action",
            },
        },
    ],

    columnUserLogCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "登录时间",
            dataIndex: "accessdtc",
            width: 200,
            slots: {
                customRender: "accessdtc",
            },
        },
        {
            title: "登录地址",
            dataIndex: "accessip",
            width: 120,
            key: "accessip",
            slots: {
                customRender: "accessip",
            },
        },
        {
            title: "用户ID",
            dataIndex: "userid",
            width: 95,
            key: "userid",
            slots: {
                customRender: "userid",
            },
        },
        {
            title: "用户名",
            dataIndex: "username",
            width: 120,
            key: "username",
            // ellipsis: true,
            slots: {
                customRender: "username",
            },
            sorter: (a, b) => a.username.length - b.username.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "电子邮件",
            dataIndex: "email",
            width: 200,
            key: "email",
            slots: {
                customRender: "email",
            },
            sorter: (a, b) => a.email.length - b.email.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: "部门",
            dataIndex: "department",
            width: 250,
            key: "department",
            slots: {
                customRender: "department",
            },
        },        
        {
            title: "注册日期",
            dataIndex: "regdate",
            width: 200,
            key: "regdate",
            slots: {
                customRender: "regdate",
            },
        },
    ],

    columnStudyInfoCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
            fixed:'left'
        },
        // {
        //     title: "新药名称",
        //     dataIndex: "brand_name",
        //     width: 100,
        //     key: "brand_name",
        //     slots: {
        //         customRender: "brand_name",
        //     },
        //     fixed:'left'
        // },
        // {
        //     title: "活性成份",
        //     dataIndex: "ingredient_name",
        //     width: 100,
        //     key: "ingredient_name",
        //     slots: {
        //         customRender: "ingredient_name",
        //     },
        //     fixed:'left'
        // },
        {
            title: "项目名称",
            dataIndex: "protocolid",
            width: 100,
            key: "protocolid",
            slots: {
                customRender: "protocolid",
            },
            fixed:'left'
        },
        {
            title: "研究编号",
            dataIndex: "studyid",
            width: 130,
            key: "studyid",
            slots: {
                customRender: "studyid",
            },
            fixed:'left'
        },
        {
            title: "标签",
            dataIndex: "tagname",
            width: 150,
            key: "tagname",
            // ellipsis: true,
            slots: {
                customRender: "tagname",
            },
        },
        {
            title: "治疗领域",
            dataIndex: "taname",
            width: 150,
            key: "taname",
            // ellipsis: true,
            slots: {
                customRender: "taname",
            },
        },
        {
            title: "适应症",
            dataIndex: "indication",
            width: 150,
            key: "indication",
            // ellipsis: true,
            slots: {
                customRender: "indication",
            },
        },
        {
            title: "研究状态",
            dataIndex: "xlstat",
            width: 95,
            key: "xlstat",
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "翻译状态",
            dataIndex: "status",
            width: 95,
            key: "status",
            slots: {
                customRender: "status",
            },
        },
        {
            title: "EDC类型",
            dataIndex: "xledctype",
            width: 95,
            key: "xledctype",
            slots: {
                customRender: "xledctype",
            },
        },
        {
            title: "数据标准",
            dataIndex: "xldttype",
            width: 95,
            key: "xldttype",
            slots: {
                customRender: "xldttype",
            },
        },
        {
            title: "数据说明格式",
            dataIndex: "xlspectype",
            width: 120,
            key: "xlspectype",
            slots: {
                customRender: "xlspectype",
            },
        },
        {
            title: "CRF格式",
            dataIndex: "xlcrftype",
            width: 95,
            key: "xlcrftype",
            slots: {
                customRender: "xlcrftype",
            },
        },
        {
            title: "研究结束日期",
            dataIndex: "xlendtc",
            width: 120,
            key: "xlendtc",
            // ellipsis: true,
            slots: {
                customRender: "xlendtc",
            },
        },
        {
            title: "数据可用日期",
            dataIndex: "xldadtc",
            width: 120,
            key: "xldadtc",
            // ellipsis: true,
            slots: {
                customRender: "xldadtc",
            },
        },
        {
            title: "项目负责人",
            dataIndex: "xltppoc",
            width: 120,
            key: "xltppoc",
            // ellipsis: true,
            slots: {
                customRender: "xltppoc",
            },
        },
        {
            title: "DO联络人",
            dataIndex: "xldopoc",
            width: 120,
            key: "xldopoc",
            // ellipsis: true,
            slots: {
                customRender: "xldopoc",
            },
        },
        {
            title: "SP联络人",
            dataIndex: "xlsppoc",
            width: 120,
            key: "xlsppoc",
            // ellipsis: true,
            slots: {
                customRender: "xlsppoc",
            },
        },
        {
            title: "DM联络人",
            dataIndex: "xldmpoc",
            width: 120,
            key: "xldmpoc",
            // ellipsis: true,
            slots: {
                customRender: "xldmpoc",
            },
        },
        {
            title: "RA联络人",
            dataIndex: "xlrapoc",
            width: 120,
            key: "xlrapoc",
            // ellipsis: true,
            slots: {
                customRender: "xlrapoc",
            },
        },
        {
            title: "CD联络人",
            dataIndex: "xlcdpoc",
            width: 120,
            key: "xlcdpoc",
            // ellipsis: true,
            slots: {
                customRender: "xlcdpoc",
            },
        },
        {
            title: "RWS联络人",
            dataIndex: "xlrwspoc",
            width: 120,
            key: "xlrwspoc",
            // ellipsis: true,
            slots: {
                customRender: "xlrwspoc",
            },
        },
        {
            title: "FSP联络人",
            dataIndex: "xlfsppoc",
            width: 120,
            key: "xlfsppoc",
            // ellipsis: true,
            slots: {
                customRender: "xlfsppoc",
            },
        },
        {
            title: "计划开始日期",
            dataIndex: "xltcdtcp",//translation plan date
            width: 120,
            key: "xltcdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xltcdtcp",
            },
        },
        {
            title: "计划完成日期",
            dataIndex: "xltcdtcp",//translation plan date
            width: 120,
            key: "xltcdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xltcdtcp",
            },
        },
        {
            title: "计划递交日期",
            dataIndex: "xldpdtcp",
            width: 120,
            key: "xldpdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xldpdtcp",
            },
        },
        {
            title: "实际开始日期",
            dataIndex: "xltcdtcp",
            width: 120,
            key: "xltcdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xltcdtcp",
            },
        },
        {
            title: "实际完成日期",
            dataIndex: "xltcdtcp",
            width: 120,
            key: "xltcdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xltcdtcp",
            },
        },
        {
            title: "实际递交日期",
            dataIndex: "xldpdtcp",
            width: 120,
            key: "xldpdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xldpdtcp",
            },
        },
        {
            title: "天数",
            dataIndex: "xldpdtcp",
            width: 120,
            key: "xldpdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xldpdtcp",
            },
        },
        {
            title: "操作",
            dataIndex: "action",
            width: 120,
            slots: {
                customRender: "action",
            },
            fixed:'right'
        },
    ],

    
    columnStudyTaskCN: [
        {
            title: "#",
            dataIndex: "seq",
            width: 60,
            key: "seq",
            // ellipsis: true,
            slots: {
                customRender: "seq",
            },
        },
        {
            title: "项目名称",
            dataIndex: "protocolid",
            width: 120,
            key: "protocolid",
            slots: {
                customRender: "protocolid",
            },
        },
        {
            title: "研究编号",
            dataIndex: "studyid",
            width: 120,
            key: "studyid",
            slots: {
                customRender: "studyid",
            },
        },
        // {
        //     title: "研究名称",
        //     dataIndex: "studytitle",
        //     width: 150,
        //     key: "studytitle",
        //     // ellipsis: true,
        //     slots: {
        //         customRender: "studytitle",
        //     },
        // },
        {
            title: "类别",
            dataIndex: "xltype",
            width: 100,
            key: "xltype",
            // ellipsis: true,
            slots: {
                customRender: "xltype",
            },
        },

        {
            title: "名称",
            dataIndex: "xlcat",
            width: 95,
            key: "xlcat",
            slots: {
                customRender: "xlcat",
            },
        },
        {
            title: "子类别",
            dataIndex: "xlscat",
            width: 95,
            key: "xlscat",
            slots: {
                customRender: "xlscat",
            },
        },
        {
            title: "适用",
            dataIndex: "xlnafl",
            width: 60,
            key: "xlnafl",
            slots: {
                customRender: "xlnafl",
            },
        },
        {
            title: "计划开始",
            dataIndex: "xlstdtcp",
            width: 120,
            key: "xlstdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xlstdtcp",
            },
        },
        {
            title: "计划结束",
            dataIndex: "xlendtcp",
            width: 120,
            key: "xlendtcp",
            // ellipsis: true,
            slots: {
                customRender: "xlendtcp",
            },
        },
        {
            title: "实际开始",
            dataIndex: "xlstdtca",
            width: 120,
            key: "xltcdtcp",
            // ellipsis: true,
            slots: {
                customRender: "xltcdtcp",
            },
        },
        {
            title: "实际结束",
            dataIndex: "xlendtca",
            width: 120,
            key: "xlendtca",
            // ellipsis: true,
            slots: {
                customRender: "xlendtca",
            },
        },   
        {
            title: "负责人",
            dataIndex: "xleditor",
            width: 120,
            key: "xleditor",
            // ellipsis: true,
            slots: {
                customRender: "xleditor",
            },
        },   
        {
            title: "校对人",
            dataIndex: "xlreviewer",
            width: 120,
            key: "xlreviewer",
            // ellipsis: true,
            slots: {
                customRender: "xlreviewer",
            },
        },       
        {
            title: "状态",
            dataIndex: "xlstat",
            width: 80,
            slots: {
                customRender: "xlstat",
            },
        },
        {
            title: "进度",
            dataIndex: "progress",
            width: 120,
            slots: {
                customRender: "progress",
            },
        },
        {
            title: "操作",
            dataIndex: "action",
            width: 120,
            slots: {
                customRender: "action",
            },
        },
    ],
}

// export default { statusList };



