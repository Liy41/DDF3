import EditableCell from './EditableCell.vue';

export { EditableCell };

export default EditableCell;
