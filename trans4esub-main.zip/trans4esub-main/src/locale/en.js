export const m = {
    //table header
    header_variable_name:'Variable',//首页
    header_variable_status:'Status',//研究展示

  }
