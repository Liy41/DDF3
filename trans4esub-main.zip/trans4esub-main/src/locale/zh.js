export const m = {
    //table header
    header_variable_name:'变量名',//首页
    header_variable_status:'状态',//研究展示

  }
