// import { createApp } from 'vue'
// import App from '../App.vue'
import { createRouter, createWebHistory } from "vue-router"
// import About from "../components/About"

// console.log(process.env.VUE_APP_baseURL);

const routeInfos = [
    {
        path: process.env.VUE_APP_baseURL,
        name: "root",
        component: () => import('../views/NMPATranslator.vue')
    },
    {
        path: process.env.VUE_APP_baseURL + "login",
        name: "login",
        alias: "/login",
        component: () => import('../views/Login.vue')
    },
    {
        path: process.env.VUE_APP_baseURL + "nda",
        name: "nda",
        alias: "/nda",
        component: () => import('../views/NDATracker.vue')
    },

    {
        path: process.env.VUE_APP_baseURL + "config",
        name: "config",
        alias: "/config",
        component: () => import('../views/SystemConfig.vue')
    },

 
]

const routerHistory = createWebHistory();

const router = createRouter({
    history: routerHistory,
    // base: process.env.VUE_APP_baseURL,
    mode: 'history',
    routes: routeInfos
})

router.beforeEach((to, from, next) => {

    const userToken = localStorage.getItem('accessToken')

    //console.log("Debug the route link:" + to.path);

    if (!userToken && to.path != (process.env.VUE_APP_baseURL +'login')) {
        next({
            path: process.env.VUE_APP_baseURL + 'login',
            query: { redirect: to.fullpath }
        })
    }
    else if (userToken && to.path === (process.env.VUE_APP_baseURL + 'login')) {
        next({
            path: process.env.VUE_APP_baseURL
        })
    } else {
        next()
    }

});


export default router;