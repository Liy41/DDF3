<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <!-- <DictionaryBrowser /> -->
  <router-view></router-view>
</template>


<script>
// import HelloWorld from './components/HelloWorld.vue'
// import DictionaryItemCrud from  './components/DictionaryItemCrud'
// import NavigatorHome from "./components/NavigatorHome";
// import DictionaryBrowser from "./views/DictionaryBrowser";
// import Assessment from "./views/Assessment";
// import Contacts from "./views/UserInfo";
// import Login from "./views/Login_NDP";
// import DNGB from "./views/NDPTracker";
export default {
  name: "App",
  components: {
    // Contacts,
    // Login,
    // DNGB
    //   DictionaryItemCrud
  },
};
</script>

