<template>
  <a-layout>
    <!-- :style="{ overflow: 'auto', height: '100vh', position: 'fixed', left: 0 }" -->
    <a-layout-sider v-model:collapsed="collapsed" collapsible :trigger="null"        >
      <div class="logo" align="center">{{this.lang==='cn'? '诺 译 通': 'DO Trans4eSub'}}</div>
     <a-menu
        theme="dark"
        mode="inline"
        :openKeys="openKeys"
        v-model:selectedKeys="selectedKeys"
        @openChange="onOpenChange"
        @click="queryTermsByMenuiItems"
      >
        <a-sub-menu key="global-terms-library">
          <template #title>
            <span>
              <StarTwoTone twoToneColor="red"/>
              <span>{{this.lang==='cn'? '翻译字典库': 'Translation Library'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in userconfig.termsCategoryList"
            :key="item.key+'-'+item.value+ '-'+index"
            >{{ this.lang==='cn'? item.name_cn:item.name_en }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-dataset-label">
          <template #title>
            <span>             
              <AppstoreTwoTone />
              <span>{{this.lang==='cn'? '数据集标签': 'Dataset Labels'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-dl' + index"
            >{{ this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-variable-label">
          <template #title>
            <span>
              <DatabaseTwoTone />
              <span>{{this.lang==='cn'? '变量标签': 'Variable Labels'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-vl'+index"
            >{{ this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-variable-logic">
          <template #title>
            <span>
              <ProfileTwoTone twoToneColor="yellow"/>
              <span>{{this.lang==='cn'? '变量衍生逻辑': 'Variable Logics'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-vdl'+index+index"
            >{{ this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-variable-codelist">
          <template #title>
            <span>
              <CopyrightTwoTone twoToneColor="red" />
              <span>{{this.lang==='cn'? '编码列表': 'Variable Codelist'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-cl'+index+index"
            >{{this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>
   

        <a-sub-menu key="study-crf-question">
          <template #title>
            <span>
             <FilePdfTwoTone twoToneColor="red"/>
              <span>{{this.lang==='cn'? 'CRF问卷': 'CRF Questions'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-cq'+index+index"
            >{{this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-crf-annotation">
          <template #title>
            <span>
             <FilePdfTwoTone twoToneColor="red"/>
              <span>{{this.lang==='cn'? 'CRF注释': 'CRF Annotations'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-cq'+index+index"
            >{{this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-ct-drugname">
          <template #title>
            <span>
              <MedicineBoxTwoTone />
              <span>{{this.lang==='cn'? '药品名称': 'Drug Terms'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-dt'+index+index"
            >{{this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="study-ct-other">
          <template #title>
            <span>
             <ReconciliationTwoTone twoToneColor="grey"/>
              <span>{{this.lang==='cn'? '其他术语': 'Other Terms'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in statusList"
            :key="item.key+'-'+item.value+'-ct'+index+index"
            >{{this.lang==='cn'? item.name_cn:item.name_en  }}</a-menu-item
          >
        </a-sub-menu>

      </a-menu>
    </a-layout-sider>
    <!-- :style="{ marginLeft: '200px' }" -->
    <a-layout>
      <a-layout-header
        style="background: #133c61; padding: 0"
        :style="{
          margin: '0px',
          padding: '0px 0px 0px 0px',
          position: 'fixed',
          height:'75px',
          zIndex: 1,
          width: '100%',
        }"
      >
        <menu-unfold-outlined
          v-if="collapsed"
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        />
        <menu-fold-outlined
          v-else
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        />
       
      <!-- <span :style="{margin: '17px 0px 10px 5px', color:'white', fontWeight:'bold'}">{{this.lang==='cn'? '诺译通': 'DO Translator'}}</span> -->
      
      <!-- <span style="margin: 17px 10px 10px 10px;">       
        <a-button type="danger" ghost :loading="reloadStatus" @click="
        this.tagNameSwitchCheck=false; this.reloadStatus=true; 
        this.inputValue=''; getNKCList();
        this.reloadStatus=false"><ReloadOutlined />{{this.lang==='cn'? 'Reload': 'Reload'}}</a-button>
      </span> -->

        <span style="color:#40a9ff">&nbsp;&nbsp;{{this.lang==='cn'? '研究编号:': 'Study ID:'}}&nbsp;&nbsp;</span>
        <a-select v-model:value="userProtocolID" style="width: 125px; margin:2px" ref="select" @change="handleUserProtocolSelect">
          <a-select-option v-for="protocol in userProtocolList" :key="protocol">
          {{ protocol }}
          </a-select-option>
        </a-select>
        <a-select v-model:value="userStudyID" style="width: 150px; margin:2px" ref="select" @change="handleSearchInput">
          <!-- <a-select-option disabled value="null">请选择项目</a-select-option> -->
          <a-select-option v-for="study in userStudyList" :key="study">
          {{ study }}
          </a-select-option>
        </a-select>

        
        <!-- <a-button v-if="(isAdmin===true || isGlobalTerms===false)"
          style="margin: 20px 2px 10px 2px; float: center"
          type="primary" 
          ghost
          @click="showDrawerNew"
          ><PlusOutlined /></a-button
        > -->

        <!-- <a-popconfirm
          v-if="selectedRowKeys != '' && (isAdmin===1 || isGlobalTerms===false)"
          title="您确定要删除所选术语吗?"
          @confirm="removeAllItem(this.state.selectedRowKeys)"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary"
            ghost
            ><MinusOutlined /></a-button
          >
        </a-popconfirm> -->

        <a-popconfirm          
          title="您确定用字典库翻译所选术语吗?"
          @confirm="handleDictionaryTranslationBatch(this.state.selectedRowKeys)"
        >
          <a-button v-if="selectedRowKeys != '' && isGlobalTerms===false && ['SHOW', 'LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1"
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" 

            ><TranslationOutlined />{{this.lang==='cn'? '库翻': 'G-DICT'}}</a-button
          >
          <a-button v-else disabled
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" 
 
            ><TranslationOutlined />{{this.lang==='cn'? '库翻': 'G-DICT'}}</a-button
          >
        </a-popconfirm>

        <!-- <a-popconfirm
          v-if="selectedRowKeys != '' && (isGlobalTerms===false)"
          title="您确定用项目组已锁定术语库翻译所选术语吗?"
          @confirm="showGroupTranslationModal()"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" 
            ghost
            ><TranslationOutlined />{{this.lang==='cn'? '组翻': 'S-DICT'}}</a-button
          >
        </a-popconfirm> -->

        <a-button v-if="selectedRowKeys != '' && isGlobalTerms===false && ['SHOW', 'LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1"
          style="margin: 20px 2px 10px 2px; float: center"
          type="primary" danger
          
          @click="showGroupTranslationModal()"
          ><TranslationOutlined />{{this.lang==='cn'? '组翻': 'S-DICT'}}</a-button
        >
        <a-button v-else disabled
          style="margin: 20px 2px 10px 2px; float: center"
          type="primary" danger
          
          @click="showGroupTranslationModal()"
          ><TranslationOutlined />{{this.lang==='cn'? '组翻': 'S-DICT'}}</a-button
        >

        <a-popconfirm          
          title="您确定在线翻译所选术语吗?（不超过2000字符）"
          @confirm="handleAPITranslationBatch(this.state.selectedRowKeys)"
        >
          <a-button v-if="selectedRowKeys != '' && isGlobalTerms===false && ['SHOW', 'LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1"
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" danger 
            
            ><RobotOutlined />{{this.lang==='cn'? '机翻': 'API'}}</a-button
          >
          <a-button v-else disabled
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" danger 
            
            ><RobotOutlined />{{this.lang==='cn'? '机翻': 'API'}}</a-button
          >
        </a-popconfirm>

        <!-- <a-button 
          style="margin: 20px 2px 10px 2px; float: center"
          type="danger"           
          @click="editVisibleBasic= true; this.strNewOrEdit='New';"
          ><PlusOutlined />New</a-button
        > -->

        <a-dropdown :trigger="['click']" >  <a >
            &nbsp;  <DownOutlined />
          </a>
          <template #overlay>
            <a-menu>
              <a-menu-item key="6" @click="handleMyAssignments"><FieldTimeOutlined />&nbsp;{{this.lang==='cn'? '我的审阅任务': 'My review assignments'}}</a-menu-item>

              <hr>
              <a-menu-item key="6" @click="sendSelectedItemsByEmail('')"><MailOutlined />&nbsp;{{this.lang==='cn'? '发送选定术语至本人邮箱': 'Send selected to me'}}</a-menu-item>
              <a-menu-item key="6" @click="showTaskAssignModal"><MailOutlined />&nbsp;{{this.lang==='cn'? '发送选定术语至审阅者邮箱': 'Send selected to reviewer'}}</a-menu-item>
              <hr>
             <a-menu-item key="61" @click="selectAllItems()"><CheckSquareOutlined />&nbsp;{{this.lang==='cn'? '全部选定': 'Select all'}}</a-menu-item>
              <a-menu-item key="62" @click="clearSelection()"><CloseSquareOutlined />&nbsp;{{this.lang==='cn'? '清除选定': 'Clear selection'}}</a-menu-item>
 
              <hr v-if="isGlobalTerms===false && queryKeyValue != 'DELETED' && queryKeyValue != 'ARCHIVED'">
              <a-menu-item v-if="isGlobalTerms===false &&  ['LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1" key="6"  @click="pendingAllItems(this.state.selectedRowKeys)"><InfoCircleOutlined />&nbsp;{{this.lang==='cn'? '设置选定术语为待定状态': 'Set Status as Pending'}}</a-menu-item>
              <a-menu-item v-if="isGlobalTerms===false &&  ['LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1" key="6"  @click="readyForQCAllItems(this.state.selectedRowKeys)"><EyeOutlined />&nbsp;{{this.lang==='cn'? '设置选定术语为待审状态': 'Set Status as Ready for QC'}}</a-menu-item>              
              <a-menu-item v-if="isGlobalTerms===false &&  ['LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1" key="6"  @click="lockAllItems(this.state.selectedRowKeys)"><LockOutlined />&nbsp;{{this.lang==='cn'? '锁定选定术语': 'Lock Selected Terms'}}</a-menu-item>   
            
              <a-menu-item v-if="isGlobalTerms===false && queryKeyValue != 'DELETED' && queryKeyValue != 'ARCHIVED'" key="6"  @click="unlockAllItems(this.state.selectedRowKeys)"><UnlockOutlined />&nbsp;{{this.lang==='cn'? '解锁选定术语': 'Unlock Selected Terms'}}</a-menu-item> 
              <a-menu-item v-else-if="isGlobalTerms==true && isAdmin==1" key="61"  @click="unlockAllItems(this.state.selectedRowKeys)"><UnlockOutlined />&nbsp;{{this.lang==='cn'? '解锁选定术语': 'Unlock Selected Terms'}}</a-menu-item> 

              <a-menu-item v-if="queryKeyValue == 'LOCKED'" key="6"  @click="archiveAllItems(this.state.selectedRowKeys)"><FileProtectOutlined />&nbsp;{{this.lang==='cn'? '归档选定术语': 'Archive Selected Terms'}}</a-menu-item>  
             
              <hr v-if="isGlobalTerms===false &&  ['LOCKED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1">
              <a-menu-item v-if="isGlobalTerms===false && ['LOCKED', 'DELETED', 'ARCHIVED'].indexOf(queryKeyValue.toUpperCase()) ==-1" key="6" @click="removeAllItem(this.state.selectedRowKeys, 'LOGICAL')"><ExportOutlined />&nbsp;{{this.lang==='cn'? '删除选定术语（逻辑）': 'Delete Terms Logically'}}</a-menu-item>
              <a-menu-item v-if="isGlobalTerms===false && queryKeyValue=='DELETED'" key="6" @click="removeAllItem(this.state.selectedRowKeys, 'PHYSICAL')"><DeleteOutlined />&nbsp;{{this.lang==='cn'? '删除选定术语（物理）': 'Delete Terms Physically'}}</a-menu-item>
              <a-menu-item v-if="isGlobalTerms===false && queryKeyValue=='DELETED' " key="6" @click="undeleteAllItem(this.state.selectedRowKeys, 'PHYSICAL')"><UndoOutlined />&nbsp;{{this.lang==='cn'? '恢复删除术语': 'Recover Terms Physically'}}</a-menu-item>

              <!-- <a-menu-item key="7" @click="showUploadModal"><UploadOutlined />{{this.lang==='cn'? '术语上传': 'Upload terms'}}</a-menu-item>
              <a-menu-item key="7" @click="showUploadModal"><UploadOutlined />{{this.lang==='cn'? '术语备份': 'Backup terms'}}</a-menu-item> -->
              <!-- <hr>             
              <a-menu-item v-if="isAdmin==1" key="12" @click="handleUserLogConfig"><UploadOutlined />{{this.lang==='cn'? '用户与日志': 'User Log File'}}</a-menu-item> -->
            </a-menu>
          </template>
        </a-dropdown>

        <span style="position: absolute; right:0; padding: 28px 600px 0px 0px"> 
          <a-statistic-countdown title="" :value="dueDate" @finish="onFinish" format="Exp: H:mm:ss" />
        </span>
        <span style="position: absolute; right:0; padding: 24px 375px 0px 0px"> 
          <a-input-search
            style="margin: 0px; width: 200px; float: center"
            v-model:value="inputValue"
            allow-clear
            placeholder=""
            enter-button
            @change="handleSearchInput"
            @search="handleSearchInput"
          />
          &nbsp;
        </span>
          <span style="position: absolute; right:0; padding: 7px 250px 0px 0px">
              <a-dropdown v-if="isLogin=true" :trigger="['click']" >  <a >
                <UserOutlined/>&nbsp;{{strUserName}}<DownOutlined />&nbsp;&nbsp;
                </a>
                <template #overlay>
                  <a-menu>
                                  
                    <!-- <a-menu-item key="1" @click="exportSelectedItemsAsXLS"><ExportOutlined />{{this.lang==='cn'? '导出为Excel文件': 'Export as Excel (.xlsx)'}}</a-menu-item> -->
                    <a-menu-item key="2" @click="exportSelectedItemsAsCSV"><ExportOutlined />&nbsp;{{this.lang==='cn'? '导出为csv格式文本文件': 'Export as comma seperated text file (.csv)'}}</a-menu-item>
                    <a-menu-item key="3" @click="exportSelectedItemsAsTAB"><ExportOutlined />&nbsp;{{this.lang==='cn'? '导出为Tab分隔文本文件': 'Export as TAB seperated text file (.txt)'}}</a-menu-item>
                    <a-menu-item key="4" @click="exportSelectedItemsAsXNDICT"><ExportOutlined />&nbsp;{{this.lang==='cn'? '导出为API字典文件': 'Export as API Dictionary (.txt)'}}</a-menu-item>
                    <a-menu-item key="5" @click="exportSelectedItemsAsSAS"><ExportOutlined />&nbsp;{{this.lang==='cn'? '导出为SAS程序文件': 'Export as SAS program (.sas)'}}</a-menu-item>
                    <!-- <a-menu-item key="6" @click="exportSelectedItemsByEmail"><MailOutlined />{{this.lang==='cn'? '邮件发送选定': 'Send by Email'}}</a-menu-item> -->
                    <hr>
            
                    <a-menu-item key="7" @click="showUploadModal"><UploadOutlined />&nbsp;{{this.lang==='cn'? '术语上传与恢复': 'Upload terms & Restore'}}</a-menu-item>
                    <a-menu-item key="8" @click="backupSelectedItemsAsCSV"><DownloadOutlined />&nbsp;{{this.lang==='cn'? '术语备份 (csv)': 'Backup terms as CSV'}}</a-menu-item>
                    <a-menu-item key="9" @click="backupSelectedItemsAsXLS"><DownloadOutlined />&nbsp;{{this.lang==='cn'? '术语备份 (xlsx)': 'Backup terms as XLSX'}}</a-menu-item>
                    <hr>             

                    <a-menu-item key="11" @click="handleNewStudy"><PlusOutlined />&nbsp;{{this.lang==='cn'? '添加项目': 'Add Project'}}</a-menu-item>
                    
                    <a-menu-item v-if="isAdmin==1" key="12" @click="handleUserProfile"><SmileTwoTone />&nbsp;{{this.lang==='cn'? '用户信息': 'User Log File'}}</a-menu-item>

                    <a-menu-item v-if="isAdmin==1" key="12" @click="handleUserAssessment"><SmileTwoTone />&nbsp;{{this.lang==='cn'? '测评信息': 'User Assessment'}}</a-menu-item>

                    <a-menu-item v-if="isAdmin==1" key="15" @click="handleUserLogConfig"><SmileTwoTone />&nbsp;{{this.lang==='cn'? '用户日志': 'User Log File'}}</a-menu-item>

                    <a-menu-item key="1" @click="this.lang==='cn'?changeLocale('en'):changeLocale('cn')"><TranslationOutlined />&nbsp;{{this.lang==='cn'? '切换语言': 'Switch to Chinese'}}</a-menu-item>
                    <a-menu-item key="22" @click="showingPasscodeModal=true"><KeyOutlined />&nbsp;{{this.lang==='cn'? '设置登录PIN码': 'Set Login Pin Code'}}</a-menu-item>
                    <a-menu-item key="23" @click="logout"><LoginOutlined />&nbsp;{{this.lang==='cn'? '注销': 'Log out'}}</a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>

             <img v-if="collapsed" src="../assets/novartis-logo01.svg" alt="" width="150" 
                    style="position: absolute; right:100px; padding: 20px 0px 0px 0px">
          </span>
                       
        <template>
          <div>
            <a-modal v-model:visible="showingPasscodeModal" title="Set or update your pin code" @ok="updatePasscode(userPasscode)">
              <p>{{this.lang==='cn'? '请输入您的PIN码 (6位数字)：': 'Please enter 6-digit pin code:'}}</p>
              <a-input v-model:value="userPasscode" placeholder="Your 6-digit PIN Code" 
              />
              <p></p>
              <a-button 
              type="danger"  @click="generatePasscode">{{this.lang==='cn'? '随机PIN码': 'Random Code'}}
          </a-button>
            </a-modal>
          </div>
        </template>

    
        <template>
        <div>
          <a-modal v-model:visible="showingWhiteBoardModal" title="翻译审阅人员设置：" 
            @ok="addNewTopic()">
            <p>请选择审阅人：
            <a-button class="ant-layout-header-searchbar-btn-link"  @click="selectedUserList=[]">清除选定</a-button>
            </p>
              <a-select
                mode="multiple"
                placeholder=""
                v-model:value="selectedUserList"
                style="width: 90%" >                
                  <a-select-option v-for="item, index in globalUserList" :key="index" :value="item.userid">
                  {{ item.department }} &nbsp; | &nbsp; {{ item.username }}
                </a-select-option>
              </a-select>
            <p></p>
            
          </a-modal>
        </div>
      </template>
      
        <template>
          <div>
            <a-modal v-model:visible="showingTaskAssignModal" title="翻译审阅人员设置：" 
              @ok="updateTermsReviewer((this.state.selectedRowKeys))">
              <p>请选择审阅人：
              <a-button class="ant-layout-header-searchbar-btn-link"  @click="selectedUserList=[]">清除选定</a-button>
              </p>
                <a-select
                  mode="multiple"
                  placeholder=""
                  v-model:value="selectedUserList"
                  style="width: 90%" >                
                    <a-select-option v-for="item, index in globalUserList" :key="index" :value="item.userid">
                    {{ item.department }} &nbsp; | &nbsp; {{ item.username }}
                  </a-select-option>
                </a-select>
              <p></p>
              
            </a-modal>
          </div>
        </template>

        <template>
          <div>
            <a-modal v-model:visible="showingVariableValueListModal" title="变量值列表：" 
              @ok="showingVariableValueListModal=false">
              <p>
                <pre><a-textarea readonly="true" rows="10" cols="50" v-model:value="selectedVariableValueList"></a-textarea></pre>
              </p>
              <p></p>
              
            </a-modal>
          </div>
        </template>

        <template>
          <div>
            <a-modal v-model:visible="showingGroupTranslationModal" title="请选择一个或多个项目用于当前项目组翻译：" 
              @ok="handleTermsTranslationBatch(this.state.selectedRowKeys,selectedProjectList)">
              <p>请选择项目（如使用全部项目，可留空）：
              <a-button class="ant-layout-header-searchbar-btn-link"  @click="selectedProjectList=[]">清除选定</a-button>
              </p>
                <a-select
                  mode="multiple"
                  placeholder=""
                  v-model:value="selectedProjectList"
                  style="width: 90%" >                
                    <a-select-option v-for="item, index in globalProtocolList" :key="index" :value="item">
                    {{ item }}
                  </a-select-option>
                </a-select>
              <p></p>
              
            </a-modal>
          </div>
        </template>

        <template>
          <a-drawer
            title="Upload Terms"
            :width="450"
            :visible="uploadVisible"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="form" layout="vertical">

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item v-if="this.lang==='en'" label="Access" name="xlaccess">
                    <div>
                      <a-radio-group  v-model:value="uploadTermAccess">
                        <a-radio :value=1>Public</a-radio>
                        <a-radio :value=2>Organization</a-radio>
                        <a-radio :value=3>Private</a-radio>
                      </a-radio-group>
                    </div>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn'"  label="访问权限" name="xlaccess">
                    <div>
                      <a-radio-group v-model:value="uploadTermAccess">
                        <a-radio :value=1>公开</a-radio>
                        <a-radio :value=2>组织</a-radio>
                        <a-radio :value=3>私有</a-radio>
                      </a-radio-group>
                    </div>
                  </a-form-item>
                 </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item v-if="this.lang==='en'" label="Scope & Category" name="xlscat">
                    <div>
                      <a-radio-group v-model:value="uploadTermScope">
                        <a-radio v-if="isAdmin ==1" :style="radioStyle" :value=1>Global Library</a-radio>
                        <a-radio :style="radioStyle" :value=2>Study Library</a-radio>
                        <a-radio :style="radioStyle" :value=3>User Library</a-radio>
                        <!-- <a-radio :style="radioStyle" :value=4>Other
                          <a-input v-if="uploadTermScope === 4" style="width: 200px; margin-left: 20px" />
                        </a-radio> -->
                      </a-radio-group>
                    </div>                    
                    <a-select
                      placeholder="Please select terms category"
                      v-model:value="uploadTermCategory" >
                      <a-select-option value="dataset-label">Dataset Label</a-select-option>
                      <a-select-option value="variable-label">Variable Label</a-select-option>
                      <a-select-option value="variable-logic">Variable Logic</a-select-option>
                      <a-select-option value="variable-codelist">Variable Codelist</a-select-option>
                      <a-select-option value="crf-question">CRF Question</a-select-option>
                      <a-select-option value="ct-drugname">Medication Term</a-select-option>
                      <a-select-option value="ct-other">Other Term</a-select-option>
                    </a-select>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn'" label="术语分级与类别" name="xlscat">
                    <div>
                      <a-radio-group v-model:value="uploadTermScope">
                        <a-radio v-if="isAdmin ==1" :style="radioStyle" :value=1>全局术语库</a-radio>
                        <a-radio :style="radioStyle" :value=2>项目术语集</a-radio>
                        <a-radio :style="radioStyle" :value=3>用户术语集或备份术语集</a-radio>
                        <!-- <a-radio :style="radioStyle" :value=4>Other
                          <a-input v-if="uploadTermScope === 4" style="width: 200px; margin-left: 20px" />
                        </a-radio> -->
                      </a-radio-group>
                    </div>                    
                    <a-select
                      placeholder="术语分类"
                      v-model:value="uploadTermCategory" >
                      <a-select-option value="dataset-label">数据集标签</a-select-option>
                      <a-select-option value="variable-label">变量标签</a-select-option>
                      <a-select-option value="variable-logic">变量逻辑</a-select-option>
                      <a-select-option value="variable-codelist">变量编码列表</a-select-option>
                      <a-select-option value="variable-valuelist">变量值列表</a-select-option>
                      <a-select-option value="crf-question">CRF病例报告表</a-select-option>
                      <a-select-option value="ct-drugname">药品名称</a-select-option>
                      <a-select-option value="ct-other">其他术语</a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item v-if="this.lang==='en' && (uploadTermCategory !='ct-drugname' && uploadTermCategory !='ct-other')" label="Terms Type" name="xltype">                   
                    <a-select
                      placeholder="Please select terms type"
                      v-model:value="uploadTermType" >
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist')" value="cdisc-raw">SDTM Dataset</a-select-option>
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist')" value="cdisc-analysis)">ADaM Dataset</a-select-option>
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist')" value="legacy-raw)">Legacy Raw Dataset</a-select-option>
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist')" value="legacy-analysis)">Legacy Analysis Dataset</a-select-option>
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='crf-question')" value="questionnaire">QRS Question</a-select-option>
                      <a-select-option v-if="this.lang==='en' && (uploadTermCategory ==='crf-question')" value="general">General Question</a-select-option>
                    </a-select>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn' && (uploadTermCategory !='ct-drugname' && uploadTermCategory !='ct-other')" label="术语子分类" name="xltype">                   
                    <a-select
                      placeholder="Please select terms type"
                      v-model:value="uploadTermType" >
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist' || uploadTermCategory ==='variable-valuelist')" value="general">通用数据集</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist' || uploadTermCategory ==='variable-valuelist')" value="cdisc-raw">SDTM原始数据集</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist' || uploadTermCategory ==='variable-valuelist')" value="cdisc-analysis">ADaM分析数据集</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist' || uploadTermCategory ==='variable-valuelist')" value="legacy-raw">非标准格式原始数据集</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='dataset-label' || uploadTermCategory ==='variable-label' || uploadTermCategory ==='variable-logic' || uploadTermCategory ==='variable-codelist' || uploadTermCategory ==='variable-valuelist')" value="legacy-analysis">非标准格式分析数据集</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='crf-question')" value="questionnaire">QRS量表问卷</a-select-option>
                      <a-select-option v-if="this.lang==='cn' && (uploadTermCategory ==='crf-question')" value="general">CRF通用问题描述</a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item v-if="this.lang==='en' && uploadTermScope === 2" label="Protocol ID" name="protocolid">
                    <a-select v-model:value="uploadProtocolID" style="width: 161px" ref="select"
                               @change="handleProtocolSelect">
                      <a-select-option v-for="study in globalProtocolList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn' && uploadTermScope === 2" label="项目名称" name="protocolid">
                    <a-select v-model:value="uploadProtocolID" style="width: 161px" ref="select"
                               @change="handleProtocolSelect">
                      <a-select-option v-for="study in globalProtocolList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item v-if="this.lang==='en' && (uploadTermScope === 2)" label="Study ID" name="studyid">
                    <a-select v-model:value="uploadStudyID" style="width: 150px" ref="select"
                               @change="handleStudySelect">
                      <a-select-option v-for="study in globalStudyList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn' && (uploadTermScope === 2)" label="研究编号" name="studyid">
                    <a-select v-model:value="uploadStudyID" style="width: 150px" ref="select"
                               @change="handleStudySelect">
                      <a-select-option v-for="study in globalStudyList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item v-if="this.lang==='en' && (uploadTermScope != 2)"
                    label="Protocol ID | Study ID"
                    name="xlstudyid"
                  >
                    <a-input
                      v-model:value="uploadDescription"                      
                      placeholder="<User ID> | <File name> be used when left blank"
                    />
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn' && (uploadTermScope != 2)"
                    label="项目名称 | 研究编号"
                    name="xlstudyid"
                  >
                    <a-input
                      v-model:value="uploadDescription"                      
                      placeholder="默认为 <用户名> | <文件名> "
                    />
                    <p :style="{
                    margin: '0px 0px 0px 0px',
                    padding: '10px 0px 0px 0px',
                    position: 'relative',
                    zIndex: 1,
                    width: '100%',
                    color: 'red',
                  }">注：如上传文件中包含项目信息，请跳过此设置</p>
                  </a-form-item>
                </a-col>
              </a-row>
              
              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item v-if="this.lang==='en'" label="Comment" name="xlcomment">
                    <a-input
                      placeholder="Enter general default comment if necessary"
                      v-model:value="uploadComment"
                    />               
                  </a-form-item>
                  <a-form-item v-else label="备注" name="xlcomment">
                    <a-input
                      placeholder="必要时可输入通用注释信息"
                      v-model:value="uploadComment"
                    />               
                  </a-form-item>

                  <a-form-item v-if="this.lang==='en'" label="Skip duplicates" name="removeDuplicate">
                    <div>
                      <a-radio-group v-model:value="uploadFileWithoutDuplicate">
                        <a-radio :value=1>Yes</a-radio>
                        <a-radio :value=2>No</a-radio>
                      </a-radio-group>
                    </div>
                  </a-form-item>
                  <a-form-item v-else-if="this.lang==='cn'" label="忽略重复值" name="removeDuplicate">
                    <div>
                      <a-radio-group v-model:value="uploadFileWithoutDuplicate">
                        <a-radio :value=1>是</a-radio>
                        <a-radio :value=2>否</a-radio>
                      </a-radio-group>
                    </div>
                  </a-form-item>

                      <span>
                      <a-progress type="circle" :percent="defaultPercent" :width="30" />
                      </span> &nbsp;&nbsp;
                  <a-upload
                        v-model:file-list="uploadFile"
                        name="file"
                        :multiple="false"
                        :showUploadList="false"
                        method="post"
                        :headers="headers"
                        :beforeUpload="beforeUpload"
                        :customRequest="uploadTerms"
                        @change="handleUploadChange"
                        accept=".csv, .txt"
                        >                     
                      <a-button>
                      <UploadOutlined />{{this.lang==='cn'? '上传': 'Upload'}}
                      </a-button>
                  </a-upload>
                  &nbsp;&nbsp;                                
                
                       &nbsp;&nbsp;
                      <a-button style="margin-right: 8px" @click="onCloseEdit" >{{this.lang==='cn'? '取消': 'Cancel'}}</a-button>
                </a-col>
              </a-row>
              <a-row :gutter="20">
                <a-col :span="40">
                  <div :style="{
                    margin: '0px 0px 0px 0px',
                    padding: '10px 0px 0px 0px',
                    position: 'relative',
                    zIndex: 1,
                    width: '100%',
                  }"><a v-if="this.lang==='en'"><br>Notes: <br> 
                        <li>1. Up to four columns to be imported only.</li> 
                        <li>2. Only column name TYPE, NAME, LABEL/SOURCE and TARGET are recognized.</li>
                        <li>3. Column name/value should be ordered as TYPE, NAME, LABEL/SOURCE, TARGET when provided.</li>
                        <li>4. Column name/value must be tab-seperated (.txt) or comma-seperated (.csv).</li>
                      </a>
                      <a v-else-if="this.lang==='cn'"><br>上传文件格式要求: <br> 
                        <li>1. 包含至少一列，最多四列</li> 
                        <li>2. 首行如为列名，应为TYPE, NAME, LABEL/SOURCE或TARGET</li>
                        <li>3. 列名及值请请按类型（可选）、名称（可选）、标签（必需）与目标（可选）依次提供</li>
                        <li>4. 需为制表符分隔值 (.txt) 或逗号分隔值 (.csv)格式文本文件</li>
                      </a>
                    </div>
                </a-col>
              </a-row>
            </a-form>
            <!-- <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseEdit"
                >Cancel</a-button
              >
              <a-button type="primary" @click="onCloseEdit">Submit</a-button>
            </div> -->
          </a-drawer>
        </template>

        <template>
          <a-drawer
            title="添加新术语"
            :width="450"
            :visible="newVisible"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="formNew" layout="vertical">
              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目名称" name="protocolid">
                    <a-input
                      v-model:value="formNew.protocolid" disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="项目名称"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号" name="studyid">
                    <a-input
                      v-model:value="formNew.studyid" disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="研究编号"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="术语名称（可选）" name="xltestcd">
                    <a-input
                      v-model:value="formNew.xltestcd"
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="术语名称（例如：变量名、数据集名）"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="原文描述"
                    name="xltest"
                  >
                    <a-input
                      v-model:value="formNew.xltest"
                      placeholder="术语原文描述"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="中文名称" name="xlmodify">
                    <a-input
                      v-model:value="formNew.xlmodify"
                      placeholder="术语中文名"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="术语分类" name="xlcat">
                    <a-input
                      v-model:value="formNew.xlcat" disabled
                      placeholder="please enter item category"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="术语子类别" name="xlscat">
                    <a-input
                      v-model:value="formNew.xlscat" disabled
                      placeholder="please enter item sub category"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="注释" name="xlcomment">
                    <a-input
                      placeholder="术语注释"
                      v-model:value="formNew.xlcomment"
                    />
                  </a-form-item>
                </a-col>
              </a-row>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseNew"
                >Cancel</a-button
              >
              <a-button type="primary" @click="onSubmitNew">Submit</a-button>
            </div>
          </a-drawer>
        </template>

        <template>
          <a-drawer
            title="编辑术语"
            :width="450"
            :visible="editVisible"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="form" layout="vertical">
              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目名称" name="protocolid">
                    <a-input
                      v-model:value="form.protocolid"
                      disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="please enter protocol ID"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号" name="studyid">
                    <a-input
                      v-model:value="form.studyid"
                      disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="please enter study ID"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="术语名称" name="xltestcd">
                    <a-input
                      v-model:value="form.xltestcd"
                      disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="（可选）"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="原文描述"
                    name="xltest"
                  >
                    <a-input
                      v-model:value="form.xltest"
                      disabled
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="中文翻译" name="xlmodify">
                    <a-input
                      v-model:value="form.xlmodify"
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="术语类别" name="xlcat">
                    <a-input
                      v-model:value="form.xlcat"
                      disabled
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="术语子类" name="xlscat">
                    <a-input
                      v-model:value="form.xlscat"
                      disabled
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="术语状态" name="xlstat">
                    <a-select
                      placeholder="请选择："
                      v-model:value="form.xlstat"
                    >
                      <a-select-option value="ACTIVE">进行中</a-select-option>
                      <a-select-option value="PENDING"
                        >待定</a-select-option
                      >
                      <a-select-option value="READY"
                        >已审核
                      </a-select-option>
                      <a-select-option value="LOCKED">已锁定</a-select-option>/
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="最后编辑用户" name="xlmouser">
                    <a-input
                      v-model:value="form.xlmouser"
                      disabled
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="最后修改时间" name="xlmodtc">
                    <a-input
                      v-model:value="form.xlmodtc"
                      disabled
                      placeholder=""
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="注释" name="xlcomment">
                    <a-input
                      placeholder=""
                      v-model:value="form.xlcomment"
                    />
                  </a-form-item>
                </a-col>
              </a-row>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseEdit"
                >取消</a-button
              >
              <a-button type="primary" @click="onSubmitEdit">保存</a-button>
            </div>
          </a-drawer>
        </template>
        <!-- <a style="margin:4px 5px 15px 20px; float: center; color: red">Total records: {{dataSource.length}}</a> -->


        <template>
               
          <a-drawer
            title="请选择合适的翻译平台结果:"
            :width="450"
            :visible="translationFormVisible"
            :destroyOnClose="true"
            placement="left"
            :body-style="{ paddingBottom: '20px' }"
            @close="onCloseNew"
          >
            <a-form :model="form" layout="vertical">
               <a-spin tip="正在翻译..." :spinning="isLoadingTranslation">
              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="翻译原文 (Source)" name="xltest">
                    <a-input
                      v-model:value="form.xltest"
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="原文"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="翻译结果 (Translation from Xiaoniu API)"
                    name="xn-result"
                  >
                 
                    <a-input
                      v-model:value="formTranslationResults.xlmodifyxn"
                      placeholder="小牛翻译结果"
                    /> <a-button style="margin-right: 0px" danger @click="selectTranslationResult(form.id, 'xn')" >选择</a-button>
                     
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="翻译结果 (Translation from Google API)"
                    name="gg-result"
                  >
                  
                    <a-input
                      v-model:value="formTranslationResults.xlmodifygg"
                      placeholder="谷歌翻译结果"
                    /><a-button style="margin-right: 0px" danger @click="selectTranslationResult(form.id, 'gg')" >选择</a-button>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="翻译结果 (Translation from Baidu API)"
                    name="bd-result"
                  >
                    <a-input
                      v-model:value="formTranslationResults.xlmodifybd" 
                      placeholder="百度翻译结果"
                    /><a-button style="margin-right: 0px" danger @click="selectTranslationResult(form.id, 'bd')" >选择</a-button>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="翻译结果 (Translation from AT-Man)"
                    name="am-result"
                  >
                    <a-input
                      v-model:value="formTranslationResults.xlmodifyam"
                      placeholder="ATMan翻译结果"
                    /><a-button style="margin-right: 0px" danger @click="selectTranslationResult(form.id, 'am')" >选择</a-button>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item
                    label="翻译结果 (Translation from Youdao API)"
                    name="yd-result"
                  >
                    <a-input
                      v-model:value="formTranslationResults.xlmodifyyd"
                      placeholder="有道翻译结果"
                    /><a-button style="margin-right: 0px" danger @click="selectTranslationResult(form.id, 'yd')" >选择</a-button>
                  </a-form-item>
                </a-col>
              </a-row>
              <a-row :gutter="20">
                <a-col :span="20">
                    <a-input
                      v-model:value="lblTranslationStatus"
                      placeholder="正在翻译，请稍候......"
                    />
                </a-col>
              </a-row>
              </a-spin>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseTranslationForm"
                >返回</a-button
              >
              <!-- <a-button type="primary" @click="onSubmitTranslation">Submit</a-button> -->
            </div>
          </a-drawer>
           
        </template>

      </a-layout-header>

      <a-layout-content
        :style="{
          margin: '0px 0px 0px 10px',
          padding: '75px 0px 0px 0px',
          minHeight: '350px',
        }" 
      >

      <a-tabs type="line" v-model:activeKey="activeKey" >

          <template #rightExtra v-if="activeKey=='1'">
             <div  :style="{padding: '5px 25px 0px 5px', 
              textAlign:'center',
              fontWeight:'bold',
              fontSize:'12pt',
              color:'red'
              }" >

              <!-- <a-checkbox :style="{
                padding: '5px 0px 0px 20px',
                color:'white'
              }" v-model:checked="blSearchInCacheOrBackend">{{this.lang==='cn'? '后端检索': 'Backend Search'}}</a-checkbox> -->

                <!-- <a-input-search
                  style="padding: 20px 20px 10px 10px; width: 150px'; float: center"
                  v-model:value="inputValue"
                  allow-clear
                  placeholder="Search term"
                  enter-button
                  @change="handleSearchInput"
                  @search="handleSearchInput"
                />  -->

              &nbsp;{{dataSource.length}} {{dataSource.length<=1?'result':'results'}} returned&nbsp;
             </div>
          </template>


            
      <!-- <a-tab-pane key="1" tab="Overview" > 

        <a-row>
       
          <a-col :span="4"><a-card style="background: #035969;">
            <a-statistic title="Plan" v-model:value="totalOtherNDPs"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #085703;">
            <a-statistic title="Active" v-model:value="totalActiveNDPs"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #9c7303;">
            <a-statistic :style="{ color:'black'}" title="On Hold" v-model:value="totalOnHoldNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #870804;"> 
            <a-statistic title="Terminated" v-model:value="totalTerminatedNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: green;">
            <a-statistic title="Completed" v-model:value="totalCompletedNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #0c59b0                        ;">
            <a-statistic style="forecolor: #ffffff;" title="Total NDPs" v-model:value="totalNDPs"  />
            </a-card>
          </a-col>
        </a-row>

        <div class="echarts-box">
          <div id="myEcharts" :style="{ width: '95%', height: '370px' }">
          </div>
        </div>

          <a-row>
                <a-col :span="4"><a-card style="background: #9fa160;">
            <a-statistic title="BEx" v-model:value="totalResources.totalBex"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #678545;">
            <a-statistic title="CDDRA" v-model:value="totalResources.totalCDDRA"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #bf9b71;">
            <a-statistic :style="{ color:'black'}" title="CDS&A" v-model:value="totalResources.totalCDSA"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #4376e6;"> 
            <a-statistic title="DM" v-model:value="totalResources.totalDM"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #62a37b;">
            <a-statistic title="SP" v-model:value="totalResources.totalSP"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #bd1c04;">
            <a-statistic style="forecolor: #ffffff;" title="Total FTEs" v-model:value="totalResources.totalResource"  />
            </a-card>
          </a-col>
        </a-row>
   

      </a-tab-pane> -->

       <a-tab-pane key="1" tab="Data Gridview"> 
          <a-spin :tip="loadText" :spinning="isLoading">
          <a-table 
            class="list"
            :data-source="dataSource"
            :style="{
              margin: '0px 0px 0px 10px',
              padding: '0px 0px 0px 0px',
            }" 

            rowKey="id"
            :row-selection="{selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange, columnTitle:columnTitle}"
            :scroll="{x:800, y:600}"
            :columns="columnsList"
            @change="handleChange"
            size="middle"
            tableLayout="fixed"
            
          >

          <template #seq="{ index }">
              {{ (index + 1)+(currentPage-1)*currentPageSize }}
          </template>

           <template #xltest="{ text,record}" >
             <div v-if="record.xltest!=null">
               <pre>{{ record.xltest.replaceAll('####','\n')}}</pre>
             </div>
             <div v-else>
               {{ text}}
             </div>
          </template>

          <template v-if="currentTableName=='study-variable-label'" #xltestcd="{ text, record }">
                <a  @Click="showVariableValueListModal(record)">{{ text}}</a>
              </template>

           <template #xlmodify="{ text, record }" >
              
              <div class="editable-cell" v-if="record.xlstat!=null && ['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase()) ==-1">

                <div
                  v-if="editableData[record.id]"
                  class="editable-cell-input-wrapper" style="text-align:left"
                >
                  <a-input
                    v-model:value="editableData[record.id].xlmodify"
                    @pressEnter="cellSave(record.id)"
                  />
                  <check-outlined
                    class="editable-cell-icon-check"
                    @click="cellSave(record.id)"
                  />
                </div>
                <div v-else class="editable-cell-text-wrapper" style="text-align:left;">
                   <TranslationOutlined  @click="translationFormVisible = true; selectCurrentItem(record); showDrawerTranslation(record.xltest)"/>               
                   &nbsp;<a @click="cellEdit(record.id)">{{ text || " " }}</a>
                  <edit-outlined
                    class="editable-cell-icon"
                    @click="cellEdit(record.id)"
                  />
                </div>
              </div>
              <div v-else-if="record.xleval!=null && record.xleval.toUpperCase() == 'DICT'" class="editable-cell-text-wrapper"> 
                  <LockTwoTone  twoToneColor='#026607' />&nbsp;{{text}}
              </div>
              <div v-else-if="record.xleval!=null && record.xleval.toUpperCase() == 'API'" class="editable-cell-text-wrapper"> 
                  <!-- <LockTwoTone  twoToneColor="record.xleval.toUpperCase()) == 'DICT' ? '#eb2f96' : record.xlstat.toUpperCase()) == 'MANUAL' ? '#eb2f96' : record.xleval.toUpperCase()) == 'STUDY' ?'#eb2f96':'#eb2f96'" />&nbsp;{{text}} -->
                    <LockTwoTone  twoToneColor='#f51634' />&nbsp;{{text}}
              </div>
              <div v-else-if="record.xleval!=null && record.xleval.toUpperCase() == 'GROUP-A'" class="editable-cell-text-wrapper"> 
                  <!-- <LockTwoTone  twoToneColor="record.xleval.toUpperCase()) == 'DICT' ? '#eb2f96' : record.xlstat.toUpperCase()) == 'MANUAL' ? '#eb2f96' : record.xleval.toUpperCase()) == 'STUDY' ?'#eb2f96':'#eb2f96'" />&nbsp;{{text}} -->
                    <LockTwoTone  twoToneColor='#1685f5' />&nbsp;{{text}}
              </div>
              <div v-else-if="record.xleval!=null && record.xleval.toUpperCase() == 'GROUP-S'" class="editable-cell-text-wrapper"> 
                  <!-- <LockTwoTone  twoToneColor="record.xleval.toUpperCase()) == 'DICT' ? '#eb2f96' : record.xlstat.toUpperCase()) == 'MANUAL' ? '#eb2f96' : record.xleval.toUpperCase()) == 'STUDY' ?'#eb2f96':'#eb2f96'" />&nbsp;{{text}} -->
                    <LockTwoTone  twoToneColor='#054585' />&nbsp;{{text}}
              </div>
              <div v-else class="editable-cell-text-wrapper"> 
                  <!-- <LockTwoTone  twoToneColor="record.xleval.toUpperCase()) == 'DICT' ? '#eb2f96' : record.xlstat.toUpperCase()) == 'MANUAL' ? '#eb2f96' : record.xleval.toUpperCase()) == 'STUDY' ?'#eb2f96':'#eb2f96'" />&nbsp;{{text}} -->
                    <LockTwoTone  twoToneColor='#eb2f96' />&nbsp;{{text}}
              </div>

            </template>       

            <template #xlstat="{record}" >
              <span v-if="record.xlstat!=null">
                <a-tag
                  :key="record.id"
                  :color="['ACTIVE', 'INITIAL'].indexOf(record.xlstat.toUpperCase()) !=-1 ? 'red' : ['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase())!=-1 ? 'green' : ['LIBRARY', 'API'].indexOf(record.xlstat.toUpperCase())!=-1 ?'blue':'red'"
                >
                  {{ record.xlstat.toUpperCase() }}
                </a-tag>
              </span>
            </template>

            <template v-if="isGlobalTerms === false" #action="{ record }" align="left">

               <SmileTwoTone v-if="record.xlcruser.toUpperCase()==record.xlmouser.toUpperCase()" twoToneColor="#52c41a"/>
               <SmileTwoTone v-else-if="record.xlmouser.toUpperCase()==''" twoToneColor="#ba0404"/>
               <SmileTwoTone v-else twoToneColor="#eb2f96"/>

              <a-button
                v-if="['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase())==-1"
                type="link"
                @click="nmpaapi.handleOnlineTranslation(this.dataSourceOrigin, this.dataSource, record, this.currentTableName, record.id); isloading=false"
                >{{this.lang==='cn'?'机翻':'API'}}</a-button
              >
              <a-button v-else-if="queryKeyValue=='SHOW'" disabled type="link">{{this.lang==='cn'?'机翻':'API'}}</a-button>

              <a-button
                v-if="['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase())==-1"
                type="link"
                @click="
                  editVisible = true;
                  selectCurrentItem(record);
                "
                >{{this.lang==='cn'?'编辑':'Edit'}}</a-button
              >
              <a-button v-else-if="queryKeyValue=='SHOW'" disabled type="link">{{this.lang==='cn'?'编辑':'Edit'}}</a-button>

              <!-- <a-popconfirm  v-if="record.xlstat.toLowerCase() == 'locked' || record.xlstat.toLowerCase() == 'approved'"
                title="您确定要复制当前记录为新记录?"
                @confirm=" selectCurrentItem(record); onRowCopy(record, 'copy')"
              >
                <a-button  type="link">{{this.lang==='cn'?'复制':'Copy'}}</a-button >
              </a-popconfirm> -->

              <a-popconfirm                
                title="您确定要删除当前记录吗?"
                @confirm="removeItem(record.id,record.xlstat,record.xlauditlog)"
              >
                <a-button v-if="['LOCKED', 'APPROVED', 'ARCHIVED', 'DELETED'].indexOf(record.xlstat.toUpperCase()) ==-1" type="link">{{this.lang==='cn'?'删除':'Delete'}}</a-button>
                <a-button v-else-if="queryKeyValue=='SHOW'" disabled type="link">{{this.lang==='cn'?'删除':'Delete'}}</a-button>
              </a-popconfirm>

              <a-popconfirm               
                title="您确定要标记当前记录为待定吗?"
                @confirm="selectCurrentItem(record); termsGovernance(record.id, 'pending', 'PENDING', record.xlstat, record.xlauditlog)"
              >
                <a-button v-if="['LOCKED', 'APPROVED', 'ARCHIVED', 'DELETED', 'PENDING'].indexOf(record.xlstat.toUpperCase()) ==-1" type="link">{{this.lang==='cn'?'待定':'Pending'}}</a-button>
                 <a-button v-else-if="queryKeyValue=='SHOW'" disabled type="link">{{this.lang==='cn'?'待定':'Pending'}}</a-button>
              </a-popconfirm>

              <a-popconfirm
                title="您确定要标记当前记录为待审吗?"
                @confirm="selectCurrentItem(record); termsGovernance(record.id, 'ready', 'READY', record.xlstat, record.xlauditlog)"
              >
                <!-- <a-button v-if="['LOCKED', 'APPROVED', 'ARCHIVED', 'DELETED', 'READY'].indexOf(record.xlstat.toUpperCase()) ==-1 && record.xlmodify != null" type="link">{{this.lang==='cn'?'待审':'Ready'}}</a-button> -->
                 <!-- <a-button v-else-if="record.xlstat.toUpperCase()=='LOCKED'" disabled type="link">{{this.lang==='cn'?'待审':'Ready'}}</a-button> -->
              </a-popconfirm>

              <a-popconfirm
                title="您确定要锁定当前记录吗?"
                @confirm=" selectCurrentItem(record); termsGovernance(record.id, 'lock', 'LOCKED', record.xlstat, record.xlauditlog)"
              >

                <a-button v-if="['LOCKED', 'APPROVED', 'ARCHIVED', 'DELETED'].indexOf(record.xlstat.toUpperCase()) ==-1 && record.xlmodify != null" type="link">{{this.lang==='cn'?'锁定':'Lock'}}</a-button>
                 <a-button v-else-if="queryKeyValue=='SHOW' && record.xlstat.toLowerCase() != 'locked'" disabled type="link">{{this.lang==='cn'?'锁定':'Lock'}}</a-button>
              </a-popconfirm>

              <a-popconfirm
                title="您确定要解锁当前记录吗??"
                @confirm=" selectCurrentItem(record); termsGovernance(record.id, 'unlock', 'ACTIVE', record.xlstat, record.xlauditlog)"
              >

                <a-button v-if="record.xlstat.toLowerCase() == 'locked'" type="link" >{{this.lang==='cn'?'解锁':'Unlock'}}</a-button>
                 <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'解锁':'Unlock'}}</a-button> -->
              </a-popconfirm>

              <a-popconfirm               
                title="您确定要将当前术语添加到API记忆库吗?"
                @confirm="AddIntoAPIMemory(record)"
              >
                <a-button  v-if="
                  ['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase()) !=-1
                " type="link">{{this.lang==='cn'?'记忆':'Add Memory'}}</a-button>
                <a-button  v-else-if="queryKeyValue=='SHOW'" disabled type="link">{{this.lang==='cn'?'记忆':'Add Memory'}}</a-button>
              </a-popconfirm>

              <a-popconfirm               
                title="您确定要将当前术语添加到全局字典库吗?"
                @confirm="AddIntoGlobalDict(record)"
              >
                <a-button v-if="record.xleval.toUpperCase() != 'DICT' && ['LOCKED', 'APPROVED', 'ARCHIVED'].indexOf(record.xlstat.toUpperCase()) !=-1 && queryKeyValue=='ARCHIVED' " type="link">{{this.lang==='cn'?'入库':'Add Library'}}</a-button>
                <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'入库':'Add Library'}}</a-button> -->
              </a-popconfirm>

            </template>
            <template v-else-if="isAdmin==1 && isGlobalTerms===true" #action="{ record }" align="left">
              <a-popconfirm
                title="您确定要锁定当前记录吗?"
                @confirm=" selectCurrentItem(record); termsGovernance(record.id, 'lockg', 'LOCKED', record.xlstat, record.xlauditlog)"
              >

                <a-button v-if="['LOCKED', 'APPROVED', 'ARCHIVED', 'DELETED'].indexOf(record.xlstat.toUpperCase()) ==-1 && record.xlmodify != null" type="link">{{this.lang==='cn'?'锁定':'Lock'}}</a-button>
                 <a-button v-else-if="queryKeyValue=='SHOW' && record.xlstat.toLowerCase() != 'locked'" disabled type="link">{{this.lang==='cn'?'锁定':'Lock'}}</a-button>
              </a-popconfirm>
              <a-popconfirm
                title="您确定要解锁当前记录吗??"
                @confirm=" selectCurrentItem(record); termsGovernance(record.id, 'unlock', 'ACTIVE', record.xlstat, record.xlauditlog)"
              >
                <a-button v-if="record.xlstat.toLowerCase() == 'locked'" type="link" >{{this.lang==='cn'?'解锁':'Unlock'}}</a-button>
                 <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'解锁':'Unlock'}}</a-button> -->
              </a-popconfirm>
              <a-popconfirm               
                title="您确定要标记当前记录为待定吗?"
                @confirm="selectCurrentItem(record); termsGovernance(record.id, 'pendingg', 'PENDING', record.xlstat, record.xlauditlog)"
              >
                <a-button v-if="['LOCKED'].indexOf(record.xlstat.toUpperCase()) !=-1" type="link">{{this.lang==='cn'?'待定':'Pending'}}</a-button>
                 <a-button v-else disabled type="link">{{this.lang==='cn'?'待定':'Pending'}}</a-button>
              </a-popconfirm>
             </template>

            <template #expandedRowRender="{ record }">
              <p style="margin: 20px">
                Study ID: {{ record.studyid}}
              </p>
              <p style="margin: 20px"  v-if="record.xlcomment != null && record.xlcomment != ''">
                Comments: {{ record.xlcomment }}
              </p>
              <pre ></pre>
              <p
                style="margin: 20px;"
                v-if="record.xlauditlog != null && record.xlauditlog != ''">
                <pre>{{ record.xlauditlog!=null?record.xlauditlog.replace('####','\n'):'' }}</pre>
              </p>
            </template>

            <template #footer>
              <div :style="{color:'grey', padding: '15px 0px 15px 20px', textAlign:'center'}" >
              <StarTwoTone two-tone-color="red" />
              &nbsp;&nbsp;当前术语列表翻译进度:&nbsp;
              <!-- <a-tag color="red"> BEx: G4015457 </a-tag> 
              <a-tag color="orange"> CDDRA: G4015458  </a-tag> 
                <a-tag color="purple"> CDS&A: G4015459  </a-tag> 
                  <a-tag color="blue"> DM: G4015460  </a-tag> 
                    <a-tag color="green"> SP: G4015461</a-tag>  -->
                 <a-tag color="grey">总共：{{this.totalTerms}} 条&nbsp;</a-tag> 
                 <a-tag color="green">已完成：{{this.totalLockedTerms}}&nbsp;</a-tag> 
                 <a-tag color="yellow">待定：{{this.totalPendingTerms}}&nbsp;</a-tag> 
                  <a-tag color="orange">待审：{{this.totalAPITerms}}&nbsp;</a-tag> 
                 <a-tag color="blue">进行：{{this.totalActiveTerms}}&nbsp;</a-tag> 
                 <a-tag color="red">尚未开始：{{this.totalInitialTerms}}&nbsp; </a-tag> 
              </div>

              </template>

          </a-table>
        </a-spin>

        </a-tab-pane>

       <!-- <a-tab-pane key="tag" tab="Tags"> 

          <span v-for="(item,index) in listOfInitialTagName" :key="item+'_'+index" :style="{width:'150px'}">
            <a @click="queryByTagName(item);" 
              :style="{fontSize:'14pt', width:'150px', color:'white', background:'#'+ Math.floor(Math.random(123)*16777215).toString(16)}">
              {{item}}
            </a>
            <a :style="{background:'white'}">&nbsp;&nbsp;&nbsp;</a>
          </span>

        </a-tab-pane> -->

        <!-- <a-tab-pane key="wish-list" tab="Wishlist" > 
  
            <templates>

            <div :style= "{ padding: '10px 20px 75px 30px', width: '60%' }" >

            <h2 style="padding: 10px 20px 75px 30px, " >Wish List Submission Form</h2>

            <a-form :model="formState" layout="vertical" ref="formRef" :rules="rulesRef"> 
     
                  <a-row :gutter="30">
                      <a-col :span="9">
                        <a-form-item
                          label="Category"
                          name="category"
                        >
                      <a-select
                        placeholder=""
                        v-model:value="formState.category" @change="handleCategorySelectChange(formState.category)"
                        >                
                          <a-select-option v-for="item, index in listOfWishListCategory" :key="index" :value="item.code">
                          {{ item.name}} 
                        </a-select-option>
                        </a-select>
                        </a-form-item>
                      </a-col>
                      <a-col :span="9">
                        <a-form-item
                          label="Sub Category"
                          name="sub_category"
                        >
                        <a-select
                          placeholder=""
                          v-model:value="formState.sub_category"
                          >                
                            <a-select-option v-for="item, index in listOfSubCategory" :key="index" :value="item.code">
                            {{ item.name }} 
                          </a-select-option>
                          </a-select>
                        </a-form-item>
                      </a-col>
                    </a-row>

                    <a-row :gutter="30" >
                       <a-col :span="18">
                          <a-form-item label="Tag Names" name="tagname">
                          <a-input
                            v-model:value="formState.tagname"
                            placeholder=""

                          />
                          </a-form-item>
                       </a-col>
                    </a-row>

                    <a-row :gutter="30" >
                       <a-col :span="18">
                          <a-form-item label="Short Description" name="subject_name">
                          <a-input
                            v-model:value="formState.subject_name"
                            placeholder=""

                          />
                          </a-form-item>
                       </a-col>
                    </a-row>

                      <a-row :gutter="30" >
                       <a-col :span="18">
                          <a-form-item label="Long Description" name="subject_desc">
                          <a-textarea
                            v-model:value="formState.subject_desc"
                            placeholder=""
                            :auto-size="{ minRows: 5, maxRows: 10}"
                          />
                          </a-form-item>
                       </a-col>
                      </a-row>
                       <a-row :gutter="30" >
                         <a-col :span="18">
                        <div style="text-align:right" >        
                        <a-button style="margin-right: 8px" type="primary" @click="onSubmitNewWL();">Submit</a-button>
                        </div>
                         </a-col>
                       </a-row>

                        
                </a-form>
            </div>

            </templates>


        </a-tab-pane> -->

      </a-tabs>
      </a-layout-content>       


      <!-- <a-layout-footer style="text-align: center">
          <div style="margin-right: 0px;
                      margin-bottom: 10px;
                      margin-left: 0px;
                      margin-top: 30px;"><span>Powered by Data42, ©2020 </span></div>   
          <p class="errorMessage" v-if="errorMessage">{{ errorMessage }}</p>
          <p class="successMessage" style="text-align: left" v-if="successMessage">
            {{ successMessage }}
          </p>
      </a-layout-footer> -->
    </a-layout>
  </a-layout>
</template>

<script>

// import {
//   // UserOutlined, VideoCameraOutlined,UploadOutlined,
//   QuestionCircleOutlined,
//   FilePdfOutlined,
//   FilePptOutlined,
//   VideoCameraOutlined,
//   PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined, ReadOutlined,LockOutlined,
//   TagOutlined,
//   UnlockOutlined,
//   AppstoreOutlined,
//   CopyrightTwoTone,
//   DeploymentUnitOutlined,
//   SyncOutlined,
//   ClusterOutlined,
//   ApartmentOutlined,
//   WarningTwoTone,
//   StarTwoTone,
//   BellTwoTone,
//   CommentOutlined,
//   CheckCircleTwoTone,
//   SlackOutlined,
//   ReloadOutlined,
//   GooglePlusOutlined,
//   LoginOutlined,
//   LogoutOutlined,
//   SmileTwoTone,
//   UserOutlined,
//   RobotOutlined,
//   TranslationOutlined,
//   PushpinOutlined,
//   SmileOutlined,
//   DownOutlined,
//   MinusOutlined,
//   DeleteOutlined,
//   MenuUnfoldOutlined,
//   MailOutlined,
//   ExportOutlined,
//   KeyOutlined,
//   ToolOutlined,
//   CheckOutlined,
//   CopyOutlined,
//   EditOutlined,
//   TeamOutlined,
//   ShoppingCartOutlined,
//   LikeOutlined,
//   SearchOutlined,
//   SettingOutlined,
//   PlusOutlined,
//   MenuFoldOutlined,
// } from "@ant-design/icons-vue";
// // import axios from "axios";
// import axios from '@/axios';
// import moment from 'moment';
// import dayjs from 'dayjs';
// // import nvslogo from '@/assets/novartis-logo01.svg';
// // import 'dayjs/locale/zh-cn';
// import * as echarts from "echarts";
// import { computed, defineComponent, onMounted, onUnmounted, reactive, ref, toRaw, toRefs, watch } from "vue";
// import { cloneDeep} from "lodash-es";
// import { message, } from "ant-design-vue";
// import config from "../common/config.js";
// // import locale from 'ant-design-vue/es/date-picker/locale/zh_CN';

// dayjs.locale('zh-cn');
import XLSX from 'xlsx';
import {
  // UserOutlined, VideoCameraOutlined,UploadOutlined,
  PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined,ClusterOutlined, ReadOutlined,LockOutlined,
  DownloadOutlined,
  StarTwoTone, CopyrightTwoTone,FilePdfTwoTone,
  ReconciliationTwoTone,MedicineBoxTwoTone,ProfileTwoTone,DatabaseTwoTone,AppstoreTwoTone,
  UnlockOutlined,
  InfoCircleOutlined,EyeOutlined,
  LockTwoTone,
  SlackOutlined,
  ReloadOutlined,
  SaveOutlined,
  GooglePlusOutlined,
  LoginOutlined,
  KeyOutlined,
  LogoutOutlined,
  SmileTwoTone,
  UserOutlined,
  RobotOutlined,
  TranslationOutlined,
  PushpinOutlined,
  SmileOutlined,
  DownOutlined,
  MinusOutlined,
  DeleteOutlined,
  UndoOutlined,
  FileProtectOutlined,
  MenuUnfoldOutlined,
  FieldTimeOutlined,
  MailOutlined,
  CheckSquareOutlined,
  CloseSquareOutlined,
  AppstoreOutlined,
  UploadOutlined,
  ExportOutlined,
  ToolOutlined,
  CheckOutlined,
  EditOutlined,
  SearchOutlined,
  SettingOutlined,
  PlusOutlined,
  MenuFoldOutlined,
} from "@ant-design/icons-vue";
// import axios from "axios";
import axios from '@/axios';
import { computed, defineComponent, onUpdated, onMounted, reactive, ref, toRefs, watch } from "vue";
import { cloneDeep, debounce, stubString } from "lodash-es";
import { message } from "ant-design-vue";
import config from "../common/config.js";
import nmpaapi from "../common/nmpa-api.js";

export default defineComponent({
  components: {
    // UserOutlined,
    // VideoCameraOutlined,
    SearchOutlined,
    StarTwoTone, CopyrightTwoTone,
    ReconciliationTwoTone,MedicineBoxTwoTone,FilePdfTwoTone,ProfileTwoTone,DatabaseTwoTone,AppstoreTwoTone,
    PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined,ClusterOutlined, ReadOutlined,LockOutlined,
    UnlockOutlined,
    InfoCircleOutlined,EyeOutlined,
    LockTwoTone,
    SlackOutlined,
    SaveOutlined,
    GooglePlusOutlined,
    ReloadOutlined,
    KeyOutlined,
    LoginOutlined,
    LogoutOutlined,
    SmileTwoTone,
    UserOutlined,
    TranslationOutlined,
    RobotOutlined,
    PushpinOutlined,
    SmileOutlined,
    DownOutlined,
    MinusOutlined,
    DeleteOutlined,
    UndoOutlined,
    FileProtectOutlined,
    DownloadOutlined,
    UploadOutlined,
    CheckOutlined,
    EditOutlined,
    PlusOutlined,
    MailOutlined,
    CheckSquareOutlined,
    CloseSquareOutlined,
    FieldTimeOutlined,
    AppstoreOutlined,
    SettingOutlined,
    MenuUnfoldOutlined,
    ExportOutlined,
    ToolOutlined,
    MenuFoldOutlined,
  },

  data() {
    return {

      languages: [
          // { flag: 'us', language: 'en', title: 'English' },
          { flag: 'cn', language: 'cn', title: 'Chinese' },
          { flag: 'us', language: 'en', title: 'English' },
      ],

      contextMenuVisible: false,
      contextMenuStyle: {
        position: "absolute",
        top: "0",
        left: "0",
        border: "1px solid #eee"
      },

      customRightClick: record => ({      
        on: {
          contextmenu: e => {
            e.preventDefault();
            this.menuData = record;
            this.contextMenuVisible = true;
            this.contextMenuStyle.top = e.clientY + "px";
            this.contextMenuStyle.left = e.clientX + "px";
            document.body.addEventListener("click", this.bodyClick);
          }
        }
      }),

      // userconfig: config,
      nmpaapi: nmpaapi,
      fileList: [],
      uploading: false,
      showingModal: false,
      showingeditModal: false,
      showingPasscodeModal: false,      
      showingdeleteModal: false,
      // inputValue: "",
      // dataSource: [],
      // cellEdit: ref({}),
      // clickedItem: {},
      editRow: {},    
      studylist:[],
      // letterList: [],
    };
  },

  setup() {
    // const fileList = ref([]);
    // const uploading = ref(false);

    // const  dataSource=ref([]);

    const activeKey=ref('1');

    const showingTaskAssignModal=ref(false);
    const showingWhiteBoardModal=ref(false);
    const showingGroupTranslationModal=ref(false);
    const showingVariableValueListModal=ref(false);
    var randomize = require('randomatic');
    const selectedUserList = ref([]);
    const selectedProjectList = ref([]);
    const selectedVariableValueList = ref('');

    let lastFetchId = 0;
    const globalUserList = ref([]);
    const assignedReviewersEmail = ref([]);
    // const filteredUserList =ref([]);
    const filteredUserList = computed(() => globalUserList.value.filter(o => !selectedUserList.value.includes(o.userid)));
 
    const taskAssignedUserList = ref ('');
    const userPasscode = ref('');
    const pageTotalLabel=ref('');
    const userconfig=reactive(config);
    const statusList=reactive(config.statusList);

    //for status bar at bottom
    // const uploadFile = ref('');
    const dueDate =ref(0);
    const loadText=ref("Loading...");
    // const onFinish = () => {
    //   console.log('finished!');
    //   $router.push({ path: process.env.VUE_APP_baseURL+"login" });
    //   //send email
    // };

    const generatePasscode = () =>{
      // var randomize = require('randomatic');
      userPasscode.value=randomize('0',4);
    };

    //for statistics purpose
    const queryKeyValue = ref('SHOW');
    const totalTerms = ref('');
    const totalLockedTerms = ref('');
    const totalPendingTerms = ref('');
    const totalActiveTerms = ref('');
    const totalAPITerms = ref('');
    const totalInitialTerms = ref('');

    //for upload purpose
    const inputValue = ref('');
    const uploadVisible = ref(false);
    const progressValue = ref('');
    const letterList = ref([]);
    const userStudyList = ref([]);
    const userProtocolList = ref([]);
    const strColumnList = ref(''); //upload file column name
    const strColumnListN = ref('');
    const globalStudyList = ref([]);
    const globalProtocolList = ref([]);
    const uploadFile = ref([]);
    const defaultPercent = ref(0);//for upload progress
    const uploadProtocolID = ref('');
    const uploadStudyID = ref('');
    const userProtocolID = ref('');
    const userStudyID = ref('');
    const uploadFileWithoutDuplicate=ref(2);
    const uploadDescription = ref('');
    const uploadComment = ref('');
    const uploadTermScope = ref(2);
    const uploadTermAccess = ref(2);
    const uploadTermCategory=ref('variable-label');
    const uploadTermType=ref('General');
    const radioStyle = reactive({
      display: 'block',
      height: '50px',
      lineHeight: '30px',
    });


    const getUniqueArray=(arr, keyProps)=> {
      const kvArray = arr.map(entry => {
        const key = keyProps.map(k => entry[k]).join('|');
        return [key, entry];
      });
      const map = new Map(kvArray);
      return Array.from(map.values());
      }

    //mapping variable list;

    const beforeUpload=(file)=> {

        var uploadFileHeaderLabel=['PROTOCOL', 'STUDY', 'PROTOCOLID', 'STUDYID', 'XLCAT', 'XLSCAT', 'XLTYPE', 'XLTEST', 'XLMODIFY','XLCOMMENT', 'COMMENT', 'XLTESTCD', 'XLTESTCD', 'XLTEST', 'XLSTAT', 'CAT',   'SCAT',   'SUBCAT' , 'CATEGORY', 'SUBCATEGORY', 'TYPE',   'SOURCE', 'TARGET',  'COMMENT',   'ELEMENT',  'NAME',     'LABEL', 'STATUS', 'CRUSER', 'MOUSER', 'CRDTC', 'MODTC', 'CRDATE', 'MODATE', 'AUDITLOG', 'AUDIT', 'ACCESS','ACCESSLEVEL', 'ORIGIN', 'XLORIGIN', 'VARNAME', 'VARLABEL', 'VARTYPE', 'VARVALUE'];

        var uploadFileHeaderName= ['PROTOCOLID', 'STUDYID', 'PROTOCOLID', 'STUDYID', 'XLCAT', 'XLSCAT', 'XLTYPE', 'XLTEST', 'XLMODIFY','XLCOMMENT', 'XLCOMMENT', 'XLTESTCD', 'XLTESTCD', 'XLTEST', 'XLSTAT', 'XLCAT', 'XLSCAT', 'XLSCAT' , 'XLCAT',    'XLSCAT', 'XLTYPE', 'XLTEST', 'XLMODIFY','XLCOMMENT', 'XLTESTCD', 'XLTESTCD', 'XLTEST', 'XLSTAT', 'XLCRUSER','XLMOUSER', 'XLCRDTC', 'XLMODTC', 'XLCRDTC', 'XLMODTC', 'XLAUDITLOG', 'XLAUDITLOG','ACCESSLEVEL','ACCESSLEVEL','XLORIGIN', 'XLORIGIN','XLTESTCD','XLTEST','XLTYPE','XLMODIFY'];
        
        var fileExtName=file.name.substring(file.name.lastIndexOf('.')+1).toLowerCase();

        const isTxtCSVPDF = fileExtName === "txt" || fileExtName === "csv" || fileExtName === "pdf";
        // const isTxtCSV = file.type === 'text/plain' || file.type === 'application/vnd.ms-excel' 

        // function checkHeaderValid(hdr){
        //   if (uploadFileHeaderLabel.find(hdr.toUpperCase)){
        //     return hdr;
        //   }

        // }

        function toUpper(x){ 
          return x.toUpperCase();
        };
        
        var seq=0;

        // var strColumnList=[];
        // var strColumnListN=[];
        strColumnList.value='';
        strColumnListN.value='';

        localStorage.removeItem("strColumnList");
        localStorage.removeItem("strColumnListN");
        
        if (fileExtName === "csv"){
            let reader = new FileReader();
            // let strValidColumnList="";
            // let strValidColumnListN="";
            reader.readAsText(file, "UTF-8");
            reader.onload =  evt => {
              let str=evt.target.result.toString();
              // console.log(str);
              const headers = str.split("\n")[0].split(',').map(toUpper);
              console.log(headers);

              seq=0;
              headers.forEach(function(value,index){
                //  console.log(index, value);
                var srtValue=value.replace(/\r/,'');
                if(uploadFileHeaderLabel.includes(srtValue)===true){
                  // console.log(index, value);    
                  // strColumnListN.value.push(index);     
                  strColumnList.value=strColumnList.value + " " + uploadFileHeaderName[uploadFileHeaderLabel.findIndex(val =>val==srtValue)]
                  strColumnListN.value=strColumnListN.value + " " + index.toString();         
                }
                seq+=1;
              }
              )

              //add into local storage;              
              localStorage.setItem("strColumnList", strColumnList.value.trim());
              localStorage.setItem("strColumnListN", strColumnListN.value.trim());

            }
        }
        else if(fileExtName === "txt"){
            let reader = new FileReader();
            // let strValidColumnList="";
            // let strValidColumnListN="";
            reader.readAsText(file, "UTF-8");
            reader.onload =  evt => {
              let str=evt.target.result.toString();
              const headers = str.split("\n")[0].split('\t').map(toUpper);
              console.log(headers);

              seq=0;
              headers.forEach(function(value,index){

                var srtValue=value.replace(/\r/,'');
                //  console.log(index, value);
                if(uploadFileHeaderLabel.includes(srtValue)===true){
                  // console.log(index, value);     
                  // strColumnListN.value.push(index);       
                  strColumnList.value=strColumnList.value + " " + uploadFileHeaderName[uploadFileHeaderLabel.findIndex(val =>val==srtValue)]   
                  strColumnListN.value=strColumnListN.value + " " + index.toString();                 
                }
                seq+=1;
              }              
              )
              // console.log(strColumnList.toString());
              //add into local storage;              
              localStorage.setItem("strColumnList", strColumnList.value.trim());
              localStorage.setItem("strColumnListN", strColumnListN.value.trim());
            }
        }


        if (!isTxtCSVPDF) {
            message.error('只能上传文本格式或PDF文件!')
        }
        const isLTMaximumSize = file.size / 1024 / 1024 < 10
        if (!isLTMaximumSize) {
            message.error('文件大小不得大于10MB!')
        }

        uploadFile.value[0]=file.name;

        return isTxtCSVPDF && isLTMaximumSize
    };

    const uploadTerms=(file)=> {

      // console.log(file.file.name);

      if (uploadTermScope.value === 2 && (uploadStudyID.value==='' || uploadProtocolID.value==='') ){
          errorMessage.value="Protocol or Study ID not selected, please check.";
          return;
      }

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      if(uploadDescription.value===''){
        const filename = file.file.name.split('.').slice(0, -1).join('.');
        uploadDescription.value=localStorage.getItem('userid') + '|' +filename.toUpperCase();
      }
      else{
        uploadDescription.value=uploadDescription.value.toUpperCase();
      }
      
      // console.log("Columns", strColumnList.value);
      let formdata = new FormData()
      formdata.append('protocolid', uploadProtocolID.value)
      formdata.append('studyid', uploadStudyID.value)
      formdata.append('description', uploadDescription.value)
      formdata.append('scope', uploadTermScope.value)
      formdata.append('category', uploadTermCategory.value)
      formdata.append('removeduplicate', uploadFileWithoutDuplicate.value)  
      formdata.append('type', uploadTermType.value)
      formdata.append('access', uploadTermAccess.value)
      formdata.append('comment', uploadComment.value)
      formdata.append('file', file.file)
      formdata.append("userid",localStorage.getItem("userid"));

      const config = {
        onUploadProgress: progressEvent => {
          // progressEvent.loaded:已上传文件大小
          // progressEvent.total:被上传文件的总大小
        //   defaultPercent.value = Number((progressEvent.loaded / progressEvent.total * 100).toFixed(2))
          defaultPercent.value=parseInt( Math.round((progressEvent.loaded / progressEvent.total ) * 100 ))
        }
      }

      // console.log(file);

      var fileExtName=file.file.name.substring(file.file.name.lastIndexOf('.')+1).toLowerCase();

      //for CRF PDF upload processing
      if (fileExtName=='pdf'){
          axios.post(`https://nmpa-flask-api.apps.busdevocp.novartis.net/readinpdf`,formdata, config).then(
              response => {
                if (response.data.error) {
                message.error(response.data);

              } else {

                message.success('PDF文本提取成功');

                message.success("正在写入数据库，请耐心等待！");

                formdata.append('filename', response.data.filename);
                // formdata.append('keytablename', localStorage.getItem("keytablename"));
                // formdata.append("strColumnList",localStorage.getItem("strColumnList"));
                // console.log(JSON.parse(JSON.stringify(response.data)));

                formdata.append("crfobject",encodeURIComponent(JSON.stringify(response.data)));
                axios.post(`terms/nmpa-crf-write-database.php`,formdata,config).then(
                    response => {
                        if (response.data.error) {
                        message.error(response.data.message);

                    } else {
                        message.success(response.data.message);
                        uploadVisible.value=false;
                        // console.log(response.data);
                    }
                    }).catch((error) => {
                            console.log(error.data);
                            message.error(error.data.message);
                   })

                    // console.log(response.data);

                }
          }).catch((error) => {
                console.log(error.data);
                message.error(error.data.message);
                alert("Your current session has expired, please log in again!");
                  if (localStorage.getItem("accessToken")) {
                    localStorage.removeItem("accessToken");
                    this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
                  }else{
                    this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
                  };
                return;
          })
          return;
      }

      //for variable values upload;

      //for pure text terms file upload processing
      axios.post(`terms/nmpa-dict-upload-csv.php`,formdata,config).then(
          response => {
            if (response.data.error) {
            message.error(response.data.message);

          } else {
            message.success(response.data.message);

            message.success("正在写入数据库，请耐心等待！");

            formdata.append('filename', response.data.filename);
            formdata.append('keytablename', localStorage.getItem("keytablename"));
            formdata.append("strColumnList",localStorage.getItem("strColumnList"));
            formdata.append("strColumnListN",localStorage.getItem("strColumnListN"));
            axios.post(`terms/nmpa-dict-write-database-v2.php`,formdata,config).then(
                response => {
                    if (response.data.error) {
                    message.error(response.data.message);

                } else {
                    message.success(response.data.message);
                    uploadVisible.value=false;
                    // console.log(response.data);
                }
                }).catch((error) => {
                        console.log(error.data);
                        message.error(error.data.message);
                    })
                // console.log(response.data);
            }
      }).catch((error) => {
            console.log(error.data);
            message.error(error.data.message);
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
      })
    };


    const stripe = ref();
    const columnTitle = ref(' ');
    const successMessage = ref("");
    const errorMessage = ref("");
    const searchInput = ref();
    const strUserName =  ref("");
    const editableData = reactive({});
    const clickedItem=reactive({});

    const isLogin = ref(false);
    const isAdmin = ref(0);
    const lang =ref('cn');
    const lblTranslationStatus = ref("正在翻译，请稍候... ...");

    const columnsList = reactive([
      {
 
      },
    ]);

    const selectedRowKeyList = ref(1);
    const currentPage = ref(1);
    const currentPageSize = ref(1);
    const filteredInfo = ref();
    const sortedInfo = ref();

   const uniqueCapitalLetterListSelected= (keyname)=> {
        //  var output = [];
         var keys   = [];
         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();
             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };

  // const handleNewStudy=()=>{
  //    $router.push({ path: process.env.VUE_APP_baseURL+"login" });
  //  };

  const handleSearchInput=()=> {
    ''
      // console.log('Debug user input:'+ userStudyID.value)

      dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));


      if (userStudyID.value!=null && userStudyID.value !="---Show All---"){
        dataSource.value = dataSource.value.filter(
          (item) =>
            (
            (item.xltest!=null?item.xltest:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
            (item.xlmodify!=null?item.xlmodify:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
            (item.xltestcd!=null?item.xltestcd:'').toLowerCase().includes(inputValue.value.toLowerCase()) 
            ) && item.studyid.toUpperCase()==userStudyID.value
        );
      }

      else if (userProtocolID.value!=null && userProtocolID.value !="---Show All---" && userStudyID.value ==="---Show All---"){
        dataSource.value = dataSource.value.filter(
          (item) =>
            (
            (item.xltest!=null?item.xltest:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
             (item.xlmodify!=null?item.xlmodify:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
             (item.xltestcd!=null?item.xltestcd:'').toLowerCase().includes(inputValue.value.toLowerCase()) 
            ) && item.protocolid.toUpperCase()==userProtocolID.value
        );
      }

      else if (userProtocolID.value =="---Show All---"){
        dataSource.value = dataSource.value.filter(
          (item) =>
            (
            (item.xltest!=null?item.xltest:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
            (item.xlmodify!=null?item.xlmodify:'').toLowerCase().includes(inputValue.value.toLowerCase()) ||
            (item.xltestcd!=null?item.xltestcd:'').toLowerCase().includes(inputValue.value.toLowerCase()) 
            ) 
        );
      }

      if (queryKeyValue==''){
        letterList.value=uniqueCapitalLetterListSelected('xltest').sort((a, b) => (a > b) ? 1 : -1);

      }
      else{
        letterList.value=uniqueCapitalLetterListSelected('xltest').sort((a, b) => (a > b) ? 1 : -1);

      }
     
      totalTerms.value=dataSource.value.length;

      totalLockedTerms.value=dataSource.value.filter(
          (item) =>
            (
            item.xlstat.toLowerCase().includes('locked') 
            ) 
        ).length;

      totalActiveTerms.value=dataSource.value.filter(
          (item) =>
            (
            item.xlstat.toLowerCase().includes('active') 
            ) 
        ).length;

      totalPendingTerms.value=dataSource.value.filter(
          (item) =>
            (
            item.xlstat.toLowerCase().includes('pending') 
            ) 
        ).length;

      totalAPITerms.value=dataSource.value.filter(
          (item) =>
            (
            item.xlstat.toLowerCase().includes('api') 
            ) 
        ).length;

      totalInitialTerms.value=dataSource.value.filter(
          (item) =>
            (
            item.xlstat.toLowerCase().includes('initial') 
            ) 
        ).length;

      
      totalLockedTerms.value=totalLockedTerms.value + ' (' + Math.round(totalLockedTerms.value*1000/totalTerms.value)/10 + '%)'
      totalPendingTerms.value=totalPendingTerms.value + ' (' + Math.round(totalPendingTerms.value*1000/totalTerms.value)/10 + '%)'
      totalActiveTerms.value=totalActiveTerms.value + ' (' + Math.round(totalActiveTerms.value*1000/totalTerms.value)/10 + '%)'
      totalAPITerms.value=totalAPITerms.value + ' (' + Math.round(totalAPITerms.value*1000/totalTerms.value)/10 + '%)'
      totalInitialTerms.value=totalInitialTerms.value + ' (' + Math.round(totalInitialTerms.value*1000/totalTerms.value)/10 + '%)'

      localStorage.setItem("protocolid", userProtocolID.value);
      localStorage.setItem("studyid", userStudyID.value);
      localStorage.setItem("searchterm", inputValue.value);

    };


    //update user passcode
    const updatePasscode = (passcode) =>{
     var params = new URLSearchParams();

      params.append("action", 'update-passcode');
      params.append("passcode", passcode);
      params.append("userid", localStorage.getItem('userid'));

      axios
        .post(
          `terms/nmpa-user-governance.php`,
          params
        )
        .then((response) => {
          // console.log(response.data);
          message.success(response.data.message);

        })
        .catch((error) => {
          // console.log(error);
          message.error(resposne.data.message);
          // errorMessage.value = error;
        });

    };

    //update terms reiewers

    const updateTermsReviewer = (keylist) =>{

     var params = new URLSearchParams();

      params.append("reviewer", selectedUserList.value);
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("assignreviewer"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(currentTableName.value));
      // console.log(selectedUserList.value)

      axios
        .post(
          `terms/nmpa-dict-assignall.php`,
          params
        )
        .then((response) => {

          // for (let value of Object.values(selectedUserList.value)) {
          //     console(value);
          // }

          //filter the reviewer's email address
         let emaillist = [];
         globalUserList.value.forEach(function (record) {
            for (var i = 1; i <= selectedUserList.value.length; i++){
              if (selectedUserList.value[i-1].toUpperCase()==record.userid.toUpperCase()){
                emaillist.push(record.email)
              };

            }
         });

        // console.log(emaillist[0])
        // sendSelectedItemsByEmail(emaillist[0]);

          message.success('任务成功分配给指定审阅人！');

        })
        .catch((error) => {
          // console.log(error);
          // message.error(resposne.data.message);
          message.success('任务邮件发送失败！');
          // errorMessage.value = error;
        });

      showingTaskAssignModal.value=false;

    

    };

    //add item into API memory library
    const AddIntoAPIMemory=(item)=>{
     
      var params = new URLSearchParams();

      params.append("keytablename", encodeURIComponent(currentTableName.value));
      params.append("action", 'append');
      params.append("userid", localStorage.getItem('userid'));

      params.append("xltest", encodeURIComponent(item.xltest));
      params.append("xltestcd", encodeURIComponent(item.xltestcd));
      params.append("xlmodify", encodeURIComponent(item.xlmodify));

      params.append("xlcat", encodeURIComponent(item.xlcat));
      params.append("xlscat", encodeURIComponent(item.xlscat));
      params.append("xltype", encodeURIComponent(item.xltype));

      params.append("protocolid", encodeURIComponent(item.protocolid));
      params.append("studyid", encodeURIComponent(item.studyid));   
      
      params.append("xlcomment", encodeURIComponent(item.xlcomment));

      axios
        .post(
          `terms/nmpa-api-dict-add.php`,
          params
        )
        .then((response) => {
          // console.log(response.data);
          message.success(response.data.message);

        })
        .catch((error) => {
          // console.log(error);
          message.error(resposne.data.message);
          // errorMessage.value = error;
        });

    };

        //add item into global library
    const AddIntoGlobalDict=(item)=>{

     
      var params = new URLSearchParams();

      params.append("keytablename", encodeURIComponent(currentTableName.value));
      params.append("action", 'append');
      params.append("userid", localStorage.getItem('userid'));

      params.append("xltest", encodeURIComponent(item.xltest));
      params.append("xltestcd", encodeURIComponent(item.xltestcd));
      params.append("xlmodify", encodeURIComponent(item.xlmodify));

      params.append("xlcat", encodeURIComponent(item.xlcat));
      params.append("xlscat", encodeURIComponent(item.xlscat));
      params.append("xltype", encodeURIComponent(item.xltype));

      params.append("protocolid", encodeURIComponent(item.protocolid));
      params.append("studyid", encodeURIComponent(item.studyid));   
      
      params.append("xlcomment", encodeURIComponent(item.xlcomment));

      axios
        .post(
          `terms/nmpa-dict-new.php`,
          params
        )
        .then((response) => {
          // console.log(response.data);
          message.success(response.data.message);

        })
        .catch((error) => {
          // console.log(error);
          message.error(resposne.data.message);
          // errorMessage.value = error;
        });

    };

    //upload modal operation
    // const getUserStudyList=(obj)=>{

    //   //retrieve the protocol and study list from database;
    //   state.selectedRowKeys.value = [];
    //   columnTitle.value="";

    //   var params = new URLSearchParams();
    //   var strList = new Array();
    //   strList = obj.key.split("-");

    //   // params.append("level", encodeURIComponent(obj.keyPath.length));
    //   params.append("uid", localStorage.getItem('userid').toUpperCase());
    //   params.append("keylevel", encodeURIComponent(strList[0]));
    //   params.append("keyname", encodeURIComponent(strList[1]));
    //   params.append("keyvalue", encodeURIComponent(strList[3].split(" ")[0].toUpperCase()));

    //   currentTableName.value = obj.keyPath[obj.keyPath.length - 1];

    //   var strRootList = new Array();
    //   strRootList = currentTableName.value.split("-");
    //   params.append("keyscope", encodeURIComponent(strRootList[0]));
    //   params.append("keytype", encodeURIComponent(strRootList[2]));
    //   params.append("keycategory", encodeURIComponent(strRootList[1]));
    //   params.append("keytablename", encodeURIComponent(currentTableName.value));

    //   localStorage.setItem("keytablename",encodeURIComponent(currentTableName.value));

    //   if (
    //     strRootList[0] == "study" &&
    //     strRootList[1] == "variable" &&
    //     strRootList[2] == "label"
    //   ) {
    //     columnsList.value =lang.value==='cn'? config.columnVariableLabelCN:config.columnVariableLabelEN ;
    //   } else if (
    //     strRootList[0] == "study" &&
    //     strRootList[1] == "dataset" &&
    //     strRootList[2] == "label"
    //   ) {
    //     columnsList.value = lang.value==='cn'? config.columnDatasetLabelCN:config.columnDatasetLabelEN;
    //   } else if (
    //     strRootList[0] == "study" &&
    //     strRootList[1] == "variable" &&
    //     strRootList[2] == "logic"
    //   ) {
    //     columnsList.value = lang.value==='cn'? config.columnVariableLogicCN:config.columnVariableLogicEN;
    //   } else if (
    //     strRootList[0] == "global" &&
    //     strRootList[1] == "variable" &&
    //     strRootList[2] == "label"
    //   ) {
    //     columnsList.value = lang.value==='cn'? config.columnGlobalVariableLabelCN:config.columnGlobalVariableLabelEN;
    //   } else if (
    //     strRootList[0] == "global" &&
    //     strRootList[1] == "dataset" &&
    //     strRootList[2] == "label"
    //   ) {
    //     columnsList.value = lang.value==='cn'?config.columnGlobalDatasetLabelCN:config.columnGlobalDatasetLabelEN;
    //   } else if (
    //     strRootList[0] == "global" &&
    //     strRootList[1] == "variable" &&
    //     strRootList[2] == "logic"
    //   ) {
    //     columnsList.value = lang.value==='cn'?config.columnGlobalVariableLogicCN:config.columnGlobalVariableLogicEN;
    //   } else {
    //     columnsList.value = lang.value==='cn'?config.columnOtherTermCN:config.columnOtherTermEN;
    //   }
     
    //   if (strRootList[0] == "study") {
    //     isGlobalTerms.value = false;
    //   } else {
    //     isGlobalTerms.value = true;
    //   }

    //   axios
    //     .post(
    //       `terms/nmpa-dict-query-studylist.php`,
    //       params
    //     )
    //     .then((response) => {

    //       dataSourceStudy.value=response.data.records;
    //       userProtocolList.value=[];
    //       dataSourceStudy.value.forEach(function (record) {

    //          var key = record['protocolid'].toUpperCase();
    //         //  console.log(key);

    //          if (userProtocolList.value.indexOf(key) === -1) {
    //              userProtocolList.value.push(key);
    //          }
            
    //         userProtocolID.value=userProtocolList.value[0];
    //         handleUserProtocolSelect();
    //      });

    //       // console.log(userProtocolList.value);

    //     })
    //     .catch((error) => {
    //       // console.log(error);
    //       errorMessage.value = error;
    //     });

    // };

    const getUserRole=()=>{

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      //retrieve user role information, determin if admin;
      axios
        .post(
          `util/nmpa-dict-user-info.php`,
          params
        )
        .then((response) => {
            isAdmin.value=response.data.alevel;
        })
        .catch((error) => {
          console.log(error);
          // errorMessage.value = error;
            // alert(error.response.data.message);
            if (localStorage.getItem("accessToken")) {
              localStorage.removeItem("accessToken");
              
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login", query: { redirect: '/trans4esub' } });
            }else{
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login", query: { redirect: '/trans4esub' } });
            };
          return;
        });
    };

  const showGroupTranslationModal = ()=>{
      showingGroupTranslationModal.value=true;

     // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      uploadTermAccess.value=2;
      uploadTermScope.value=2;

      //populate the default value;      
      uploadDescription.value = "";

      axios
        .post(
          `terms/nmpa-dict-study-list.php`,
          params
        )
        .then((response) => {

          dataSourceStudy.value=response.data.records;
          globalProtocolList.value=[];
          dataSourceStudy.value.forEach(function (record) {
             var key = record['protocolid'].toUpperCase();
             if (globalProtocolList.value.indexOf(key) === -1) {
                 globalProtocolList.value.push(key);
             }
         });

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
  };


  const getUserStudyList=()=>{
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      axios
        .post(
          `terms/nmpa-dict-study-list.php`,
          params
        )
        .then((response) => {

          dataSourceStudy.value=response.data.records;
          // globalProtocolList.value=[];
          userProtocolList.value.push("---请选择---");
          dataSourceStudy.value.forEach(function (record) {
             var key = record['protocolid'].toUpperCase();
             if (userProtocolList.value.indexOf(key) === -1) {
                 userProtocolList.value.push(key);
             }
         });

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });

  };

   const showTaskAssignModal = () => {

      showingTaskAssignModal.value=true;

      // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      axios
        .post(
          `terms/nmpa-dict-user-list.php`,
          params
        )
        .then((response) => {

          globalUserList.value=response.data.records;
        //   globalUserList.value=[];
        //   dataSourceStudy.value.forEach(function (record) {
        //      globalUserList.value.push(record['username'].toUpperCase());
        //  });

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });

      // newVisible.value = true;
      // console.log(globalUserList);
    };

    const showUploadModal = () => {

      uploadVisible.value = true;

      // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      // //retrieve user role information, determin if admin;
      // axios
      //   .post(
      //     `util/nmpa-dict-user-info.php`,
      //     params
      //   )
      //   .then((response) => {
      //       isAdmin.value=response.data.alevel==='1'? true:false;
      //   })
      //   .catch((error) => {
      //     // console.log(error);
      //     errorMessage.value = error;
      //   });

      uploadTermAccess.value=2;
      uploadTermScope.value=2;

      //populate the default value;      
      uploadDescription.value = "";

      axios
        .post(
          `terms/nmpa-dict-study-list.php`,
          params
        )
        .then((response) => {

          dataSourceStudy.value=response.data.records;
          globalProtocolList.value=[];
          dataSourceStudy.value.forEach(function (record) {

             var key = record['protocolid'].toUpperCase();

             if (globalProtocolList.value.indexOf(key) === -1) {
                 globalProtocolList.value.push(key);
             }
         });

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
    };


    const showVariableValueListModal = (record) => {

      selectedVariableValueList.value="It is loading...";

      showingVariableValueListModal.value = true;

      // console.log(record);

      // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("studyid", record.studyid);
      params.append("varname", record.xltestcd);
      params.append("varlabel", record.xltest);
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("keyvalue", 'VALUE');
      params.append("keytablename", 'study-variable-valuelist');
      
      //  console.log(params);
      uploadTermAccess.value=2;
      uploadTermScope.value=2;

      //populate the default value;      
      uploadDescription.value = "";

      axios
        .post(
          `terms/nmpa-dict-query-terms.php`,
          params
        )
        .then((response) => {

          if (response.data.records.length){
            selectedVariableValueList.value=response.data.records[0].xlmodify.replace(/\\n/g,"\r\n");
          }
          else{
            selectedVariableValueList.value='Not found!'
          }

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
    };

    // const handleUserProtocolSelect2 =()=>{
    //   //update the studylist dynamically
    //     userStudyList.value=[];
    //     userStudyID.value='';
    //     dataSourceStudy.value.forEach(function (record) {
    //       var key = record['studyid'].toUpperCase();
    //       if (record['protocolid'].toUpperCase() == userProtocolID.value){
    //         // globalStudyList.value.push(record['studyid'].toUpperCase());
    //         if (userStudyList.value.indexOf(key) === -1) {
    //              userStudyList.value.push(key);
    //          }
    //       }
    //       userStudyID.value=userStudyList.value[0];
    //   });

    // };

    const handleUserProtocolSelect =()=>{
      //update the studylist dynamically
        // userStudyList.value=[];
        userStudyList.value=["---Show All---"];
        userStudyID.value='';
        // console.log(userProtocolID.value);    
        dataSourceOrigin.value.forEach(function (record) {
          var key = record['studyid'].toUpperCase();
          // console.log(userProtocolID.value);
          if (record['protocolid'].toUpperCase() == userProtocolID.value){
            // globalStudyList.value.push(record['studyid'].toUpperCase());
            if (userStudyList.value.indexOf(key) === -1) {
                 userStudyList.value.push(key);
             }
          }
         
          // localStorage.setItem("protocolid", userProtocolID.value);
          // localStorage.setItem("studyid", userStudyID.value);
          // localStorage.setItem("searchterm", inputValue.value);

          // this.handleSearchInput();
          // handleSearchInput();
      });

          localStorage.setItem("userStudyList", userStudyList.value);
          userStudyID.value=userStudyList.value[0];
          // console.log(userStudyID.value);
          handleSearchInput();
    };

   const uniqueCapitalLetterListSelected2=(keyname)=>{
        //  var output = [];
         var keys   = [];

        //  console.log(keyname);

         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };

    // const handleUserStudySelect=()=>{
      
    //   console.log(userStudyID.value)

    //   dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));
    //   if (userStudyID.value){
    //     dataSource.value = dataSource.value.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(inputValue.value.toLowerCase()) 
    //         ) && item.studyid.toUpperCase()==userStudyID.value
    //     );
    //   }
    //   else{
    //      dataSource.value = dataSource.value.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(inputValue.value.toLowerCase()) 
    //         ) 
    //     );
    //   }

    //   letterList.value=uniqueCapitalLetterListSelected2('xltest').sort((a, b) => (a > b) ? 1 : -1);

    //   localStorage.setItem("protocolid", userProtocolID.value);
    //   localStorage.setItem("studyid", userStudyID.value);
    //   localStorage.setItem("searchterm", inputValue.value);

    //   handleSearchInput();

    // };

    // this.userProtocolList=this.uniqueStudyList('protocolid').sort((a, b) => (a > b) ? 1 : -1);

    const handleProtocolSelect =()=>{
      //update the studylist dynamically
        globalStudyList.value=[];
        uploadStudyID.value='';
        dataSourceStudy.value.forEach(function (record) {
          var key = record['studyid'].toUpperCase();
          if (record['protocolid'].toUpperCase() == uploadProtocolID.value){
            // globalStudyList.value.push(record['studyid'].toUpperCase());
            if (globalStudyList.value.indexOf(key) === -1) {
                 globalStudyList.value.push(key);
             }
          }
          uploadStudyID.value=globalStudyList.value[0];
      });

    };

    const handleStudySelect =()=>{
      //update the studylist dynamically
        uploadDescription.value='';
      //   dataSourceStudy.value.forEach(function (record) {
      //     if (record['studyid'].toUpperCase() == uploadStudyID.value){
      //       uploadDescription.value = record['studytitle'];
      //     }
      // });

    };

    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);        
        selectedRowKeyList.value=selectedRowKeys;
        // console.log(selectedRows);
        state.selectedRowList.value=selectedRows;

        if (selectedRowKeyList.value !=""){
          successMessage.value=selectedRowKeyList.value;
        }
        else{
          successMessage.value="";
          selectedRowKeyList.value="";
        }
        
      },

      // {selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange, columnTitle:columnTitle}

      getCheckboxProps: record => ({
        // disabled: record.name === 'Disabled User',
        // // Column configuration not to be checked
        // name: record.name,
      }),
      

    };

    const handleChange = (pagination, filters, sorter) => {
      // console.log("Various parameters", pagination, filters, sorter);
      filteredInfo.value = filters;
      sortedInfo.value = sorter;
      currentPage.value = pagination.current;
      currentPageSize.value = pagination.pageSize;
      // console.log("this is currentpage:", currentPage);
    };

    const dropdownValue = "";

    const newVisible = ref(false);
    const editVisible = ref(false);
    const translationFormVisible = ref(false);
    const isLoading = ref(false);
    const isLoadingTranslation = ref(false);
    const Loading = ref(false);
    const isGlobalTerms = ref(true);
    const currentTableName = ref("global-dataset-label");

    const currentTerm = ref("");
    const originalTerm = ref("");
    const originalStatus = ref("");
    const originalComment = ref("");

    const showDrawerNew = () => {

      // console.log(userProtocolID.value);      
      // editRow.value = [];
      if (userStudyID.value != '---Show All---'){
        formNew.protocolid=userProtocolID.value;
        formNew.studyid=userStudyID.value;
        formNew.xlcat=currentTableName.value.split('-')[1].toUpperCase();
        formNew.xlscat=currentTableName.value.split('-')[2].toUpperCase();
        formNew.xltestcd="";
        formNew.xltestcd="";
        formNew.xlmodify="";
        formNew.xlcomment="";
        newVisible.value = true;
      }
      else{
        alert('请先选择需添加术语的项目号！')
      }

    };
    const showDrawerEdit = () => {
      editVisible.value = true;
    };

    

    const showDrawerTranslation = (term) => {
      // translationFormVisible.value = true;
      // console.log(term);

      isLoadingTranslation.value = true;

      var params = new URLSearchParams();
      params.append("src", encodeURIComponent(term));
      params.append("from", "en");
      params.append("to", "zh");

      //automatically translate the source with xn api
      lblTranslationStatus.value = "已完成翻译：";
      axios
        .post(
          `https://data42.cn/api/terms/nmpa-online-translator-xn.php`,
          params
        )
        .then((response) => {
          // console.log(JSON.parse(response.data).tgt_text);
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifyxn = JSON.parse(
            response.data
          ).tgt_text;
          //   this.successMessage = response.data.message;
          // lblTranslationStatus.value = "小牛翻译已完成";
          lblTranslationStatus.value = lblTranslationStatus.value + "小牛 ";
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "小牛翻译出现异常";
        });

      //automatically translate the source with baidui api

      axios
        .post(
          `https://data42.cn/api/terms/nmpa-online-translator-bd.php`,
          params
        )
        .then((response) => {
          // console.log(response.data.trans_result[0]["dst"]); //test ok
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifybd =
            response.data.trans_result[0]["dst"];

          lblTranslationStatus.value = lblTranslationStatus.value + "百度 ";
          //   this.successMessage = response.data.message;
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "Baidu翻译出现异常";
        });

      //automatically translate the source with gg api
      // lblTranslationStatus.value = "正在谷歌翻译，请稍候";
      axios
        .post(
          `https://data42.cn/api/terms/nmpa-online-translator-gg.php`,params
        )
        .then((response) => {
          // console.log(response);
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifygg = response.data["1"];
          //   this.successMessage = response.data.message;

          lblTranslationStatus.value = lblTranslationStatus.value + "谷歌  ";
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "Google翻译出现异常";
        });
      // formTranslationResults.xlmodifyxn = "this";

      isLoadingTranslation.value = false;
    };

    const selectTranslationResult = (key, translationplatform) => {
      // console.log(key);
      let strResult = "";
      if (translationplatform == "xn") {
        strResult = formTranslationResults.xlmodifyxn;
        // console.log(formTranslationResults.xlmodifyxn);
      } else if (translationplatform == "gg") {
        strResult = formTranslationResults.xlmodifygg;
      } else if (translationplatform == "bd") {
        strResult = formTranslationResults.xlmodifybd;
      } else if (translationplatform == "yd") {
        strResult = formTranslationResults.xlmodifyyd;
      } else if (translationplatform == "am") {
        strResult = formTranslationResults.xlmodifyam;
      }

      //write back to the data source;

      // console.log(strResult);

      // lblTranslationStatus.value = "翻译完成";

      dataSource.value.filter(
        (item) => key === item.id
      )[0].xlmodify = strResult;

      //additionally added for the clone copy operation due to a clone copy used as datasource for more efficiency;
      dataSourceOrigin.value.filter(
        (item) => key === item.id
      )[0].xlmodify = strResult;

      //write back to database
      var params = new URLSearchParams([]);
        params.append("action", "cell-update");
        params.append("id", key);
        params.append("xlmodify", strResult);
        params.append("original-term", originalTerm.value);
        // params.append("modified-term", currentTerm.value);
        params.append("userid",localStorage.getItem("userid"));
        params.append(
          "keytablename",
          encodeURIComponent(currentTableName.value)
        );
        // params.append(
        //   "jwt-token",
        //   encodeURIComponent(localStorage.getItem("accessToken"))
        // );
        axios
          .post(`terms/nmpa-dict-update-cell.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              // dataSource.value.filter((item) => key === item.id)[0].xlauditlog=response.data.auditlog;
              dataSource.value.filter((item) => key === item.id)[0].xlstat='ACTIVE';
            }
          });


    };

    const form = reactive({
      protocolid: "",
      studyid: "",
      seq: "",
      xltest: "",
      xltestcd: "",
      xlmodify: "",
      xlcat: "",
      xlscat: "",
      xlcomment: "",
      xltype: "",
      xlcruser: "",
      xlmouser: "",
      xlmodtc: "",
      xlauditlog: "",
    });

    const formNew = reactive({
      protocolid: "",
      studyid: "",
      seq: "",
      xltest: "",
      xltestcd: "",
      xlmodify: "",
      xlcat: "",
      xlscat: "",
      xlcomment: "",
      xltype: "",
      xlcruser: "",
      xlmouser: "",
      xlmodtc: "",
      xlauditlog: "",
    });

    const formTranslationResults = reactive({
      xlmodifyxn: "",
      xlmodifygg: "",
      xlmodifybd: "",
      xlmodifyyd: "",
      xlmodifyam: "",
    });

    const refreshSelect =()=>{
        var params = new URLSearchParams();
        params.append("action", "query");
        params.append("userid",localStorage.getItem("userid").toUpperCase());
        params.append(
          "keytablename",
          encodeURIComponent(currentTableName.value)
        );
        axios
          .post(`terms/nmpa-dict-study-list.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              console.log(response.data.records);

            }});
    };

    const cellEdit = (key) => {
      // console.log("this is for a test");
      editableData[key] = cloneDeep(
        dataSource.value.filter((item) => key === item.id)[0]
      );
      // editableData[key] = dataSource[key];
      // console.log(dataSource[key]);
      originalTerm.value = editableData[key].xlmodify;
    };

    const cellSave = (key) => {
      Object.assign(
        dataSource.value.filter((item) => key === item.id)[0],
        editableData[key]
      );

      // dataSource[key] = editableData[key];

      //additionally added for the clone copy operation due to a clone copy used as datasource for more efficiency;
      Object.assign(
        dataSourceOrigin.value.filter((item) => key === item.id)[0],
        editableData[key]
      );

      currentTerm.value=dataSource.value.filter((item) => key === item.id)[0].xlmodify;
      // console.log(originalTerm.value);
      // console.log(currentTerm.value);

      if (originalTerm.value != currentTerm.value
        // dataSourceOrigin.value[key].xlmodify != strCurrentTerm.value
      ) {
        var params = new URLSearchParams(editableData[key]);
        params.append("action", "cell-update");
        params.append("id", key);
        params.append("original-term", originalTerm.value);
        // params.append("modified-term", currentTerm.value);
        params.append("userid",localStorage.getItem("userid"));
        params.append(
          "keytablename",
          encodeURIComponent(currentTableName.value)
        );
        // params.append(
        //   "jwt-token",
        //   encodeURIComponent(localStorage.getItem("accessToken"))
        // );
        axios
          .post(`terms/nmpa-dict-update-cell.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              dataSource.value.filter((item) => key === item.id)[0].xlauditlog=response.data.auditlog;
              dataSource.value.filter((item) => key === item.id)[0].xlstat='ACTIVE';
            }
          });
      }
      delete editableData[key];
    };

    const onCloseNew = () => {
      newVisible.value = false;
      editVisible.value = false;
      uploadVisible.value=false;
      translationFormVisible.value = false;
      form.value = [];
    };
    const onCloseEdit = () => {
      newVisible.value = false;
      editVisible.value = false;
      uploadVisible.value=false;
      translationFormVisible.value = false;
      form.value = [];
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const onCloseTranslationForm = () => {
      translationFormVisible.value = false;
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const handleUploadChange = (info) => {
      if (info.file.status !== "uploading") {
        console.log(info.file);
      }

      if (info.file.status === "done") {
        message.success(`${info.file.name} file uploaded successfully`);
        // console.log(this.file);
      } else if (info.file.status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    };

    const incrementNumber = () => {
      let i = 0;
      return (index) => {
        if (pagination.current === 1) {
          return index++;
        }
        return (i = i + 1);
      };
    };

    const fromCurrentIndex = incrementNumber();

    const pagination = {
      pageSize: 10, // 默认每页显示数量
      position: "top",
      showSizeChanger: true, // 显示可改变每页数量
      pageSizeOptions: ["5", "10", "20", "50", "100"], // 每页数量选项
      showTotal: (total) => lang.value==='cn'?'总共' + ` ${total} 条` + pageTotalLabel.value: 'Total' + ` ${total} ` + pageTotalLabel.value, // 显示总数
      showSizeChange: (current, pageSize) => (this.pageSize = pageSize), // 改变每页数量时更新显示
    };

    const state = reactive({
      rootSubmenuKeys: [
        "global-terms-library",
        "study-dataset-label",
        "study-variable-label",
        "study-variable-logic",
        "study-variable-codelist",
        "study-crf-question",
        "study-crf-annotation",
        "study-ct-drugname",
        "study-ct-other",
       
      ],

      selectedRowKeys: [],
      selectedRows: [],
      selectedRowList: [],

      openKeys: [], //openKeys: ["study-variable-label"],
      groupData: [],
      value: [],
      fetching: false,
      pagination,
      selectedKeys: [],
      options: [],
      searchText: "",
      destroy: true,
      searchedColumn: "",
    });

    const hasSelected = computed(() => state.selectedRowKeys.length > 0);

    const onSelectChange = (selectedRowKeys,selectedRows) => {
      // console.log('selectedRowKeys changed: ', selectedRowKeys);

      state.selectedRows=selectedRows;

      state.selectedRowKeys = selectedRowKeys;

      var selectedTerms='';

      // console.log(state.selectedRows);
      for (var item in state.selectedRows){
        selectedTerms+=state.selectedRows[item].xltest + ""; 
      }

      // console.log(selectedTerms);
      
      // selectedRowKeyList.value=selectedRowKeys;
        // console.log(state.selectedRowKeys);
        
        if (state.selectedRowKeys.length>0){
                // console.log(selectedTermsLength);    
            if (lang.value==='cn'){
              successMessage.value="已选定 " + state.selectedRowKeys.length + " 条术语 (" + selectedTerms.length + " 字符)";
            }
            else{
              successMessage.value=state.selectedRowKeys.length + " rows selected. (" + selectedTerms.length + " characters)";
            }
          // successMessage.value=state.selectedRowKeys.length + " rows selected.";
          // successMessage.value=state.selectedRowKeys;
          // successMessage.value=state.selectedRowKeys.length + " rows selected. \n\n" + state.selectedRowKeys
        }
        else{
          successMessage.value="";
          errorMessage.value="";
          // state.selectedRowKeys.value="";
        }
    };

    const current1 = ref(1);
    const current2 = ref(2);
    const current = ref(1);
    const pageSizeRef = ref(10);
    const pageSizeOptions = ref(["5", "10", "20", "50", "100", "200"]);
    const total = ref(50);

    //for the in-cell edit ;
    const dataSource = ref([]);
    const dataSourceOrigin = ref([]);
    const dataSourceStudy = ref([]);
    const count = computed(() => this.dataSource.length + 1);
    // const editableData = reactive({});

    const onShowSizeChange = (current, pageSize) => {
      // console.log(pageSize);
      pageSizeRef.value = pageSize;
    };

    const onChange = (pageNumber) => {
      console.log("Page: ", pageNumber);
    };

    const onOpenChange = (openKeys) => {
      const latestOpenKey = openKeys.find(
        (key) => state.openKeys.indexOf(key) === -1
      );

      if (state.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
        state.openKeys = openKeys;
      } else {
        state.openKeys = latestOpenKey ? [latestOpenKey] : [];
      }
    };

    const handleSearch = (selectedKeys, confirm, dataIndex) => {
      confirm();
      state.searchText = selectedKeys[0];
      state.searchedColumn = dataIndex;
    };

    const handleReset = clearFilters => {
      clearFilters();
      state.searchText = '';
    };

    return {
      ...toRefs(state),
      dueDate,
      loadText,
      getUniqueArray,
      // onFinish,
      queryKeyValue,
      totalTerms,
      totalLockedTerms,
      totalInitialTerms,
      totalActiveTerms,
      totalPendingTerms,
      totalAPITerms,
      formNew,
      pageTotalLabel,
      AddIntoAPIMemory,
      AddIntoGlobalDict,
      updatePasscode,
      updateTermsReviewer,
      // handleNewStudy,
      handleSearchInput,
      uniqueCapitalLetterListSelected,
      uniqueCapitalLetterListSelected2,
      getUserStudyList,
      userProtocolList,
      userStudyList,      
      strColumnList,
      strColumnListN,
      globalProtocolList,
      globalStudyList,
      lang,
      inputValue,
      letterList,
      statusList,
      userconfig,
      uploadVisible,
      progressValue,
      uploadFile,
      beforeUpload,
      uploadTerms,
      defaultPercent,
      handleUploadChange,
      userProtocolID,
      uploadProtocolID,
      userStudyID,
      userPasscode,
      taskAssignedUserList,
      generatePasscode,
      uploadStudyID,
      uploadFileWithoutDuplicate,
      uploadDescription,
      uploadComment,
      uploadTermScope,
      uploadTermAccess,
      uploadTermCategory,
      uploadTermType,
      handleUserProtocolSelect,
      // handleUserStudySelect,
      handleProtocolSelect,
      handleStudySelect,
      radioStyle,
      isAdmin,
      getUserRole,
      selectedUserList,
      selectedProjectList,
      selectedVariableValueList,
      assignedReviewersEmail,
      filteredUserList,
      globalUserList,
      activeKey,
      showingTaskAssignModal,
      showingWhiteBoardModal,
      showingGroupTranslationModal,
      showingVariableValueListModal,
      showTaskAssignModal,
      showGroupTranslationModal,
      showUploadModal,
      refreshSelect,
      onSelectChange,
      hasSelected,
      columnTitle,
      selectedRowKeyList,
      // selectedRowList,
      rowSelection,
      handleSearch,
      handleReset,
      searchText: '',
      searchInput,
      searchedColumn: '',
      // clickedItem,
      strUserName,
      originalTerm,
      originalStatus,
      originalComment,
      currentTerm,
      lblTranslationStatus,
      showDrawerTranslation,
      showVariableValueListModal,
      selectTranslationResult,
      onCloseTranslationForm,
      isLogin,
      translationFormVisible,
      onOpenChange,
      pageSizeOptions,
      current,
      form,
      formTranslationResults,
      dropdownValue,
      // EditableCell,
      editableData,
      cellEdit,
      cellSave,
      // onSubmitEdit,
      currentPage,
      currentPageSize,
      // listAllRecords,
      columnsList,
      dataSource,
      dataSourceOrigin,
      dataSourceStudy,
      Loading,
      handleChange,
      // uploading,
      // handleRemove,
      // beforeUpload,
      // handleUpload,
      headers: {
        authorization: "authorization-text",
      },
      // fileList,
      isLoading,
      isLoadingTranslation,
      isGlobalTerms,
      currentTableName,
      pagination,
      pageSize: pageSizeRef,
      total,
      onShowSizeChange,
      current1,
      current2,
      onChange,
      // onCellEdit,
      // onCellSave,
      onCloseNew,
      onCloseEdit,
      // onSubmit,
      showDrawerNew,
      showDrawerEdit,
      successMessage,
      errorMessage,
      // edit,
      // options,
      // save,
      state,
      count,
      newVisible,
      editVisible,
      collapsed: ref(false),
      selectedKeys: ref(["1"]),
    };
  },

  mounted: function () {
    // console.log(this.options);
    // var parameter = this.inputValue;
    // this.columnsList = this.userconfig.columnVariableListCN;
    // console.log(this.columnsList);
    //this.options;
    // this.total=this.users.length;
    //this.getAllObservations("A");
    // console.log(dataSource);
    this.strUserName=localStorage.getItem("username");
    this.lang=localStorage.getItem("country_code").toUpperCase()==='CN'?'cn':'en';
    

    this.getUserRole();
    // this.getUserStudyList();

    // console.log(localStorage.getItem("userid"))
    // console.log(localStorage.getItem("email"))

    this.queryKeyValue=localStorage.getItem("query-key-value");
    this.queryWithLastOperation();

    var loginDateTime = new Date(parseInt(localStorage.getItem('loginDateTime'))).getTime();

    // console.log(loginDateTime)

    // this.dueDate=Date.now()+ 1000 * 60 * 60 * 24 * 2 ;
    this.dueDate=loginDateTime+ 1000 * 60 * 60 * 12;
    // this.dueDate=loginDateTime+ 1000 * 60;

    // console.log(this.dueDate);

  },
  // watch:{
  // 	'$route':'getSelectedUsers'
  // },

 computed: {
   uniqueCapitalLetterList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
    },

   dataSource: function () {
      // iterate over items
      return this.dataSourceOrigin.map(item => {
        // copy current item
        const current = Object.assign({}, item);
        // iterate over item keys
        Object.keys(current).forEach(key => {
          // if value of this key is a string, replace
          if(typeof current[key] === 'string')
            current[key] = current[key].replace(/↵/g, '\n');
        });
        return current;
      });
    },

  //  uniqueCapitalLetterListSelected: function () {
  //     var vm = this;
  //     return function (keyname) {
  //       //  var output = [];
  //        var keys   = [];

  //        vm.dataSource.forEach(function (record) {
  //            var key = record[keyname].substring(0,1).toUpperCase();

  //            if (keys.indexOf(key) === -1) {
  //                keys.push(key);
  //               //  output.push(record);
  //            }
  //        });

  //        return keys;
  //     };
  //  },

   uniqueValueList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname];

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },
   uniqueStudyList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
        //  var keys   = [];
        var keys   = ["---Show All---"];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },


},

  watch:{
      columnsList:function(){
        console.log(this.columnsList);
      }

  },

  methods: {

    bodyClick() {
      this.menuVisible = false;
      document.body.removeEventListener("click", this.bodyClick);
      },    

    changeLocale(locale) {

      if (this.lang =='cn'){
        this.lang ='en'
      }
      else if (this.lang =='en'){
        this.lang ='cn'
      }
      // this.lang = locale;

      localStorage.setItem("country_code",this.lang);
      // this.columnsList=[];
      var strRootList = new Array();
      strRootList = localStorage.getItem("keytablename").split("-");

      if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
        this.pageTotalLabel=this.lang==='cn'?"变量标签":"variable labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
        this.pageTotalLabel=this.lang==='cn'?"数据集标签":"dataset labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
        this.pageTotalLabel=this.lang==='cn'?"变量逻辑":"variable logics";
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "terms" &&
        strRootList[2] == "library"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      }

        // console.log(locale);
    },

    logout() {
      if (localStorage.getItem("accessToken")) {
        localStorage.removeItem("accessToken");
        this.$router.push({ path: process.env.VUE_APP_baseURL +"login" });
      }
    },

    onFinish() {
      alert("Token已过期，请重新登录！");
      if (localStorage.getItem("accessToken")) {
        localStorage.removeItem("accessToken");
        this.$router.push({ path: process.env.VUE_APP_baseURL +"login" });
      }
    },

    handleNewStudy(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"config" });
    },

    handleStudyTracker(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"studytracker" });
    },
    
    handleUserLogConfig(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"config" });
    },

    handleUserProfile(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"contacts" });
    },

    handleUserAssessment(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"assessment" });
    },

    handleMyAssignments(){
      this.$router.push({ path: process.env.VUE_APP_baseURL+"terms-review" });
    },

    getAllObservations(searchItemValue) {
      this.isLoading = true;

      var params = new URLSearchParams();
      params.append("action", encodeURIComponent("read"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      params.append("keyname", encodeURIComponent("xltest-xltestcd-xlmodify"));
      params.append("keyvalue", encodeURIComponent(searchItemValue));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-query.php`, params)
        .then((response) => {
          // console.log(response);
          this.clearMessage;
          this.dataSource = response.data.records;
          this.isLoading = false;
          // console.log(this.dataSource);
          //   this.successMessage = response.data.message;
        })
        .catch((error) => {
          // console.log(error);
          this.errorMessage = error.data.message;
        });
    },

    customUploadRequest: function (data) {
      // console.log("submit");
      const formData = new FormData();
      formData.append("file", data.file);
      // formData.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          "terms/nmpa-dict-label-upload.php?action=upload",
          formData
        )
        .then((response) => {
          this.fileList.push({
            uid: "00000001",
            name: data.file.name,
            status: "done",
            response: response,
          });
          // console.log(this.fileList);
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            this.getAllObservations();
          }
        });
    },

    onRowDelete: function (id) {
      this.dataSource.value = this.dataSource.value.filter(
        (item) => item.id !== id
      );
    },

    updateItem: function () {
      var formData = this.toFormData(this.clickedItem);
      params.append("action", "update");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-query.php", formData)
        .then((response) => {
          // console.log(response);
          this.clickedItem = this.editData;
          // this.clickedItem = {};
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            // this.getAllObservations();
          }
        });
    },

    onRowCopy: function (record) {
      // this.visible.value = false;
      var params = new URLSearchParams(record);
      params.append("action", "rowcopy");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-new.php", params)
        .then((response) => {
          // console.log(response);
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            //this.getAllObservations();
          }
        });
    },

    onSubmitNew: function () {
      // this.visible.value = false;
      var params = new URLSearchParams(this.formNew);
      params.append("action", "create");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-new.php", params)
        .then((response) => {
          // console.log(response);
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            //update the clone table;
            // console.log(this.formNew);

            // console.log(this.dataSource);

            // this.dataSource.push(this.formNew);


            // console.log(response);
            //this.getAllObservations();
          }
        });
    },

    onSubmitEdit: function () {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (this.strUserName);
      
      var params = new URLSearchParams(this.form);
      // console.log(this.clickedItem.xlmodify);
      // console.log(this.form.xlmodify);
      
      this.originalTerm=this.clickedItem.xlmodify;
      this.originalStatus=this.clickedItem.xlstat;
      this.originalComment=this.clickedItem.xlcomment;

      params.append("action", "row-update");
      params.append("userid",localStorage.getItem("userid"));
      params.append("original-term", this.originalTerm);
      params.append("original-comment", this.originalComment);
      params.append("original-status", this.originalStatus);
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-update-row.php`, params)
        .then((response) => {
          // console.log( this.editRow);
          // console.log(this.form);
          Object.assign(this.clickedItem, this.form);          

          //additionally added for the updates of original copy;
          Object.assign(
            this.dataSourceOrigin.filter((item) => item.id === this.form.id)[0],
            this.form
          );
          // this.clickedItem = this.editRow;
          if (response.data.error) {
            // console.log(response);
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // console.log(response);
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            this.editVisible = false;
            this.dataSource.filter((item) => this.form.id === item.id)[0].xlauditlog=response.data.auditlog;

            // this.getAllObservations();
            // console.log(this.successMessage);
          }
        });
    },

    uploadFile: function () {

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      var params = new URLSearchParams();
      // params.append('id', recordKey);
      params.append("userid",localStorage.getItem("userid"));
      params.append("action","upload-csv");

      const { fileList } = this;
      fileList.forEach((file) => {
        params.append("file", file);
      });

      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `util/nmpa-dict-upload-csv.php`,params
        )
        .then((response) => {
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            // console.log(response.data);
          }
        });
    },

    edit(rowData) {
      let _editData = {};
      Objects.assign(_editData, rowData); //浅拷贝对象
      this.editData = _editData;
    },

    removeItem: function (recordKey, status, auditlog) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData.xlauditlog);
      var params = new URLSearchParams();
      params.append("id", recordKey);
      params.append("action", "delete");
      params.append("userid",localStorage.getItem("userid"));
      params.append("original-status", status);
      params.append("original-auditlog", auditlog);
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-governance.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => item.id !== recordKey
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => item.id !== recordKey
            );

            // this.getAllObservations();
          }
        });
    },
  
    termsGovernance: function (recordKey, action, value, status, auditlog) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("id", recordKey);
      params.append("action", action);

      params.append("userid",localStorage.getItem("userid"));
      params.append("original-status", status);
      params.append("original-auditlog", auditlog);

      params.append("keytablename", encodeURIComponent(this.currentTableName));

      // console.log (params);

      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-governance.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            this.clickedItem.xlstat = value;

            //additionally added for the updates of original copy;
            Object.assign(
              this.dataSourceOrigin.filter((item) => item.id === recordKey)[0],
              this.clickedItem
            );

           this.dataSource.filter((item) => recordKey === item.id)[0].xlauditlog=response.data.auditlog;

            // this.dataSource.value.filter((item) => recordKey === item.id)[0];

            // this.getAllObservations();
          }
        });
    },

    lockAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("lockall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-lockall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='LOCKED';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='LOCKED';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

  unlockAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("unlockall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-unlockall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ACTIVE';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ACTIVE';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

  archiveAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("archiveall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-archiveall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ARCHIVED';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ARCHIVED';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

  pendingAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("pendingall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-pendingall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='PENDING';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='PENDING';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },


  readyForQCAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("ready4qc"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-readyforqcall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='READY';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='READY';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

   handleAPITranslationBatch: function (keylist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("from", "en");
      params.append("to", "zh");

      //retrieve the text according to the keylist

      // console.log(this.state.selectedRows)

      var selectedTerms='';
      var seq=0;

      // console.log(state.selectedRows);

      //handling the carriage character

      for (var item in this.state.selectedRows){   
        if(seq==0 && this.state.selectedRows[item].xltest!=null && this.state.selectedRows[item].xltest!=''){
          // selectedTerms=this.state.selectedRows[item].xltest.replace('\n','####')
          selectedTerms=this.state.selectedRows[item].xltest
        } 
        else if(this.state.selectedRows[item].xltest!=null && this.state.selectedRows[item].xltest!=''){
          // selectedTerms=selectedTerms+ '\n' + this.state.selectedRows[item].xltest.replace('\n','####'); 
          selectedTerms=selectedTerms+ '\n' + this.state.selectedRows[item].xltest; 
        }        
        seq+=1;
      }
      // console.log(selectedTerms);
      params.append("src_text", selectedTerms);
      // params.append(
      //     "jwt-token",
      //     encodeURIComponent(localStorage.getItem("accessToken"))
      //   );
      params.append(
          "Content-Type",
          "“application/x-www-form-urlencoded;charset=utf-8”"
      );
      axios
        .post(
          `https://data42.cn/api/terms/nmpa-online-translator.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error('批量翻译失败，请检查后再试！');
          } else {
            // this.successMessage = response.data.message;
            message.success('已成功完成翻译，正写入数据库，请稍后...');
            // this.getAllObservations();
            var res=JSON.parse(response.data).tgt_text.trim();
            var src_txt=selectedTerms.trim().split('\n');
            var tgt_txt=res.split('\n');
            // console.log(src_txt)
            // console.log(tgt_txt)

            //update the status;
            this.dataSource.filter(function (record) {   
                for (var j = 0; j < tgt_txt.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===src_txt[j]){
                    record['xlmodify']=tgt_txt[j]
                     record['xlstat']='API';
                  }
                }                
          });

            this.dataSourceOrigin.forEach(function (record) {

                for (var j = 0; j < tgt_txt.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===src_txt[j]){
                    record['xlmodify']=tgt_txt[j]
                     record['xlstat']='API';
                  }
                }               
          });

          //update bakend database with the corresponding source and target;
          var params = new URLSearchParams();
          params.append("keylist", encodeURIComponent(keylist));
          params.append("action", encodeURIComponent("batch-translation"));
          params.append("userid",localStorage.getItem("userid"));
          params.append("src_txt", encodeURIComponent(selectedTerms.trim()));
          params.append("tgt_txt", encodeURIComponent(res));
          params.append("dlm", encodeURIComponent('\n'));

          params.append("keytablename", encodeURIComponent(this.currentTableName));
          axios
            .post(
              `terms/nmpa-api-translator-batch-v3.php`,
              params
            )
            .then((response) => {
              // console.log(response);
              // this.clickedItem = {};
              if (response.data.error) {
                // this.errorMessage = response.data.message;
                message.error(response.data.message);
              } else {
                // this.successMessage = response.data.message;
                message.success(response.data.message);
                // this.getAllObservations();

              }
              
            });
          }
          this.isLoading=false;
        });
    },

    handleAPITranslationBatch_OLD: function (keylist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      axios
        .post(
          `terms/nmpa-api-translator-batch-v2.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();

            // console.log(response.data.source.length, response.data.target.length)

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0) {
                    record['xlstat']='API';
                }

                for (var j = 0; j < response.data.source.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===response.data.source[j]){
                    record['xlmodify']=response.data.target[j]
                  }
                }                
          });

            this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0) {
                    record['xlstat']='API';
                }

                for (var j = 0; j < response.data.source.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===response.data.source[j]){
                    record['xlmodify']=response.data.target[j]
                  }
                }                
            });
          }
          this.isLoading=false;
        });
    },

    handleTermsTranslationBatch: function (keylist, protocollist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("protocollist", encodeURIComponent(protocollist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      // console.log(protocollist);

      axios
        .post(
          `terms/nmpa-terms-translator-batch.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();
            this.queryWithLastOperation();


          }
          this.isLoading=false;
        });

        showingGroupTranslationModal=false;
    },


    handleDictionaryTranslationBatch: function (keylist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      axios
        .post(
          `terms/nmpa-dict-translator-batch.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();
            this.queryWithLastOperation();


          }
          this.isLoading=false;
        });
    },

    removeAllItem: function (keylist,deltype) {
      // console.log (keylist);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (keylist);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("deltype",deltype);
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `terms/nmpa-dict-delete-records.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => keylist.indexOf(item.id) ===-1
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => keylist.indexOf(item.id)===-1
            );
            // this.getAllObservations();
          }
        });
    },


    undeleteAllItem: function (keylist) {
      // console.log (keylist);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (keylist);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      // params.append("deltype",deltype);
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `terms/nmpa-dict-undelete-records.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0) {
                    record['xlstat']='ACTIVE';
                }
         
            });

            this.dataSourceOrigin.forEach(function (record) {
                  var key = record['id'];
                  // console.log(key, keylist.indexOf(key), keylist)
                  if (keylist.indexOf(key) >=0 ) {
                      record['xlstat']='ACTIVE';
                  }
        
            });

            // this.getAllObservations();
          }
        });
    },

    selectCurrentItem: function (item) {
      Object.assign(this.editRow, item);
      this.clickedItem = item;
      // console.log(this.editRow);
      this.form = this.editRow;
    },

    toFormData: function (obj) {
      var form_data = new FormData();
      for (var key in obj) {
        form_data.append(key, obj[key]);
      }
      return form_data;
    },

    clearMessage: function () {
      this.errorMessage = "";
      this.successMessage = "";
    },

    queryUserTermsByStudy: function (obj) {

      console.log(obj);

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      this.columnTitle="";

      var params = new URLSearchParams();
      var strList = new Array();
      strList = obj.key.split("-");

      // params.append("level", encodeURIComponent(obj.keyPath.length));
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("keylevel", encodeURIComponent(strList[0]));
      params.append("keyname", encodeURIComponent(strList[1]));
      params.append("keyvalue", encodeURIComponent(strList[3].split(" ")[0].toUpperCase()));

      // params.append("action", encodeURIComponent("read"));

      //retrieve the root key;

      this.currentTableName = obj.keyPath[0];

      var strRootList = new Array();
      strRootList = this.currentTableName.split("-");
      params.append("keyscope", encodeURIComponent(strRootList[0]));
      params.append("keytype", encodeURIComponent(strRootList[2]));
      params.append("keycategory", encodeURIComponent(strRootList[1]));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      localStorage.setItem("keytablename",encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );

    if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
        this.pageTotalLabel=this.lang==='cn'?"变量标签":"variable labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
        this.pageTotalLabel=this.lang==='cn'?"数据集标签":"dataset labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
        this.pageTotalLabel=this.lang==='cn'?"变量逻辑":"variable logics";
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "terms" &&
        strRootList[2] == "library"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnTermsCN:this.userconfig.columnTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      }

      if (strRootList[0] == "study") {
        this.isGlobalTerms = false;
      } else {
        this.isGlobalTerms = true;
      }

      // if (
      //   strRootList[0] == "study" &&
      //   strRootList[1] == "variable" &&
      //   strRootList[2] == "label"
      // ) {
      //   this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
      // } else if (
      //   strRootList[0] == "study" &&
      //   strRootList[1] == "dataset" &&
      //   strRootList[2] == "label"
      // ) {
      //   this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
      // } else if (
      //   strRootList[0] == "study" &&
      //   strRootList[1] == "variable" &&
      //   strRootList[2] == "logic"
      // ) {
      //   this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
      // } else if (
      //   strRootList[0] == "global" &&
      //   strRootList[1] == "variable" &&
      //   strRootList[2] == "label"
      // ) {
      //   this.columnsList = this.lang==='cn'? this.userconfig.columnGlobalVariableLabelCN:this.userconfig.columnGlobalVariableLabelEN;
      // } else if (
      //   strRootList[0] == "global" &&
      //   strRootList[1] == "dataset" &&
      //   strRootList[2] == "label"
      // ) {
      //   this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalDatasetLabelCN:this.userconfig.columnGlobalDatasetLabelEN;
      // } else if (
      //   strRootList[0] == "global" &&
      //   strRootList[1] == "variable" &&
      //   strRootList[2] == "logic"
      // ) {
      //   this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalVariableLogicCN:this.userconfig.columnGlobalVariableLogicEN;
      // } else {
      //   this.columnsList = this.lang==='cn'?this.userconfig.columnOtherTermCN:this.userconfig.columnOtherTermEN;
      // }

      // console.log(strRootList);

      if (strRootList[0] == "study") {
        this.isGlobalTerms = false;
      } else {
        this.isGlobalTerms = true;
      }

      //add response block when error returned;

      // axios.interceptors.response.use(
      //   (response) => {
      //     return response;
      //   },
      //   (error) => {
      //     //alert(error.response.status);
      //     if (error.response) {
      //       if (error.response.status === 401) {
      //         this.errorMessage = error.response.data.message;
      //         alert(error.response.data.message); //console.log(error.response);
      //         this.$router.push({ path: this.$router.currentRoute.value.fullPath || "/login" });
      //       }
      //     }
      //   }
      // );

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "terms/nmpa-dict-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          this.inputValue = "";

          this.dataSourceOrigin = response.data.records;

          this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

          // console.log(this.uniqueValueList('xltest'));

          this.letterList=this.uniqueCapitalLetterList('xltest').sort((a, b) => (a > b) ? 1 : -1);

          this.studylist=this.uniqueStudyList('studyid').sort((a, b) => (a > b) ? 1 : -1);

          //save the current query condition into the local storage
          localStorage.setItem("query-params",params);

          // delete this.columnsList[2];
          // console.log(this.columnsList);

          // this.columnsList.splice(3,0,{
          //   title: "English Label",
          //   dataIndex: "xltest",
          //   width: 350,
          //   key: "xltest",
          //   // ellipsis: true,
          //   slots: {
          //       customRender: "xltest",
          //   },
          //   sorter: (a, b) => a.xltest.length - b.xltest.length,
          //   sortDirections: ['descend', 'ascend'],
          // });

          // console.log(this.columnsList);

          // console.log(this.letterList.sort((a, b) => (a > b) ? 1 : -1));
        })
        .catch((error) => {
          // console.log(error);
          // this.errorMessage = error.response.data.message;
          this.isLoading = false;

          // alert(error.response.data.message);
            if (localStorage.getItem("accessToken")) {
              localStorage.removeItem("accessToken");
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            }else{
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            };
          return;
          // alert(error.message);
          // logout();
        });
    },

    queryTermsByMenuiItems: function (obj) {

      // console.log(obj);

      // console.log(this.isAdmin);

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      this.columnTitle="";

      var params = new URLSearchParams();
      var strList = new Array();
      strList = obj.key.split("-");

      // params.append("level", encodeURIComponent(obj.keyPath.length));
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("keylevel", encodeURIComponent(strList[0]));
      params.append("keyname", encodeURIComponent(strList[1]));

      this.queryKeyValue = encodeURIComponent(strList[3].split(" ")[0].toUpperCase());
      localStorage.setItem("query-key-value",this.queryKeyValue);
      params.append("keyvalue", this.queryKeyValue);

      // params.append("action", encodeURIComponent("read"));

      //retrieve the root key;

      if (obj.keyPath[0]==='global-terms-library'){
         var strList2 = new Array();
         strList2 = obj.key.split("-");
         this.currentTableName = "global-" + strList2[2]+"-"+strList2[3];
      }
      else{
        this.currentTableName = obj.keyPath[0];
      }
     

      var strRootList = new Array();
      strRootList = this.currentTableName.split("-");
      params.append("keyscope", encodeURIComponent(strRootList[0]));
      params.append("keytype", encodeURIComponent(strRootList[2]));
      params.append("keycategory", encodeURIComponent(strRootList[1]));
      params.append("keytablename", encodeURIComponent(this.currentTableName));



      localStorage.setItem("keytablename",encodeURIComponent(this.currentTableName));

      if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
        this.pageTotalLabel=this.lang==='cn'?"变量标签":"variable labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
        this.pageTotalLabel=this.lang==='cn'?"数据集标签":"dataset labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
        this.pageTotalLabel=this.lang==='cn'?"变量逻辑":"variable logics";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "crf" &&
        strRootList[2] == "question"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnCRFQuestionCN:this.userconfig.columnCRFQuestionEN;
        this.pageTotalLabel=this.lang==='cn'?"CRF术语":"CRF Terms";
      }else if (
        strRootList[0] == "global" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnGlobalVariableLogicCN:this.userconfig.columnGlobalVariableLogicEN;
        this.pageTotalLabel=this.lang==='cn'?"变量逻辑":"variable logics";
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "crf" &&
        strRootList[2] == "question"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnGlobalCRFQuestionCN:this.userconfig.columnGlobalCRFQuestionEN;
        this.pageTotalLabel=this.lang==='cn'?"CRF术语":"CRF Terms";
      } else if (
        strRootList[0] == "global" &&
        (strRootList[1] == "dataset" || strRootList[1] == "variable" || strRootList[1] == "ct" ) &&
        (strRootList[2] == "label" || strRootList[2] == "codelist" || strRootList[1] == "drugname" || strRootList[1] == "other")
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      }else if (
        strRootList[0] == "global" &&
        (strRootList[1] == "terms") &&
        (strRootList[2] == "pending")
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsPendingCN:this.userconfig.columnGlobalTermsPendingEN;
        this.pageTotalLabel=this.lang==='cn'?"待审术语":"terms";
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnOtherTermCN:this.userconfig.columnOtherTermEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      }

      if (strRootList[0] == "study") {
        this.isGlobalTerms = false;
      } else {
        this.isGlobalTerms = true;
      }

      // console.log(this.isAdmin);

      // console.log(this.pageTotalLabel);

      //add response block when error returned;

      // axios.interceptors.response.use(
      //   (response) => {
      //     return response;
      //   },
      //   (error) => {
      //     //alert(error.response.status);
      //     if (error.response) {
      //       if (error.response.status === 401) {
      //         this.errorMessage = error.response.data.message;
      //         alert(error.response.data.message); //console.log(error.response);
      //         this.$router.push({ path: this.$router.currentRoute.value.fullPath || "/login" });
      //       }
      //     }
      //   }
      // );

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "terms/nmpa-dict-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          this.inputValue = "";

          this.dataSourceOrigin = response.data.records;

          this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

          // console.log(this.uniqueValueList('xltest'));

          this.userProtocolID="";

          this.letterList=this.uniqueCapitalLetterList('xltest').sort((a, b) => (a > b) ? 1 : -1);
          this.userProtocolList=this.uniqueStudyList('protocolid').sort((a, b) => (a > b) ? 1 : -1);


          // console.log("debug", this.userProtocolList, localStorage.getItem('protocolid'), this.userProtocolList.includes(localStorage.getItem('protocolid'))===false)

          // if (this.userProtocolID ==='' || (this.userProtocolID !='' && this.userProtocolList.includes(this.userProtocolID)===false)){
          //   this.userProtocolID=this.userProtocolList[0];            
          //   // this.userStudyID=this.userStudyList[0];                            
          // } 

          if (this.userProtocolList.includes(localStorage.getItem('protocolid'))===false){
              this.userProtocolID=this.userProtocolList[0];      
               this.handleUserProtocolSelect();    
               this.userStudyID=this.userStudyList[0];      
               this.handleSearchInput();     
          }
          else{
              this.userProtocolID=localStorage.getItem('protocolid');
              this.userStudyID=localStorage.getItem('studyid');
              this.handleSearchInput();   
          }
          

          // this.handleUserStudySelect();   
          // this.handleSearchInput();
         

          localStorage.setItem("userProtocolList",this.userProtocolList);

          //save the current query condition into the local storage
          localStorage.setItem("query-params",params);

          // delete this.columnsList[2];
          // console.log(this.columnsList[5]);

          // if (this.isGlobalTerms==false && ['LOCKED', 'ARCHIVED', 'DELETED'].indexOf(this.queryKeyValue)!=-1){
          //   this.columnsList[5].width=150;
          // }
          // else if (this.isGlobalTerms==false && ['INITIAL'].indexOf(this.queryKeyValue)!=-1){
          //   this.columnsList[5].width=300;
          // }
          // else if (this.isGlobalTerms==false){
          //    this.columnsList[5].width=350;
          // }
         
          // console.log(this.columnsList);

          // console.log(this.letterList.sort((a, b) => (a > b) ? 1 : -1));
        })
        .catch((error) => {
          console.log(error);
          this.errorMessage = error.response;
          this.isLoading = false;

          // alert(error.message);
          //   if (localStorage.getItem("accessToken")) {
          //     localStorage.removeItem("accessToken");
          //     this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
          //   }else{
          //     this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
          //   };
          return;
          // alert(error.message);
          // logout();
        });
    },

    queryUserStudyList: function (obj) {

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      // this.columnTitle="";

      var params = new URLSearchParams();
      var strList = new Array();
      strList = obj.key.split("-");

      // params.append("level", encodeURIComponent(obj.keyPath.length));
      params.append("uid", localStorage.getItem('userid').toUpperCase());
      params.append("keylevel", encodeURIComponent(strList[0]));
      params.append("keyname", encodeURIComponent(strList[1]));
      params.append("keyvalue", encodeURIComponent(strList[3].split(" ")[0].toUpperCase()));

      this.currentTableName = obj.keyPath[0];

      var strRootList = new Array();
      strRootList = this.currentTableName.split("-");
      params.append("keyscope", encodeURIComponent(strRootList[0]));
      params.append("keytype", encodeURIComponent(strRootList[2]));
      params.append("keycategory", encodeURIComponent(strRootList[1]));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      localStorage.setItem("keytablename",encodeURIComponent(this.currentTableName));

      if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnGlobalVariableLabelCN:this.userconfig.columnGlobalVariableLabelEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalDatasetLabelCN:this.userconfig.columnGlobalDatasetLabelEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalVariableLogicCN:this.userconfig.columnGlobalVariableLogicEN;
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnOtherTermCN:this.userconfig.columnOtherTermEN;
      }

      if (strRootList[0] == "study") {
        this.isGlobalTerms = false;
      } else {
        this.isGlobalTerms = true;
      }

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "terms/nmpa-dict-query-studylist.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          this.inputValue = "";

          this.dataSourceStudy = response.data.records;
          this.userProtocolList=[];
          this.dataSourceStudy.forEach(function (record) {

          var key = record['protocolid'].toUpperCase();
          this.userProtocolList.push(key);

             if (this.userProtocolList.indexOf(key) === -1) {
                 this.userProtocolList.push(key);
             }
         });

          // delete this.columnsList[2];
          // console.log(this.columnsList);

          // this.columnsList.splice(3,0,{
          //   title: "English Label",
          //   dataIndex: "xltest",
          //   width: 350,
          //   key: "xltest",
          //   // ellipsis: true,
          //   slots: {
          //       customRender: "xltest",
          //   },
          //   sorter: (a, b) => a.xltest.length - b.xltest.length,
          //   sortDirections: ['descend', 'ascend'],
          // });

          // console.log(this.columnsList);

          // console.log(this.letterList.sort((a, b) => (a > b) ? 1 : -1));
        })
        .catch((error) => {
          // console.log(error);
          // this.errorMessage = error.response.data.message;
          this.isLoading = false;

          alert(error.response.data.message);
            if (localStorage.getItem("accessToken")) {
              localStorage.removeItem("accessToken");
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            }else{
              this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            };
          return;
          // alert(error.message);
          // logout();
        });
    },

    clearSelection : function(){
      //reset all row selections;      
      this.errorMessage="";
      this.successMessage="";
      this.state.selectedRowKeys=[];     
      // alert(this.successMessage) 
    },

    selectAllItems : function(){
      //reset all row selections;
      this.state.selectedRowKeys=[];
      this.dataSource.filter((item) => this.state.selectedRowKeys.push(item.id));

      // this.dataSource.filter((item) => this.state.selectedRows.push(item));

      // this.state.selectedRowKeys=[];
      // console.log(this.state.selectedRowKeys);    
      
      var selectedTerms =[];
      this.dataSource.filter((item) => selectedTerms.push(item.xltest));

      var selectedTermsLength=0;

      for (var item in selectedTerms){
        selectedTermsLength+=selectedTerms[item].length; 
      }

      // console.log(selectedTermsLength);    
      if (this.lang==='cn'){
        this.successMessage="已选定 " + this.state.selectedRowKeys.length + " 条术语 (" + selectedTermsLength + " 字符)";
      }
      else{
        this.successMessage=this.state.selectedRowKeys.length + " rows selected. (" + selectedTermsLength + " characters)";
      }
     
      // this.successMessage=this.state.selectedRowKeys;
    },

    backupSelectedItemsAsXLS:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            // this.isloading=true;

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".xlsx";

            let selectedItems = [
                ['PROTOCOLID', 'STUDYID', 'CATEGORY', 'DSTYPE', 'TYPE', 'ELEMENT', 'SOURCE', 'TARGET', 'CRUSER', 'MOUSER', 'CRDTC', 'MODTC', 'COMMENT', 'STATUS', 'AUDIT']
            ] // 表格表头

            // JSON.parse(JSON.stringify(this.state.selectedRowList)).forEach (item => {
            //     let rowData = []
            //     rowData = [
            //         item.xltest,
            //         item.xlmodify,
            //     ]
            //     tableData.push(rowData)
            // })

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            const arrayUniqueByKey=this.getUniqueArray(this.dataSourceOrigin,['studyid', 'xlscat', 'xltestcd', 'xltest', 'xlmodify']);

            this.currentTableName = localStorage.getItem("keytablename");
            var strRootList = new Array();
            strRootList = this.currentTableName.split("-");

            arrayUniqueByKey.forEach (item => {
                let rowData = []
                rowData = [
                    item.protocolid,
                    item.studyid,
                    strRootList[1].toUpperCase(),
                    item.xlscat,
                    item.xltype,
                    item.xltestcd,
                    item.xltest,
                    item.xlmodify,
                    item.xlcruser,
                    item.xlmouser,
                    item.xlcrdtc,
                    item.xlmodtc,
                    item.xlcomment,
                    item.xlstat,
                    item.xlauditlog!=null?item.xlauditlog.replace(/\n/g, '####'):''
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (this.userStudyID !='---Show All---'){
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.studyid==this.userStudyID){
                    selectedItems.push(rowData)
                    // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                    }

                    fileName=this.userStudyID + "_" + strRootList[1].toUpperCase() + "_"+run_dt+ ".xlsx";
                }
                else if (this.userProtocolID !='---Show All---'){
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.protocolid==this.userProtocolID){
                    selectedItems.push(rowData)
                    // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                    }
                    fileName=this.userProtocolID + "_" + strRootList[1].toUpperCase() + "_"+run_dt+ ".xlsx";
                } 
                else{
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                    selectedItems.push(rowData)
                  }
                  //  let  fileName=localStorage.getItem("userid") + "_" + run_dt+ ".xlsx";
                }

            })

            // console.log(tableData)

            let ws = XLSX.utils.aoa_to_sheet(selectedItems);
            ws["!cols"]=[{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:300},{wpx:300},{wpx:300},{wpx:100},{wpx:300}];
            // var s = ws['!ref'];
            // var rows = s.substr(s.length - 1, 1);
            // var columns = ['SOURCE', 'TARGET'];
            // for (var j = 0; j < columns.length; j++) {
            //     for (var i = 1; i <= rows; i++) {
            //         if (i == 1) {
            //             ws[columns[j] + i].s = { //样式  
            //                 font: {
            //                     bold: true,
            //                     italic: false,
            //                     underline: false
            //                 },
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: false
            //                 }
            //             };
            //         }
            //         else {
            //             ws[columns[j] + i].s = { //样式  
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: true
            //                 }
            //             };
            //         }
            //     }
            // }
            
            let wb = XLSX.utils.book_new()
            XLSX.utils.book_append_sheet(wb, ws, 'LABEL') // 工作簿名称
            XLSX.writeFile(wb, fileName) // 保存的文件名

            //  this.isloading=false;
    },

    // backupSelectedItemsAsXLS:function(){

    //     // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

    //         if(this.state.selectedRowKeys==""){
    //           // alert("No items selected!")
    //           message.error("没有术语选定，请确认!");
    //           return;
    //         }

    //         let run_dt = new Date().Format("yyyyMMddThhmmss");
    //         let fileName=localStorage.getItem("keytablename").toLowerCase() + "_" + localStorage.getItem("userid").toLowerCase() + "_backup_" + run_dt+ ".xlsx";

    //         let selectedItems = [
    //             ['PROTOCOLID', 'STUDYID', 'NAME', 'SOURCE', 'TARGET', 'STATUS', 'COMMENT']
    //         ] // 表格表头

    //         // JSON.parse(JSON.stringify(this.state.selectedRowList)).forEach (item => {
    //         //     let rowData = []
    //         //     rowData = [
    //         //         item.xltest,
    //         //         item.xlmodify,
    //         //     ]
    //         //     tableData.push(rowData)
    //         // })

    //         // console.log(JSON.stringify(this.state.selectedRowKeys))
    //         this.dataSourceOrigin.forEach (item => {
    //             let rowData = []
    //             rowData = [
    //                 item.protocolid,
    //                 item.studyid,
    //                 item.xltestcd,
    //                 item.xltest,
    //                 item.xlmodify,
    //                 item.xlstat,
    //                 item.xlcomment
    //             ]
                
    //             // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
    //             if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
    //             selectedItems.push(rowData)
    //             // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
    //             }
    //         })

    //         // console.log(tableData)

    //         let ws = XLSX.utils.aoa_to_sheet(selectedItems);
    //         ws["!cols"]=[{wpx:100},{wpx:100},{wpx:100},{wpx:400},{wpx:400},{wpx:100},{wpx:400}];
     
    //         let wb = XLSX.utils.book_new()
    //         XLSX.utils.book_append_sheet(wb, ws, 'LABEL') // 工作簿名称
    //         XLSX.writeFile(wb, fileName) // 保存的文件名
    // },

  backupSelectedItemsAsCSV:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

          // The download function takes a CSV string, the filename and mimeType as parameters
          // Scroll/look down at the bottom of this snippet to see how download is called
          var exportAsCSV = function(content, fileName, mimeType) {
            var a = document.createElement('a');
            mimeType = mimeType || 'application/octet-stream';

            if (navigator.msSaveBlob) { // IE10
              navigator.msSaveBlob(new Blob([content], {
                type: mimeType
              }), fileName);
            } else if (URL && 'download' in a) { //html5 A[download]
              a.href = URL.createObjectURL(new Blob([content], {
                type: mimeType
              }));
              a.setAttribute('download', fileName);
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
            } else {
              location.href = 'data:application/octet-stream,' + encodeURIComponent(content); // only this mime type is supported
            }
          }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".csv";

            let selectedItems = [
                ['PROTOCOLID', 'STUDYID', 'CATEGORY', 'DSTYPE', 'TYPE', 'ELEMENT', 'SOURCE', 'TARGET', 'CRUSER', 'MOUSER', 'CRDTC', 'MODTC', 'COMMENT', 'STATUS', 'AUDIT']
            ] // 表格表头


            this.currentTableName = localStorage.getItem("keytablename");
            var strRootList = new Array();
            strRootList = this.currentTableName.split("-");

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                  item.protocolid,
                  item.studyid,
                  strRootList[1].toUpperCase(),
                  item.xlscat,
                  item.xltype,
                  item.xltestcd,
                  item.xltest,
                  item.xlmodify,
                  item.xlcruser,
                  item.xlmouser,
                  item.xlcrdtc,
                  item.xlmodtc,
                  item.xlcomment,
                  item.xlstat,
                  item.xlauditlog!=null?item.xlauditlog.replace(/\n/g, '####'):''
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (this.userStudyID !='---Show All---'){
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.studyid==this.userStudyID){
                    selectedItems.push(rowData)
                    // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                    }

                    fileName=this.userStudyID + "_" + strRootList[1].toUpperCase() + "_"+run_dt+ ".csv";
                }
                else if (this.userProtocolID !='---Show All---'){
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.protocolid==this.userProtocolID){
                    selectedItems.push(rowData)
                    // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                    }
                    fileName=this.userProtocolID + "_" + strRootList[1].toUpperCase() + "_"+run_dt+ ".csv";
                } 
                else{
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                    selectedItems.push(rowData)
                  }
                  //  let  fileName=localStorage.getItem("userid") + "_" + run_dt+ ".xlsx";
                }
                
            })

            // Building the CSV from the Data two-dimensional array
            // Each column is separated by ";" and new line "\n" for next row
            var csvContent = '';
            var dataString='';
            selectedItems.forEach(function(infoArray, index) {
              dataString = infoArray.join(';');
              csvContent += index < selectedItems.length ? dataString + '\n' : dataString;
            });
            
            // exportAsCSV(csvContent, 'dowload.csv', 'text/csv;encoding:utf-8');

            exportToCSV(fileName,selectedItems,',');
    },

   exportSelectedItemsAsCSV:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

          // The download function takes a CSV string, the filename and mimeType as parameters
          // Scroll/look down at the bottom of this snippet to see how download is called
          var exportAsCSV = function(content, fileName, mimeType) {
            var a = document.createElement('a');
            mimeType = mimeType || 'application/octet-stream';

            if (navigator.msSaveBlob) { // IE10
              navigator.msSaveBlob(new Blob([content], {
                type: mimeType
              }), fileName);
            } else if (URL && 'download' in a) { //html5 A[download]
              a.href = URL.createObjectURL(new Blob([content], {
                type: mimeType
              }));
              a.setAttribute('download', fileName);
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
            } else {
              location.href = 'data:application/octet-stream,' + encodeURIComponent(content); // only this mime type is supported
            }
          }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".csv";

            let selectedItems = [
                ['SOURCE', 'TARGET', 'STATUS']
            ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            // Building the CSV from the Data two-dimensional array
            // Each column is separated by ";" and new line "\n" for next row
            var csvContent = '';
            var dataString='';
            selectedItems.forEach(function(infoArray, index) {
              dataString = infoArray.join(';');
              csvContent += index < selectedItems.length ? dataString + '\n' : dataString;
            });
            
            // exportAsCSV(csvContent, 'dowload.csv', 'text/csv;encoding:utf-8');

            exportToCSV(fileName,selectedItems,',');
    },


   exportSelectedItemsAsTAB:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".txt";

            let selectedItems = [
                ['SOURCE', 'TARGET', 'STATUS']
            ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            exportToCSV(fileName,selectedItems,'\t');
    },

   exportSelectedItemsAsSAS(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        // if (result.search(/("|,|\n)/g) >= 0)
                        //     result = '"' + result + '"';
                        if (j > 0){
                            finalVal += dlm;
                            finalVal += '"' + result + '"';
                        }
                        else{
                          finalVal += result;
                        }
                    }
                    return "    VALUES ( " + finalVal + ')\n';
                };

                var csvFile = 'PROC SQL; \n';
                csvFile += '    CREATE TABLE NMPA_DICT_LABEL \n';
                csvFile += '    (RECID INT, STUDYID CHAR(20), CAT CHAR(40), SUBCAT CHAR(40), SOURCE CHAR(2000), TARGET CHAR(2000), STATUS CHAR(40)); \n';
                csvFile += 'QUIT; \n\n';

                csvFile += 'PROC SQL; \n';
                csvFile += '    INSERT INTO NMPA_DICT_LABEL \n';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                csvFile += ';\n';
                csvFile += 'QUIT; \n';

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".sas";

            let selectedItems = [ ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))

            const key = 'xltest'
            // const arrayUniqueByKey = [...new Map(this.dataSourceOrigin.map(item =>
            //                     [item[key], item])).values()];


            // const getUniqArrBy = (props = [], arrInp = [{}], objTmp={}, arrTmp=[]) => {
            //   if (arrInp.length > 0) {
            //     const lastItem = arrInp[arrInp.length -1]
            //     const propStr = props.reduce((res, item) => (`${res}${lastItem[item]}`), '')
            //     if (!objTmp[propStr]) {
            //       objTmp[propStr] = true
            //       arrTmp=[...arrTmp, lastItem]
            //     }
            //     arrInp.pop()
            //     return getUniqArrBy(props, arrInp, objTmp, arrTmp)
            //   }
            //   return arrTmp
            // }
            const getUniqueArray=(arr, keyProps)=> {
              const kvArray = arr.map(entry => {
                const key = keyProps.map(k => entry[k]).join('|');
                return [key, entry];
              });
              const map = new Map(kvArray);
              return Array.from(map.values());
              }
              
            const arrayUniqueByKey=getUniqueArray(this.dataSourceOrigin,['studyid', 'xlscat', 'xltest', 'xlmodify']);

            let seq=1;
            arrayUniqueByKey.forEach (item => {
                let rowData = [];                
                rowData = [
                    item.id,
                    item.studyid,
                    item.xlcat,
                    item.xlscat,
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ];

                // console.log(rowData)
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.xlstat==='LOCKED' && item.studyid==this.userStudyID){
                seq=seq+1;
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                };
            })

            exportToCSV(fileName,selectedItems,',');
    },

    sendSelectedItemsByEmail:function(emailto){

        if(this.state.selectedRowKeys==""){
          // alert("No items selected!")
          message.error("没有术语选定，请确认!");
          return;
        }

        if (emailto==''){
          emailto=localStorage.getItem("email");
        }

        function exportToMailBody(rows) {
            var processRow = function (row) {
                var finalVal = '';
                for (var j = 0; j < row.length; j++) {
                    var innerValue = row[j] === null ? '' : row[j].toString();
                    if (row[j] instanceof Date) {
                        innerValue = row[j].toLocaleString();
                    };
                    var result = innerValue; //innerValue.replace(/"/g, '""');
                    finalVal += '<td>'+result+'</td>';
                }
                return finalVal ;
            };

            var mailbody = '';
            for (var i = 0; i < rows.length; i++) {
                if (i>0){
                mailbody += '<tr>' + '<td>' + i+ '</td>' + processRow(rows[i]) + '<td></td>' + '</tr>';
                }
                else{
                   mailbody += '<tr>' + '<td></td>' +processRow(rows[i]) + '<td>' + 'COMMENTS'+ '</td>' + '</tr>';
                }
            }
            return mailbody;
        }

        let selectedItems = [
            ['SOURCE', 'TARGET']
        ] // 表格表头

        // console.log(JSON.stringify(this.state.selectedRowKeys))
        this.dataSourceOrigin.forEach (item => {
            let rowData = []
            rowData = [
                item.xltest,
                item.xlmodify,
            ]
            
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
            selectedItems.push(rowData)
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            }
        })
      
      var mailbody=exportToMailBody(selectedItems);

      // console.log(mailbody);

      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(this.selectedRowKeys));
      params.append("action", "mailnotice");
      params.append("userid",localStorage.getItem("userid"));
      params.append("username",localStorage.getItem("username"));
      params.append("mailfrom",emailto);
      params.append("mailto",emailto);
      // params.append("mailcc",localStorage.getItem("email"));
      params.append("mailsubject","DO Translation Message: Please help review the terms");
      params.append("mailbody",encodeURIComponent(mailbody));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      axios
        .post(
          `https://data42.cn/api/func/mail.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();
          }
        });

    },


    sendReviewerSelectedItemsByEmail:function(){

        if(this.state.selectedRowKeys==""){
          // alert("No items selected!")
          message.error("没有术语选定，请确认!");
          return;
        }

        function exportToMailBody(rows) {
            var processRow = function (row) {
                var finalVal = '';
                for (var j = 0; j < row.length; j++) {
                    var innerValue = row[j] === null ? '' : row[j].toString();
                    if (row[j] instanceof Date) {
                        innerValue = row[j].toLocaleString();
                    };
                    var result = innerValue; //innerValue.replace(/"/g, '""');
                    finalVal += '<td>'+result+'</td>';
                }
                return finalVal ;
            };

            var mailbody = '';
            for (var i = 0; i < rows.length; i++) {
                if (i>0){
                mailbody += '<tr>' + '<td>' + i+ '</td>' + processRow(rows[i]) + '<td></td>' + '</tr>';
                }
                else{
                   mailbody += '<tr>' + '<td></td>' +processRow(rows[i]) + '<td>' + 'COMMENTS'+ '</td>' + '</tr>';
                }
            }

            mailbody +='<br><br>Please click the link below to conduct the review process directly!<br><br>'

            return mailbody;
        }

        let selectedItems = [
            ['SOURCE', 'TARGET']
        ] // 表格表头

        // console.log(JSON.stringify(this.state.selectedRowKeys))
        this.dataSourceOrigin.forEach (item => {
            let rowData = []
            rowData = [
                item.xltest,
                item.xlmodify,
            ]
            
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
            selectedItems.push(rowData)
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            }
        })
      
      var mailbody=exportToMailBody(selectedItems);

      // console.log(mailbody);

      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(this.selectedRowKeys));
      params.append("action", "mailnotice");
      params.append("userid",localStorage.getItem("userid"));
      params.append("username",localStorage.getItem("username"));
      params.append("mailfrom",localStorage.getItem("email"));
      params.append("mailto",localStorage.getItem("email"));
      params.append("mailcc",localStorage.getItem("email"));
      params.append("mailsubject","DO Translation Message: Please help review the terms");
      params.append("mailbody",encodeURIComponent(mailbody));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      axios
        .post(
          `https://data42.cn/api/func/mail.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();
          }
        });

    },

   exportSelectedItemsAsXNDICT:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("没有术语选定，请确认!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".txt";

            let selectedItems = [] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.xlstat==='LOCKED'){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            exportToCSV(fileName,selectedItems,'\t');
    },

   queryWithLastOperation: function () {

    //  console.log(localStorage.getItem("accessToken"));
     if (localStorage.getItem("accessToken")=="" || localStorage.getItem("accessToken")==null){
       return;
     }

     if (localStorage.getItem("keytablename")=="" || localStorage.getItem("keytablename")==null){
       return;
     }

     if (localStorage.getItem("userStudyList")=="" || localStorage.getItem("userStudyList")==null){
       return;
     }

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      this.columnTitle="";
     
      this.currentTableName = localStorage.getItem("keytablename");
      var strRootList = new Array();
      strRootList = this.currentTableName.split("-");

      var params=localStorage.getItem("query-params");

      if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnGlobalVariableLabelCN:this.userconfig.columnGlobalVariableLabelEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalDatasetLabelCN:this.userconfig.columnGlobalDatasetLabelEN;
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalVariableLogicCN:this.userconfig.columnGlobalVariableLogicEN;
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnOtherTermCN:this.userconfig.columnOtherTermEN;
      }

      if (strRootList[0] == "study") {
        this.isGlobalTerms = false;
      } else {
        this.isGlobalTerms = true;
      }

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "terms/nmpa-dict-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          // this.inputValue = localStorage.getItem("searchterm");
          // this.studyid=localStorage.getItem("studyid");

          this.dataSourceOrigin = response.data.records;

          this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

          // console.log(this.uniqueValueList('xltest'));

          this.letterList=this.uniqueCapitalLetterList('xltest').sort((a, b) => (a > b) ? 1 : -1);

          this.userProtocolList=this.uniqueStudyList('protocolid').sort((a, b) => (a > b) ? 1 : -1);

          if (localStorage.getItem("studyid") && localStorage.getItem("protocolid")){
            this.userProtocolList=localStorage.getItem("userProtocolList").split(',');
            this.userStudyList=localStorage.getItem("userStudyList").split(',');;
            this.userProtocolID=localStorage.getItem("protocolid");
            this.userStudyID=localStorage.getItem("studyid");
            this.handleSearchInput();
          }

        })
        .catch((error) => {
          // console.log(localStorage.getItem("accessToken"));
          // this.errorMessage = error.response.data.message;
          this.isLoading = false;

          console.log(error);

          // alert(error.response.data.message);
          //   if (localStorage.getItem("accessToken")) {
          //     localStorage.removeItem("accessToken");
          //     this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
          //   }else{
          //     this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
          //   };
          return;
          // alert(error.message);
          // logout();
        });
    },

    queryTermsByTestName: function (searchItemValue) {
      // this.isLoading = true;

      //  console.log(searchItemValue, this.userStudyID);
      
      this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

      if (searchItemValue && this.userProtocolID && this.userProtocolID =='---Show All---'){
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) 
        );
      }
      // else if (this.userProtocolID && this.userProtocolID =='---Show All---'){
      //   this.dataSource = this.dataSource.filter((item) =>
      //     item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) 
      //   );
      // }
      else if (searchItemValue && this.userStudyID && this.userStudyID !='---Show All---'){
        // console.log('Show selected study with search item:', searchItemValue, this.userStudyID);
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) && item.studyid.toUpperCase()==this.userStudyID && item.protocolid.toUpperCase()==this.userProtocolID
        );
      }
      else if (searchItemValue && this.userStudyID =='---Show All---'){
      //  console.log('Show all with search item:', searchItemValue, this.userStudyID);
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) && item.protocolid.toUpperCase()==this.userProtocolID
        );
      }
      else if (searchItemValue){
        // console.log('Show selected protocol with search item:', searchItemValue, this.userStudyID);
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) && item.protocolid.toUpperCase()==this.userProtocolID
        );
      }else if (this.userStudyID && this.userStudyID !='---Show All---'){
        // console.log('Show all selected study', searchItemValue, this.userStudyID);
        this.dataSource = this.dataSource.filter((item) =>
          item.studyid.toUpperCase()==this.userStudyID && item.protocolid.toUpperCase()==this.userProtocolID
        );
      }

      // this.isLoading = false;

      // var params = new URLSearchParams();

      // // params.append("level", encodeURIComponent(obj.keyPath.length));
      // // params.append("level", encodeURIComponent(strList[0]));
      // params.append("keyname", encodeURIComponent("xltest"));
      // params.append("keyvalue", encodeURIComponent(searchItemValue + "%"));
      // params.append("action", encodeURIComponent("read"));
      // params.append("keytablename", encodeURIComponent(this.currentTableName));

      // // console.log(searchItemValue);
      // axios
      //   .post(`terms/nmpa-dict-query.php`, params)
      //   .then((response) => {
      //     // this.inputValue=obj.key;
      //     this.isLoading = false;
      //     this.errorMessage = "";
      //     this.successMessage = "";
      //     this.inputValue = "";
      //     this.dataSource = response.data.records;
      //   })
      //   .catch((error) => {
      //     // console.log(error);
      //     this.errorMessage = error.data.message;
      //   });
    },

    // handleSearchInput() {
    //   this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));
    //   if (this.userStudyID){
    //     this.dataSource = this.dataSource.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(this.inputValue.toLowerCase()) 
    //         ) && item.studyid.toUpperCase()==this.userStudyID
    //     );
    //   }
    //   else{
    //     this.dataSource = this.dataSource.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(this.inputValue.toLowerCase()) 
    //         ) 
    //     );
    //   }

    //   this.letterList=this.uniqueCapitalLetterListSelected('xltest').sort((a, b) => (a > b) ? 1 : -1);

    //   localStorage.setItem("protocolid", this.userProtocolID);
    //   localStorage.setItem("studyid", this.userStudyID);
    //   localStorage.setItem("searchterm", this.inputValue);

    // },

    handleDropdonwlist() {
      // console.log("dropdownlist");
      // console.log(this.dropdownValue);
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      console.log(file);
      this.fileList = [...this.fileList, file];
      return false;
    },
    handleUpload() {
      const { fileList } = this;
      const formData = new FormData();
      fileList.forEach((file) => {
        formData.append("file", file);
      });
      formData.append("action", "upload-csv");
      formData.append("scope", "study");
      formData.append("type", "Labels");
      formData.append("userid",localStorage.getItem("userid"));
      formData.append(
        "keytablename",
        encodeURIComponent(this.currentTableName)
      );

      this.uploading = true;

      // You can use any AJAX library you like
      axios
        .post(
          "util/nmpa-dict-upload-csv.php",
          formData
        )
        .then((response) => {
          this.uploading = false;
          // console.log(response.data);
          // console.log("response : ", response);
          this.handleRemove();
        })
        .catch((e) => {
          console.log(e);
        });
    },

  },
});
</script>

<style>
#app .trigger {
  font-size: 18px;
  line-height: 32px;
  background: rgb(0, 242, 9,0.65);
  padding: 0 12px;
  cursor: pointer;
  transition: color 0.3s;
}

#app .trigger:hover {
  color: #ffffff;
}


#app .logo {
  height: 32px;
  background: rgba(248, 80, 2, 0.85);
  color:rgba(255, 255, 255, 0.85);
  font-weight: bold;
  margin: 21px 0px 16px 0px;
  padding:6px 0px 0px 0px
}

.highlight {
  background-color: rgb(255, 192, 105);
  padding: 0px;
}

.zerovaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  content: "";
  /* background-color: rgb(226, 221, 221); */
  color: rgb(218, 214, 214);
  font-size: 16px;
}

/*high value for FSP*/
.highfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  font-weight: bold;
  
  content: "";
  background-color: rgb(253, 252, 179, 0.95);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}

/*high value for FTE*/
.highftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  font-weight: bold;
  content: "";
  background-color: rgb(255, 216, 205,0.95);
  color: rgb(0, 0, 0,0.5);
  font-size: 16px;
}

.ftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.65);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}

.fspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.65);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}


.totalftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalhighftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalhighfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}


.totalvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(4, 168, 31,0.65);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.totalresource {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgba(255, 0, 0, 0.85);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.totalhighvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 0, 0,0.5);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.ant-table-cell{
  text-align: left  ;
}


.totalftecolor{
  color: rgb(6, 3, 161);
}

.ant-typography {
    color: rgba(9, 121, 37);
    font-weight: bold;
    /* overflow-wrap: break-word; */
    text-align: center;
}

#components-table-demo-summary tfoot th,
#components-table-demo-summary tfoot td {
  background: #fafafa;
}
[data-theme='dark'] #components-table-demo-summary tfoot th,
[data-theme='dark'] #components-table-demo-summary tfoot td {
  background: #1d1d1d;
}

/* .ant-table-cell-fix-left{
background: #dad9d9;
} */
/* .boxW,
.normalB {
  :global {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
      padding: 8px 8px !important;
    }
    .ant-table-thead > tr > th {
      background-color: rgb(110, 193, 199);
      font-size: 24px；;
    }
    .ant-table-thead > tr > th:hover {
      background-color: rgb(9, 75, 80);
      font-size: 24px；;
    }
    .ant-table-thead
      > tr
      > th.ant-table-column-has-actions.ant-table-column-has-sorters:hover {
      background: rgb(192, 244, 248);
      font-size: 24px；;
    }
  }
} */


.site-layout .site-layout-background {
  background: rgb(224, 221, 221);
}

.editable-cell {
  position: relative;}

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding-right: 24px;
  }

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding: 5px 24px 5px 5px;
  }

  .editable-cell .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    right: 0;
    width: 20px;
    cursor: pointer;
  }

  .editable-cell .editable-cell-icon {
    margin-top: 4px;
    display: none;
  }

  .editable-cell-icon-check {
    line-height: 28px;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }

  .editable-add-btn {
    margin-bottom: 8px;
  }

/* element.style{
  background: black;
} */

.editable-cell:hover .editable-cell-icon {
  display: inline-block;
}

.ant-statistic-content {
    color: #f0f0f0;
    font-size: 14px;
}

.ant-table-thead > th {
  color: white;
  background: #d46114 !important;
  font-size: 16px;
}

.ant-table-tbody > tr {
  color: rgb(0, 0, 0);
  /* background: #f0f1ee !important; */
  border: 0px !important;
  font-size: 16px;
}

.ant-table-tbody > tr:hover {
  color: rgb(255, 5, 5) !important;
  /* font-weight: bold; */
  /* font-weight: 600; */
  /* background: rgb(243, 247, 25); */
  /* font-size: 16px !important; */
}

.ant-tabs-card>.ant-tabs-nav .ant-tabs-tab .ant-tabs-tab-active{
  background: rgb(221, 55, 5);
  color:#bb3a3a
}

.ant-tabs-card>.ant-tabs-nav .ant-tabs-tab{
  background: rgb(199 208 199);
}
.ant-statistic-content {
    color: #b8947e;
    font-size: 14px;
}

.ant-upload-list-item {
  position: fixed !important;
  height: 22px;
  /* width: 200px  !important; */
  margin-top: 0px !important;
  font-size: 14px !important;
}

.ant-select:not(.ant-select-customize-input) .ant-select-selector {
    position: relative;
    background-color: rgb(255 255 255 / 90%);
    /* border: white; */
    color: #f04e0e;
    border-radius: 2px
;
    transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
}

</style>