<template>
  <a-layout>
    <!-- :style="{ overflow: 'auto', height: '100vh', position: 'fixed', left: 0 }" -->
    <a-layout-sider v-model:collapsed="collapsed" collapsible :trigger="null"        >
      <div class="logo" align="center">{{collapsed? 'NMPA NDA': 'NMPA NDA'}}</div>
      <a-menu
        theme="dark"
        mode="inline"
        :openKeys="openKeys"
        v-model:selectedKeys="selectedKeys"
        @openChange="onOpenChange"
        @click="queryByMenuiItems"
      >
        <a-sub-menu key="ndp-list-function_name">
          <template #title>
            <span>
              <ClusterOutlined />
              <span>{{this.lang==='cn'? 'Function Group': 'Function Group'}}</span>
            </span>
          </template>
          <a-menu-item :key="'ALL'+'_'+'299'">
             {{this.lang==='cn'? 'All Functions': 'All Functions'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndpfunctionlist"
            :key="item.value+ '_'+index"
            >{{ item.value.toUpperCase() }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="ndp-list-tier">
          <template #title>
            <span>
              <AppstoreOutlined />
              <span>{{this.lang==='cn'? 'NDP Tiers': 'NDP Tiers'}}</span>
            </span>
          </template>
           <a-menu-item :key="'ALL'+'_'+'199'">
             {{this.lang==='cn'? 'All Tiers': 'All Tiers'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndptierlist"
            :key="item.value+ '_'+index"
            >{{ item.text.toUpperCase() }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="ndp-list-status">
          <template #title>
            <span>
              <SyncOutlined />
              <span>{{this.lang==='cn'? 'NDP Status': 'NDP Status'}}</span>
            </span>
          </template>
          <a-menu-item :key="'ALL'+'_'+'399'">
             {{this.lang==='cn'? 'All Status': 'All Status'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndpstatuslist"
            :key="item.value+ '_'+index"
            >{{ item.text.toUpperCase() }}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="ndp-list-tagname">
          <template #title>
            <span>
             <TagOutlined />
              <span>{{this.lang==='cn'? 'NDP Tags': 'NDP Tags'}}</span>
            </span>
          </template>
          <a-menu-item :key="'ALL'+'_'+'399'">
             {{this.lang==='cn'? 'All Tags': 'All Tags'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndptagnamelist"
            :key="item+ '_'+index"
            >{{ item}}</a-menu-item
          >
        </a-sub-menu>

        <a-sub-menu key="ndp-list-project_type">
          <template #title>
            <span>
             <GroupOutlined />
              <span>{{this.lang==='cn'? 'NDP Groups': 'NDP Groups'}}</span>
            </span>
          </template>
          <a-menu-item :key="'ALL'+'_'+'399'">
             {{this.lang==='cn'? 'All GroupsTags': 'All Groups'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndpdefinitiontypelist"
            :key="item.value+ '_'+index"
            >{{ item.text.toUpperCase() }}</a-menu-item
          >
        </a-sub-menu>
        <!-- <a-sub-menu key="ndp-list-ftetype">
          <template #title>
            <span>
              <DatabaseOutlined />
              <span>{{this.lang==='cn'? 'FTE Type': 'FTE Type'}}</span>
            </span>
          </template>
          <a-menu-item :key="'ALL'+'_'+'399'">
             {{this.lang==='cn'? 'All FTEs': 'All FTEs'}}
          </a-menu-item>
          <a-menu-item
            v-for="(item, index) in ndpftetypelist"
            :key="item.value+ '_'+index"
            >{{ item.text.toUpperCase() }}</a-menu-item
          >
        </a-sub-menu> -->

       </a-menu>
    </a-layout-sider>
    <!-- :style="{ marginLeft: '200px' }" -->
    <a-layout>
      <a-layout-header
        style="background: #fff; padding: 0"
        :style="{
          margin: '0px',
          padding: '0px 0px 0px 0px',
          position: 'fixed',
          zIndex: 1,
          width: '100%',
        }"
      >
        <!-- <menu-unfold-outlined
          v-if="collapsed"
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        />
        <menu-fold-outlined
          v-else
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        /> -->
       
        <!-- <span :style="{margin: '20px 0px 0px 0px', color:'green', fontWeight:'bold'}">Oregano</span> -->

        <a-button style="margin: 20px 2px 10px 20px; float: center" type="primary" :loading="reloadStatus" @click="this.initChart();this.tagNameSwitchCheck=false; this.reloadStatus=true; this.inputValue=''; getNDPList();this.calcDashBoardMetrics(dataSource);this.reloadStatus=false"><ReloadOutlined />{{this.lang==='cn'? 'Reload': 'Reload'}}</a-button>

        <a-button 
          style="margin: 20px 2px 10px 2px; float: center"
          type="danger" 
        
          @click="resetFields(); editVisibleBasic= true; this.strNewOrEdit='New';"
          ><PlusOutlined />NDA</a-button
        >

        <!-- <a-button type="link"  @click="selectAllItems()">{{this.lang==='cn'? 'Select All': 'Select All'}}</a-button>
        <a-button type="link"  @click="clearSelection()">{{this.lang==='cn'? 'Clear Selection': 'Clear Selection'}}</a-button> -->
        <!-- <a-button type="link"  @click="clearSelection()">{{this.lang==='cn'? 'Clear Filters': 'Clear Filters'}}</a-button> -->
        
        <!-- <a-checkbox 
          :style="{
          padding: '5px 0px 0px 20px',          
          }"
          v-model:checked="blSearchInCacheOrBackend">{{this.SearchInCacheOrBackend}}
        </a-checkbox>

          <a-input-search
            style="margin: 20px 2px 10px 10px; width: 15%; float: center"
            v-model:value="inputValue"
            allow-clear
            placeholder="Search NDP name, WPID or PM"
            enter-button
            @change="handleSearchInputChange"
            @search="handleSearchInput2"
          />
       <a-dropdown :trigger="['click']" >  <a >
            &nbsp;  <DownOutlined />
          </a>
          <template #overlay>
            <a-menu>
              <a-menu-item key="1" @click="filterNDPByFTE('>0')"><FunnelPlotOutlined />&nbsp;{{this.lang==='cn'? '显示有资源分配项目': 'Filter NDP with FTE assigned'}}</a-menu-item>
              <a-menu-item key="2" @click="filterNDPByFTE('=0')"><FunnelPlotOutlined />&nbsp;{{this.lang==='cn'? '显示无资源分配项目': 'Filter NDP without FTE assigned'}}</a-menu-item>
              <hr>
              <a-menu-item key="4" @click="filterNDPByFTE('<4')"><FunnelPlotOutlined />&nbsp;{{this.lang==='cn'? '显示项目资源分配<=4': 'Filter NDP with 0< FTE <4'}}</a-menu-item>
              <a-menu-item key="5" @click="filterNDPByFTE('>=4')"><FunnelPlotOutlined />&nbsp;{{this.lang==='cn'? '显示无资源分配项目': 'Filter NDP with FTE >=4'}}</a-menu-item>
              <hr>
              <a-menu-item key="3" @click="filterNDPByFTE('>=0')"><FunnelPlotOutlined />&nbsp;{{this.lang==='cn'? '显示所有项目': 'Reset to show all NDP'}}</a-menu-item>
            </a-menu>
          </template>
        </a-dropdown> -->

        <span style="position: absolute; right:0; padding: 28px 550px 0px 0px"> 
          <a-statistic-countdown title="" :value="dueDate" @finish="onFinish" format="Expire: H:mm:ss" />
        </span>

        <!-- <a-popconfirm
          v-if="selectedRowKeys != '' && (isAdmin===true)"
          title="Are you sure to remove all selected rows?"
          @confirm="removeAllItem(this.state.selectedRowKeys)"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary"
            ghost
            ><MinusOutlined /></a-button
          >
        </a-popconfirm> -->

 
        <!-- <a-dropdown v-if="isAdmin===true" :trigger="['click']" >  <a >
            &nbsp; <DownOutlined />
          </a>
          <template #overlay>
            <a-menu>
              <a-menu-item key="1" @click="exportSelectedItemsAsXLS"><ExportOutlined />{{this.lang==='cn'? '导出为Excel文件': 'Export as Excel (.xlsx)'}}</a-menu-item>
            </a-menu>
          </template>
        </a-dropdown> -->

    <span style="position: absolute; right:0; padding: 6px 270px 0px 0px">

          <!-- <a-radio-group name="radioGroupFTE" v-model:value="valueFTEType">
            <a-radio value="All">All</a-radio>
            <a-radio value="Internal">Internal</a-radio>
            <a-radio value="External">External</a-radio>        
          </a-radio-group> -->          
                  
            <StarTwoTone twoToneColor="red" />&nbsp;<a-switch v-model:checked="tagNameSwitchCheck" @change="handleTagNameSwitchCheck()"/>&nbsp; B22 Plan &nbsp;
          
          <a-dropdown v-if="isLogin=true" :trigger="['click']" > 
             <a >
              &nbsp;&nbsp;<UserOutlined/>&nbsp;{{strUserName}}<DownOutlined />&nbsp;&nbsp;              
              </a>
                               
              <template #overlay>
                <a-menu>                                   
                  <a-menu-item key="1" @click="backupSelectedItemsAsXLS"><ExportOutlined />&nbsp;{{this.lang==='cn'? '导出 (xlsx)': 'Export as XLSX'}}</a-menu-item>
                  <!-- <a-menu-item key="2" @click="changeLocale(this.lang)"><TranslationOutlined />{{this.lang==='cn'? '切换语言': 'Switch to Chinese'}}</a-menu-item>
                  <a-menu-item key="3" @click="showingPasscodeModal=true"><KeyOutlined />{{this.lang==='cn'? '设置登录PIN码': 'Set Login Pin Code'}}</a-menu-item> -->
                  <a-menu-item key="4" @click="logout"><LoginOutlined />&nbsp;{{this.lang==='cn'? '注销': 'Log out'}}</a-menu-item>
                </a-menu>
              </template>
            </a-dropdown>

             <img v-if="collapsed" src="../assets/novartis-logo01.svg" alt="" width="150" 
                    style="position: absolute; right:100px; padding: 20px 0px 0px 0px">
          </span>
  
       <template>
          <a-drawer
            title="添加项目 (如一个项目包含多项研究，请分别添加)"
            :width="600"
            :visible="editVisibleBasic"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="formNew" layout="vertical" ref="formRef" :rules="rulesRef">
               <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交名称（不可修改）" name="protocolid">
                    <a-input
                      v-model:value="formState.protocolid" 
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：ENTRESTO"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号（不可修改）" name="studyid">
                    <a-input
                      v-model:value="formState.studyid" 
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：CLCZ696B2301"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="项目标题中文（可选）" name="studytitle">
                    <a-input
                      v-model:value="formState.xltestcd"
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="项目标题"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="治疗领域" name="taname">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formState.taname"
                    >
                      <a-select-option value="Cardiovascular Disease">Cardiovascular</a-select-option>
                      <a-select-option value="Metabolism">Metabolism</a-select-option>
                      <a-select-option value="Oncology">Oncology</a-select-option>
                      <a-select-option value="Ophthalmology"
                        >Ophthalmology</a-select-option
                      >
                      <a-select-option value="Dermatology"
                        >Dermatology
                      </a-select-option>
                      <a-select-option value="NeuroScience">NeuroScience</a-select-option>
                      <a-select-option value="Others">Others</a-select-option>/
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="适应症" name="indication">
                    <a-input
                      v-model:value="formState.indication"
                      placeholder="适应症"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="EDC类型" name="xledctype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formState.xledctype"
                    >
                      <a-select-option value="OCRDC">OC RDC</a-select-option>
                      <a-select-option value="RAVE">RaveX</a-select-option>    
                      <a-select-option value="OTHER">Others</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="CRF文件格式类型" name="xlcrftype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="formState.xlcrftype"
                    >
                      <a-select-option value="OC">Standard OC Format</a-select-option>
                      <a-select-option value="RAVE">Standard RAVE Format</a-select-option>
                      <a-select-option value="PICTURE">Picture Format</a-select-option>
                      <a-select-option value="OTHER">Other Format</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究数据类型" name="xldttype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formState.xldttype"
                    >
                      <a-select-option value="CDISC">CDISC</a-select-option>
                      <a-select-option value="Legacy">Legacy</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据说明文件格式类型" name="xlspectype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="formState.xlspectype"
                    >
                      <a-select-option value="DefineXML">Define.XML</a-select-option>
                      <a-select-option value="Spreadsheet">Spreadsheet (.xlsx)</a-select-option>
                      <a-select-option value="RAP-M8">RAP Module 8 (.pdf)</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究结束日期" name="xlendtc">
                    <a-date-picker v-model:value="formState.xlendtc" @Change="onChangePickDate"
                      format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                      />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据可用日期（GPS）" name="xldadtc">
                    <a-date-picker v-model:value="formState.xldadtc" 
                    format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交日期（计划）" name="xldpdtcp">
                    <a-date-picker v-model:value="formState.xldpdtcp" 
                      format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                      :disabled-date="disabledDate" />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="翻译完成日期（计划）" name="xltcdtcp">
                    <a-date-picker v-model:value="formState.xltcdtcp" 
                    format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                    :disabled-date="disabledDate"/>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                 <a-form-item label="RA负责人" name="xlrapoc">
                    <a-select v-model:value="formState.xlrapoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="DO负责人" name="xldopoc">
                    <a-select v-model:value="formState.xldopoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="SP负责人" name="xlsppoc">
                    <a-select v-model:value="formState.xlsppoc"  ref="select"                               >
                    <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                     {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>             
                <a-col :span="10">
                  <a-form-item label="DM负责人" name="xldmpoc">
                    <a-select v-model:value="formState.xldmpoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="CD负责人" name="xlcdpoc">
                    <a-select v-model:value="formState.xlcdpoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>       
                <a-col :span="10">
                  <a-form-item label="RWS负责人" name="xlmwpoc">
                    <a-select v-model:value="formState.xlmwpoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>


              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="注释" name="xlcomment">
                    <a-input
                      placeholder=""
                      v-model:value="formState.xlcomment"
                    />
                  </a-form-item>
                </a-col>
              </a-row>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
            <div v-if="this.strNewOrEdit=='Edit'">
              <a-button style="margin-right: 8px" type="danger" @click="resetForm">重置</a-button>
              <a-button style="margin-right: 8px" type="danger" @click="onCloseEdit">取消</a-button>
              <a-button style="margin-right: 8px" type="primary" @click="onSubmitEdit(formState.record_id, 'row-update')">保存</a-button>
              <a-button style="margin-right: 8px" type="danger" @click="onSubmitNew">新增保存</a-button>
              </div>
            <div v-else>              
              <a-button style="margin-right: 8px" type="danger" @click="resetForm">重置</a-button>
              <!-- <a-button style="margin-right: 8px" type="danger" @click="resetFields">Clear</a-button> -->
              <a-button style="margin-right: 8px" type="danger" @click="onCloseNew">取消</a-button>
              <a-button style="margin-right: 8px" type="primary" @click="onSubmitNew">新增</a-button>
              </div>
            
            </div>
          </a-drawer>
        </template>
      </a-layout-header>

      <a-layout-content
        :style="{
          margin: '0px 0px 0px 10px',
          padding: '100px 0px 0px 0px',
          background: '#fff',
          minHeight: '700px',
        }" 
      >

      <a-spin tip="Loading..." :spinning="isLoading">
      <a-tabs type="card" v-model:activeKey="activeKey" @change="reloadEcharts">

          <template #rightExtra v-if="activeKey!='1'">
             <div  :style="{padding: '5px 25px 0px 5px', 
              textAlign:'center',
              fontWeight:'bold',
              fontSize:'12pt',
              color:'red'
              }" >
              &nbsp;{{dataSource.length}} {{dataSource.length<=1?'result':'results'}} returned&nbsp;
             </div>
          </template>

      <a-tab-pane key="1" tab="NDA概览"  > 

        <a-row>
       
          <a-col :span="4"><a-card style="background: #035969;">
            <a-statistic title="Plan" v-model:value="totalOtherNDPs"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #085703;">
            <a-statistic title="Active" v-model:value="totalActiveNDPs"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #9c7303;">
            <a-statistic :style="{ color:'black'}" title="On Hold" v-model:value="totalOnHoldNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #870804;"> 
            <a-statistic title="Terminated" v-model:value="totalTerminatedNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: green;">
            <a-statistic title="Completed" v-model:value="totalCompletedNDPs"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #0c59b0                        ;">
            <a-statistic style="forecolor: #ffffff;" title="Total NDPs" v-model:value="totalNDPs"  />
            </a-card>
          </a-col>
          <!-- <a-col :span="4"><a-card style="background: #f58c0c;">
            <a-statistic title="Total FTEs" v-model:value="totalFTE"  />
            </a-card>
          </a-col> -->
        </a-row>

        <div class="echarts-box">
          <div id="myEcharts" :style="{ width: '95%', height: '370px' }">
          </div>
        </div>

          <a-row>
                <a-col :span="4"><a-card style="background: #9fa160;">
            <a-statistic title="BEx" v-model:value="totalResources.totalBex"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #678545;">
            <a-statistic title="CDDRA" v-model:value="totalResources.totalCDDRA"   />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #bf9b71;">
            <a-statistic :style="{ color:'black'}" title="CDS&A" v-model:value="totalResources.totalCDSA"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #4376e6;"> 
            <a-statistic title="DM" v-model:value="totalResources.totalDM"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #62a37b;">
            <a-statistic title="SP" v-model:value="totalResources.totalSP"  />
            </a-card>
          </a-col>
          <a-col :span="4"><a-card style="background: #bd1c04;">
            <a-statistic style="forecolor: #ffffff;" title="Total FTEs" v-model:value="totalResources.totalResource"  />
            </a-card>
          </a-col>
        </a-row>
     </a-tab-pane>

       <a-tab-pane key="2" tab="NDA项目列表"> 
          <!-- <a-spin tip="Loading..." :spinning="isLoading"> -->
          <a-table 
            class="list"
            :data-source="dataSource"
            bordered
            rowKey="record_id"
            :scroll="{x:1000, y:600}"
            :columns="columnsList"
            :customRow="customRightClick"
            @change="handleChange"
            size="middle"
            tableLayout="fixed"
          >

            <template #flag="{record }">
              <!-- <a-badge count="25" /> -->
              <div v-if="record.comment!='' && record.comment!=null">
                <a-tooltip color='#661703'>
                  <template #title>Comments: <br>{{record.comment}}</template>    
                  <BellTwoTone two-tone-color="#eb2f96"/>
                </a-tooltip>
               </div>
              </template>

            <template #seq="{ index }">
                {{ (index + 1)+(currentPage-1)*currentPageSize }}
            </template>

            <template #project_name="{ text, record }" >
              <div class="editable-cell" style="text-align: left;">      
                <a-tooltip placement="left" trigger="click" color="#0d5780">
                <template #title>{{record.project_desc}}</template>        
                <div
                  v-if="editableData[record.record_id]"
                  class="editable-cell-input-wrapper"
                >
                  <a-input
                    v-model:value="editableData[record.record_id].project_name"
                    @pressEnter="cellSave('project_name',record.record_id)"
                  />
                  <check-outlined
                    class="editable-cell-icon-check"
                    @click="cellSave('project_name',record.record_id)"
                  />
                </div>
                
                <div v-else-if="record.status.toUpperCase()=='ACTIVE' && ['TIER 0','TIER 2', 'TIER 3'].indexOf(record.tier.toUpperCase())!=-1 && (record.horizon_wpid=='' || record.horizon_wpid==null)" class="editable-cell-text-wrapper">         
                    {{ text || " " }} &nbsp;<WarningTwoTone twoToneColor="#eb2f96"/>
                  <edit-outlined
                    class="editable-cell-icon"
                    @click="cellEdit('project_name',record.record_id)"
                  />
                </div>
                <div v-else class="editable-cell-text-wrapper">         
                    {{ text || " " }} &nbsp;
                     <a-tooltip color="#0d5780">
                      <template #title>{{record.tagname}}</template> 
                        <StarTwoTone v-if="record.tagname!=null?record.tagname.toString().split(/\s*,\s*/).indexOf('BP22') !=-1:''" twoToneColor="red"/>
                        <StarTwoTone v-else-if="record.tagname!=null && record.tagname!=''" twoToneColor="green"/>
                      </a-tooltip>
                  <edit-outlined
                    class="editable-cell-icon"
                    @click="cellEdit('project_name',record.record_id)"
                  />
                </div>
                </a-tooltip>
                
              </div>
            </template>

            <template #status="{record}">
              <div style="text-align: left;" v-if="record.status!=null && record.status!=''">
                <a-tag 
                  :key="record.record_id"
                  :color="['ACTIVE', 'PLAN', 'INITIAL'].indexOf(record.status.toUpperCase()) !=-1 ? 'blue' : 
                  ['COMPLETED', 'APPROVED'].indexOf(record.status.toUpperCase())!=-1 ? 'green' : 
                  ['ON-HOLD', 'ON HOLD'].indexOf(record.status.toUpperCase())!=-1 ? 'pink' : 
                  ['TERMINATED'].indexOf(record.status.toUpperCase())!=-1 ?'red':'grey'"
                >
                  {{ record.status.toUpperCase() }} 
                </a-tag>
              </div>
            </template>

            <template #tier="{record}">
              <span>
                <a-tooltip placement="topLeft" trigger="click" >
                <template v-if="['TIER 0'].indexOf(record.tier) !=-1" #title>Tier 0 projects where DO provide resources but does not own</template>     
                <template v-else-if="['TIER 1'].indexOf(record.tier) !=-1" #title>Tier 1 projects with less than 4 months or 4 FTEs<br>Approval level: LF</template>
                <template v-else-if="['TIER 2'].indexOf(record.tier) !=-1" #title>Tier 2 projects with no capital spend (>4 months / >4 FTE<br>Approval level: DNGB;
                  <br><br>Tier 2 projects with capital spend less than 150k<br><br>Approval level: DNGB with further Endorsement of TIBPB and approval</template>
                <template v-else-if="['TIER 3'].indexOf(record.tier) !=-1" #title>Tier 3 projects with capital spend 150k – 500k<br>Approval level: TIBPB Endorsement, GDO LT</template>     
                <template v-else #title>Tier 4 projects with capital spend 500k – 2m <br>Approval level: TIBPB Endorsement, approval GDO LT > VMT
                                        <br><br>Tier 5 projects with capital spend >2m<br>Approval level: TIBPB Endorsement, approval GDO LT > VMT > GDD IC</template>
                <a-tag
                  :key="record.record_id"
                  :color="['TIER 0'].indexOf(record.tier) !=-1 ? 'black' : 
                  ['TIER 1'].indexOf(record.tier)!=-1 ? 'green' : 
                  ['TIER 2'].indexOf(record.tier)!=-1 ? 'red' : 
                  ['TIER 3'].indexOf(record.tier)!=-1 ?'blue':'grey'"
                >
                  {{ record.tier }}
                </a-tag>
                 </a-tooltip>
              </span>
            </template>
            

            <template #modtc="{record}">
              <span>
                <a-tooltip placement="left" trigger="click" >
                <template v-if="record.mouserid!=null & record.mocruserid!=''" #title>Last modified by: {{record.mouserid}}</template> 
                <template v-else-if="record.cruserid!=null & record.cruserid!=''" #title>Created by: {{record.cruserid}}</template>     
                  {{ record.modtc}}
                 </a-tooltip>
              </span>
            </template>

            <template #project_manager="{record}">
              <div style="text-align: left;">
                <a :href="'mailto:'+record.project_manager_email+'?subject=DNGB about NDP '+record.project_name+'&cc=' + 
                record.project_lead_email+'&body=Dear ' + record.project_manager + 
                ',%0D%0A%0D%0A%0D%0A'+ 'Regards,%0D%0A' + strUserName + ' On behalf of DNGB%0D%0ADO Non-Drug Governance Board' 
                ">{{record.project_manager}}</a>
              </div>
            </template>

            <template #project_lead="{record}">
              <div style="text-align: left;">
                <a :href="'mailto:'+record.project_lead_email+'?subject=DNGB about NDP '+record.project_lead+'&cc=' + 
                record.project_manager_email+'&body=Dear ' + record.project_lead + 
                ',%0D%0A%0D%0A%0D%0A'+ 'Regards,%0D%0A' + strUserName + ' On behalf of DNGB%0D%0ADO Non-Drug Governance Board' 
                ">{{record.project_lead}}</a>
              </div>
            </template>
            <template #filterDropdown="{ setSelectedKeys, selectedKeys, confirm, clearFilters, column }">
              <div style="padding: 8px">
                <a-input
                  ref="searchInput"
                  :placeholder="`Search ${column.dataIndex}`"
                  :value="selectedKeys[0]"
                  style="width: 188px; margin-bottom: 8px; display: block"
                  @change="e => setSelectedKeys(e.target.value ? [e.target.value] : [])"
                  @pressEnter="handleSearch(selectedKeys, confirm, column.dataIndex)"
                />
                <a-button
                  type="primary"
                  size="small"
                  style="width: 90px; margin-right: 8px"
                  @click="handleSearch(selectedKeys, confirm, column.dataIndex)"
                >
                  <template #icon><SearchOutlined /></template>
                  Search
                </a-button>
                <a-button size="small" style="width: 90px" @click="handleReset(clearFilters)">
                  Reset
                </a-button>
              </div>
            </template>
            <template #filterIcon="filtered">
              <search-outlined :style="{ color: filtered ? '#108ee9' : undefined }" />
            </template>
            
            <template #expandedRowRender="{ record }">
                <table>
                <tr style="background-color:#dff2f0">
                  <td style="margin: 0;" width=20%>
                    Project Name
                  </td>
                  <td style="margin: 0;" align="left" width=70%>
                    {{ record.project_name}}
                  </td>
                </tr>
                <tr style="background-color:#dff2f0">
                  <td style="margin: 0;" width=20%>
                    Project Description
                  </td>
                  <td style="margin: 0;" align="left" width=70%>
                    {{ record.project_desc}}
                  </td>
                </tr>
                <tr style="background-color:#dff2f0">
                  <td style="margin: 0;" width=20%>
                    Last Modified User
                  </td>
                  <td style="margin: 0;" align="left" width=70%>
                    {{ record.mouserid}} {{ record.modtc}}
                  </td>
                </tr>
                <tr v-if="record.comment != 'null' && record.comment != ''"
                  style="background-color:#dff2f0">
                  <td style="margin: 0;" width=20%>
                    Project Comments
                  </td>
                  <td style="margin: 0;" align="left" width=70%>
                    {{ record.comment}}
                  </td>
                </tr>
                <tr v-if="record.auditlog != 'null' && record.auditlog != ''"
                  style="background-color:#dff2f0"> 
                  <td style="margin: 0;" width=20%>
                    Change History
                  </td>
                  <td style="margin: 0;" align="left" width=70%>
                    <pre>{{ record.auditlog }}</pre>
                  </td>
                </tr>
                </table>
            </template>

            <template #fte_total="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_total == '0.00', 'totalhighftevaluestyle':record.fte_total >= this.warningValue, 'totalftevaluestyle':record.fte_total > '0.00' && record.fte_total < this.warningValue}">{{record.fte_total}}</div>
            </template>   
            <template #fsp_total="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_total == '0.00', 'totalhighfspvaluestyle':record.fsp_total >= this.warningValue, 'totalfspvaluestyle':record.fsp_total > '0.00' && record.fsp_total < this.warningValue}">{{record.fsp_total}}</div>
            </template>    
            <template #totalresource="{ record }">  
              <div :class="{'zerovaluestyle':record.totalresource == '0.00', 'totalhighvaluestyle':record.totalresource >= this.warningValue, 'totalvaluestyle':record.totalresource > '0.00' && record.totalresource < this.warningValue}">{{record.totalresource}}</div>
            </template>   

            <template #action="{ record }" align="left">
       
               <!-- <SmileTwoTone v-if="record.xlcruser.toUpperCase()==record.xlmouser.toUpperCase()" twoToneColor="#52c41a"/>
               <SmileTwoTone v-else-if="record.xlmouser.toUpperCase()==''" twoToneColor="#ba0404"/>
               <SmileTwoTone v-else twoToneColor="#eb2f96"/> -->

              <a-button
                type="link" style="padding:4px 8px"
                @click=" editVisibleBasic = true; strNewOrEdit='Edit'; selectCurrentItem(record,'edit'); "
                ><SettingOutlined /></a-button
              >
              <a-button
                type="link" style="padding:4px 8px" 
                @click=" editVisibleBudget = true; strNewOrEdit='Edit'; selectCurrentItem(record,'edit'); "
                ><TeamOutlined /></a-button
              >
              <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'编辑':'Edit'}}</a-button> -->

              <a-popconfirm
                v-if="dataSource.length"                
                title="Are you sure to delete?"
                @confirm="removeItem(record.record_id)"
              >
                <a-button  type="link" style="padding:4px 8px"><DeleteOutlined /></a-button>
                 <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'删除':'Delete'}}</a-button> -->
              </a-popconfirm>

            </template>
             
          </a-table>
          
        <!-- </a-spin> -->

        </a-tab-pane>

       <a-tab-pane key="3" tab="翻译任务进度"> 
          <!-- <a-spin tip="Loading..." :spinning="isLoading"> -->
          <a-table 
            class="list"
            :data-source="dataSource"
            bordered
            rowKey="record_id"
            :row-selection="{selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange, columnTitle:columnTitle}"
            :scroll="{x:1000, y:600}"
            :columns="columnsFTE"
            :customRow="customRightClick"
            @change="handleChange"
            size="middle"
            tableLayout="fixed"
          >

          <template #summary>
            <a-table-summary fixed>
            <a-table-summary-row >
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell></a-table-summary-cell>
              <a-table-summary-cell><div style="color:red; font-weight:bold">Total FTEs:</div></a-table-summary-cell>
              <a-table-summary-cell >
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalBexFTE == '0.00', 'highftevaluestyle':totalResources.totalBexFTE > '0.00'}">{{ totalResources.totalBexFTE.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalBexFSP == '0.00', 'highfspvaluestyle':totalResources.totalBexFSP > '0.00'}">{{ totalResources.totalBexFSP.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text ><div :class="{'zerovaluestyle':totalResources.totalCDDRAFTE == '0.00', 'highftevaluestyle':totalResources.totalCDDRAFTE > '0.00'}">{{ totalResources.totalCDDRAFTE.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalCDDRAFSP == '0.00', 'highfspvaluestyle':totalResources.totalCDDRAFSP > '0.00'}">{{ totalResources.totalCDDRAFSP.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalCDSAFTE == '0.00', 'highftevaluestyle':totalResources.totalCDSAFTE > '0.00'}">{{ totalResources.totalCDSAFTE.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalCDSAFSP == '0.00', 'highfspvaluestyle':totalResources.totalCDSAFSP > '0.00'}">{{ totalResources.totalCDSAFSP.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalDMFTE == '0.00', 'highftevaluestyle':totalResources.totalDMFTE > '0.00'}">{{ totalResources.totalDMFTE.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalDMFSP == '0.00', 'highfspvaluestyle':totalResources.totalDMFSP > '0.00'}">{{ totalResources.totalDMFSP.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text><div :class="{'zerovaluestyle':totalResources.totalCDDRAFTE == '0.00', 'highftevaluestyle':totalResources.totalCDDRAFTE > '0.00'}">{{ totalResources.totalSPFTE.toFixed(2) }}</div></a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text>{{ totalResources.totalSPFSP.toFixed(2) }}</a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text style="color:red">{{ totalResources.totalFTE.toFixed(2) }}</a-typography-text>
              </a-table-summary-cell>
              <a-table-summary-cell>
                <a-typography-text>{{ totalResources.totalFSP.toFixed(2) }}</a-typography-text>
              </a-table-summary-cell>

              <a-table-summary-cell>
                <a-typography-text><div :class="{'totalresource': totalResources.totalResource>=0}">{{ totalResources.totalResource}}</div></a-typography-text>
              </a-table-summary-cell>

            </a-table-summary-row>
             </a-table-summary>
          </template>

            <template #flag="{record }">
              <!-- <a-badge count="25" /> -->
              <div v-if="record.budget_comment!='' && record.budget_comment!=null">
                <a-tooltip color='#661703'>
                  <template #title>Budget Comments: <br>{{record.budget_comment}}</template>    
                  <BellTwoTone two-tone-color="#eb2f96"/>
                </a-tooltip>
               </div>
              </template>

            <!-- <template #function_name="{ record }">
              <template v-if="record.function_name !='DM'">
                KKK
              </template>
            </template> -->

            <!-- <template v-for="column in columnsFTE" v-slot:bodyCell="{record}">

            </template> -->

            <template #fte_bex="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_bex == '0.00', 'highftevaluestyle':record.fte_bex >= this.warningValue, 'ftevaluestyle':record.fte_bex > '0.00' && record.fte_bex < this.warningValue}">{{record.fte_bex}}</div>
            </template>
            <template #fte_cddra="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_cddra == '0.00', 'highftevaluestyle':record.fte_cddra >= this.warningValue, 'ftevaluestyle':record.fte_cddra > '0.00' && record.fte_cddra < this.warningValue}">{{record.fte_cddra}}</div>
            </template>         
            <template #fte_cdsa="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_cdsa == '0.00', 'highftevaluestyle':record.fte_cdsa >= this.warningValue, 'ftevaluestyle':record.fte_cdsa > '0.00' && record.fte_cdsa < this.warningValue}">{{record.fte_cdsa}}</div>
            </template>
            <template #fte_dm="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_dm == '0.00', 'highftevaluestyle':record.fte_dm >= this.warningValue, 'ftevaluestyle':record.fte_dm > '0.00' && record.fte_dm < this.warningValue}">{{record.fte_dm}}</div>
            </template>
            <template #fte_sp="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_sp == '0.00', 'highftevaluestyle':record.fte_sp >= this.warningValue, 'ftevaluestyle':record.fte_sp > '0.00' && record.fte_sp < this.warningValue}">{{record.fte_sp}}</div>
            </template>


            <template #fsp_bex="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_bex == '0.00', 'highfspvaluestyle':record.fsp_bex >= this.warningValue, 'fspvaluestyle':record.fsp_bex > '0.00' && record.fsp_bex < this.warningValue}">{{record.fsp_bex}}</div>
            </template>
            <template #fsp_cdsa="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_cdsa == '0.00', 'highfspvaluestyle':record.fsp_cdsa >= this.warningValue, 'fspvaluestyle':record.fsp_cdsa > '0.00' && record.fsp_cdsa < this.warningValue}">{{record.fsp_cdsa}}</div>
            </template>
            <template #fsp_cddra="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_cddra == '0.00', 'highfspvaluestyle':record.fsp_cddra >= this.warningValue, 'fspvaluestyle':record.fsp_cddra > '0.00' && record.fsp_cddra < this.warningValue}">{{record.fsp_cddra}}</div>
            </template>   
            <template #fsp_dm="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_dm == '0.00', 'highfspvaluestyle':record.fsp_dm >= this.warningValue, 'fspvaluestyle':record.fsp_dm > '0.00' && record.fsp_dm < this.warningValue}">{{record.fsp_dm}}</div>
            </template>    
            <template #fsp_sp="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_sp == '0.00', 'highfspvaluestyle':record.fsp_sp >= this.warningValue, 'fspvaluestyle':record.fsp_sp > '0.00' && record.fsp_sp < this.warningValue}">{{record.fsp_sp}}</div>
            </template>   

            <template #fte_total="{ record }">  
              <div :class="{'zerovaluestyle':record.fte_total == '0.00', 'totalhighftevaluestyle':record.fte_total >= this.warningValue, 'totalftevaluestyle':record.fte_total > '0.00' && record.fte_total < this.warningValue}">{{record.fte_total}}</div>
            </template>   
            <template #fsp_total="{ record }">  
              <div :class="{'zerovaluestyle':record.fsp_total == '0.00', 'totalhighfspvaluestyle':record.fsp_total >= this.warningValue, 'totalfspvaluestyle':record.fsp_total > '0.00' && record.fsp_total < this.warningValue}">{{record.fsp_total}}</div>
            </template>    
            <template #totalresource="{ record }">  
              <div :class="{'zerovaluestyle':record.totalresource == '0.00', 'totalhighvaluestyle':record.totalresource >= this.warningValue, 'totalvaluestyle':record.totalresource > '0.00' && record.totalresource < this.warningValue}">{{record.totalresource}}</div>
            </template>   

            <template #seq="{ index }">
              <!-- <a-badge count="25" /> -->
                {{ (index + 1)+(currentPage-1)*currentPageSize }}
              </template>

            <template #tier="{record}">
              <span>
                <a-tooltip placement="topLeft" trigger="click" >
                <template v-if="['TIER 0'].indexOf(record.tier.toUpperCase()) !=-1" #title>Tier 0 projects where DO provide resources but does not own</template>     
                <template v-else-if="['TIER 1'].indexOf(record.tier.toUpperCase()) !=-1" #title>Tier 1 projects with less than 4 months or 4 FTEs<br>Approval level: LF</template>
                <template v-else-if="['TIER 2'].indexOf(record.tier.toUpperCase()) !=-1" #title>Tier 2 projects with no capital spend (>4 months / >4 FTE<br>Approval level: DNGB;
                  <br><br>Tier 2 projects with capital spend less than 150k<br><br>Approval level: DNGB with further Endorsement of TIBPB and approval</template>
                <template v-else-if="['TIER 3'].indexOf(record.tier.toUpperCase()) !=-1" #title>Tier 3 projects with capital spend 150k – 500k<br>Approval level: TIBPB Endorsement, GDO LT</template>     
                <template v-else #title>Tier 4 projects with capital spend 500k – 2m <br>Approval level: TIBPB Endorsement, approval GDO LT > VMT
                                        <br><br>Tier 5 projects with capital spend >2m<br>Approval level: TIBPB Endorsement, approval GDO LT > VMT > GDD IC</template>
                <a-tag
                  :key="record.record_id"
                  :color="['TIER 0'].indexOf(record.tier.toUpperCase()) !=-1 ? 'black' : 
                  ['TIER 1'].indexOf(record.tier.toUpperCase())!=-1 ? 'green' : 
                  ['TIER 2'].indexOf(record.tier.toUpperCase())!=-1 ? 'red' : 
                  ['TIER 3'].indexOf(record.tier.toUpperCase())!=-1 ?'blue':'grey'"
                >
                  {{ record.tier.toUpperCase() }}
                </a-tag>
                 </a-tooltip>
              </span>
            </template>

            <template #status="{record}">
              <div style="text-align: left;" v-if="record.status!=null && record.status!=''">
                 <a-tag 
                  :key="record.record_id"
                  :color="['ACTIVE', 'PLAN', 'INITIAL'].indexOf(record.status.toUpperCase()) !=-1 ? 'blue' : 
                  ['COMPLETED', 'APPROVED'].indexOf(record.status.toUpperCase())!=-1 ? 'green' : 
                  ['ON-HOLD', 'ON HOLD'].indexOf(record.status.toUpperCase())!=-1 ? 'pink' : 
                  ['TERMINATED'].indexOf(record.status.toUpperCase())!=-1 ?'red':'grey'"
                >
                  {{ record.status.toUpperCase() }}
                </a-tag>
              </div>
            </template>

            <template #project_name="{record}">
              <a-tooltip color="#0d5780" placement="left" trigger="click">
                <template #title>{{record.project_desc}}</template>
                <div style="text-align: left;">
                  {{record.project_name}}
                </div>
              </a-tooltip>
            </template>

            <template #project_manager="{record}">
              <div style="text-align: left;">
                <a :href="'mailto:'+record.project_manager_email+'?subject=DNGB about NDP '+record.project_name+'&cc=' + 
                record.project_lead_email+'&body=Dear ' + record.project_manager + 
                ',%0D%0A%0D%0A%0D%0A'+ 'Regards,%0D%0A' + strUserName + ' On behalf of DNGB%0D%0ADO Non-Drug Governance Board' 
                ">{{record.project_manager}}</a>
              </div>
            </template>

            <template #filterDropdown="{ setSelectedKeys, selectedKeys, confirm, clearFilters, column }">
              <div style="padding: 8px">
                <a-input
                  ref="searchInput"
                  :placeholder="`Search ${column.dataIndex}`"
                  :value="selectedKeys[0]"
                  style="width: 188px; margin-bottom: 8px; display: block"
                  @change="e => setSelectedKeys(e.target.value ? [e.target.value] : [])"
                  @pressEnter="handleSearch(selectedKeys, confirm, column.dataIndex)"
                />
                <a-button
                  type="primary"
                  size="small"
                  style="width: 90px; margin-right: 8px"
                  @click="handleSearch(selectedKeys, confirm, column.dataIndex)"
                >
                  <template #icon><SearchOutlined /></template>
                  Search
                </a-button>
                <a-button size="small" style="width: 90px" @click="handleReset(clearFilters)">
                  Reset
                </a-button>
              </div>
            </template>
            <template #filterIcon="filtered">
              <search-outlined :style="{ color: filtered ? '#108ee9' : undefined }" />
            </template>
            
            <template #customRender="{ text, column }">
              <span v-if="searchText && searchedColumn === column.dataIndex">
                <template
                  v-for="(fragment, i) in text
                    .toString()
                    .split(new RegExp(`(?<=${searchText})|(?=${searchText})`, 'i'))"
                >
                  <mark
                    v-if="fragment.toLowerCase() === searchText.toLowerCase()"
                    class="highlight"
                    :key="i"
                  >
                    {{ fragment }}
                  </mark>
                  <template v-else>{{ fragment }}</template>
                </template>
              </span>
              <template v-else>
                {{ text }}
              </template>
            </template>

            <template #action="{ record }" align="left">
       
               <!-- <SmileTwoTone v-if="record.xlcruser.toUpperCase()==record.xlmouser.toUpperCase()" twoToneColor="#52c41a"/>
               <SmileTwoTone v-else-if="record.xlmouser.toUpperCase()==''" twoToneColor="#ba0404"/>
               <SmileTwoTone v-else twoToneColor="#eb2f96"/> -->

              <a-button
                type="link" style="padding:4px 8px"
                @click=" editVisibleBasic = true; strNewOrEdit='Edit'; selectCurrentItem(record); "
                ><SettingOutlined /></a-button
              >
              <a-button
                type="link" style="padding:4px 8px" 
                @click=" editVisibleBudget = true; strNewOrEdit='Edit'; selectCurrentItem(record); "
                ><TeamOutlined /></a-button
              >
              <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'编辑':'Edit'}}</a-button> -->

              <a-popconfirm
                v-if="dataSource.length"                
                title="Are you sure to delete?"
                @confirm="removeItem(record.record_id)"
              >
                <a-button  type="link" style="padding:4px 8px"><DeleteOutlined /></a-button>
                 <!-- <a-button v-else disabled type="link">{{this.lang==='cn'?'删除':'Delete'}}</a-button> -->
              </a-popconfirm>

            </template>
             
          </a-table>
          
        <!-- </a-spin> -->

        </a-tab-pane>

      </a-tabs>
        </a-spin>
      </a-layout-content>       


      <!-- <a-layout-footer style="text-align: center">
          <div style="margin-right: 0px;
                      margin-bottom: 10px;
                      margin-left: 0px;
                      margin-top: 30px;"><span>Powered by Data42, ©2020 </span></div>   
          <p class="errorMessage" v-if="errorMessage">{{ errorMessage }}</p>
          <p class="successMessage" style="text-align: left" v-if="successMessage">
            {{ successMessage }}
          </p>
      </a-layout-footer> -->
    </a-layout>
  </a-layout>
</template>

<script>

import {
  // UserOutlined, VideoCameraOutlined,UploadOutlined,
  PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined, ReadOutlined,LockOutlined,
  TagOutlined,
  UnlockOutlined,
  GroupOutlined,
  AppstoreOutlined,
  SyncOutlined,
  ClusterOutlined,
  ApartmentOutlined,
  WarningTwoTone,
  StarTwoTone,
  BellTwoTone,
  CommentOutlined,
  CheckCircleTwoTone,
  SlackOutlined,
  ReloadOutlined,
  GooglePlusOutlined,
  LoginOutlined,
  LogoutOutlined,
  SmileTwoTone,
  UserOutlined,
  RobotOutlined,
  TranslationOutlined,
  PushpinOutlined,
  SmileOutlined,
  DownOutlined,
  MinusOutlined,
  DeleteOutlined,
  MenuUnfoldOutlined,
  MailOutlined,
  FunnelPlotOutlined,
  ExportOutlined,
  ToolOutlined,
  CheckOutlined,
  EditOutlined,
  TeamOutlined,
  SearchOutlined,
  SettingOutlined,
  PlusOutlined,
  MenuFoldOutlined,
} from "@ant-design/icons-vue";
// import axios from "axios";
// import XLSX from 'xlsx';
import XLSX2 from 'xlsx-js-style';
import axios from '@/axios';
import moment from 'moment';
import dayjs from 'dayjs';
// import nvslogo from '@/assets/novartis-logo01.svg';
// import 'dayjs/locale/zh-cn';
import * as echarts from "echarts";
import { computed, defineComponent, onUpdated, onMounted, onUnmounted, reactive, ref, toRaw, toRefs, watch } from "vue";
import { cloneDeep} from "lodash-es";
import { message, } from "ant-design-vue";
import config from "../common/config.js";
// import locale from 'ant-design-vue/es/date-picker/locale/zh_CN';

// dayjs.locale('zh-cn');

export default defineComponent({
  name: "echartsBox",
  title: "DNGB",
  components: {
    // UserOutlined,
    // VideoCameraOutlined,
    SearchOutlined,
    GroupOutlined,
    AppstoreOutlined,
    SyncOutlined,
    ClusterOutlined,
    ApartmentOutlined,
    WarningTwoTone,
    StarTwoTone,
    BellTwoTone,
    CommentOutlined,
    CheckCircleTwoTone,
    PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined,ReadOutlined,LockOutlined,
    TagOutlined,
    UnlockOutlined,
    SlackOutlined,
    GooglePlusOutlined,
    ReloadOutlined,
    LoginOutlined,
    LogoutOutlined,
    SmileTwoTone,
    UserOutlined,
    TranslationOutlined,
    RobotOutlined,
    PushpinOutlined,
    SmileOutlined,
    DownOutlined,
    MinusOutlined,
    DeleteOutlined,
    CheckOutlined,
    EditOutlined,
    TeamOutlined,
    PlusOutlined,
    MailOutlined,
    FunnelPlotOutlined,
    AppstoreOutlined,
    SettingOutlined,
    MenuUnfoldOutlined,
    ExportOutlined,
    ToolOutlined,
    MenuFoldOutlined,
    // nvslogo,
  },

  data() {
    return {

      languages: [
          // { flag: 'us', language: 'en', title: 'English' },
          { flag: 'cn', language: 'cn', title: 'Chinese' },
          { flag: 'us', language: 'en', title: 'English' },
      ],

      contextMenuVisible: false,
      contextMenuStyle: {
        position: "absolute",
        top: "0",
        left: "0",
        border: "1px solid #eee"
      },

      customRightClick: record => ({      
        on: {
          contextmenu: e => {
            e.preventDefault();
            this.menuData = record;
            this.contextMenuVisible = true;
            this.contextMenuStyle.top = e.clientY + "px";
            this.contextMenuStyle.left = e.clientX + "px";
            document.body.addEventListener("click", this.bodyClick);
          }
        }
      }),

      userconfig: config,
      showingModal: false,
      showingeditModal: false,
      showingdeleteModal: false,
      editRow: {},    
      studylist:[],
      // functionChecklist: [],
    };
  },

  setup() {

    onMounted(() => {
      // initChart();

      //get the current url;
      // console.log(window.location.href);


      // myDashBoardChart=echart.init(document.getElementById("myEcharts"), "auto");      
      // refreshChart(myDashBoardChart)
    });

    onUnmounted(() => {
      echart.dispose;
    });

  

    //config the threld value for the cell color;

    // const dateFormat = 'YYYY-MM-DD'

    const blSearchInCacheOrBackend=ref(false);

    const warningValue=ref(4);

    const valueFTEType=ref('Internal');
    const resetForm = () => {
      // console.log(formRef);
      // console.log(formRef.keys);
      formRef.value.resetFields();
    };
    const clearForm = () => {
      // console.log(formRef.value);
      console.log(this.$refs);
      // var self = this;
      // Object.keys(formRef.value).forEach(function(key,index) {
      //     formRef.value[key] = '';
      // });

    };
    const globalFunctionList = ref([]);

    let echart = echarts;
    let totalTier0NDPs=ref(0);
    let totalTier1NDPs=ref(0);
    let totalTier2NDPs=ref(0);
    let totalTier3NDPs=ref(0);

    let totalActiveNDPs=ref(0);
    let totalCompletedNDPs=ref(0);
    let totalOnHoldNDPs=ref(0);
    let totalTerminatedNDPs=ref(0);
    let totalOtherNDPs=ref(0);
    let totalNDPs=ref(0);
    let totalFTE=ref(0);
    let totalInternalFTE=ref(0);
    let totalExternalFTE=ref(0);

    const tagNameSwitchCheck = ref(false);
    const pageTotalLabel=ref('');
    const userconfig=reactive(config);
    const statusList=reactive(config.statusList);

    const strNewOrEdit = ref('New');

    const inputValue = ref('');
    const functionChecklist = ref([]);
    const statusChecklist = ref([]);
    const radioStyle = reactive({
      display: 'block',
      height: '50px',
      lineHeight: '30px',
    });

    const onChangePickDate=(dt)=>{     
      // form= moment(dt).format("YYYY-MM-DD");
      // console.log(formState.project_stdtc);
      // console.log(dt);
    };

    const ndptierlist = ref([]);
    const ndpfunctionlist = ref([]);
    const ndpstatuslist = ref([]);
    const ndpsubfunctionlist = ref([]);
    const ndpbusinessunitlist = ref([]);
    const ndpgdocategorylist = ref([]);
    const ndpimpactlevellist = ref([]);
    const ndpdefinitiontypelist = ref([]);
    const ndptagnamelist = ref([]); 

    const stripe = ref();
    const columnTitle = ref(' ');
    const successMessage = ref("");
    const errorMessage = ref("");
    const searchInput = ref();
    const strUserName =  ref("");
    const strUserID =  ref("");
    const editableData = reactive({});
    const clickedItem=reactive({});

    const isLogin = ref(false);
    const isAdmin = ref(false);
    const lang =ref('en');

    const pieRadius =reactive([]);

    const grpByTierResults =reactive([]);
    const grpByFunctionResults =reactive([]);
    const grpByImpactResults =reactive([]);
    const grpByStatusResults =reactive([]);
    const sumByFunctionGroup =reactive([]);


    let myDashBoardChart;

    // 基础配置一下Echarts

    // var name=[];
    // var list=[];
    // for(var i=0; i<libtypelist.length;i++){
    //   name.push(libtypelist[i].LIB_TYPE);
    //   list.push({value:libtypelist[i].num,name:libtypelist[i].LIB_TYPE});
    // }

    const initChart=function(){

      console.log("tabclick event ok")

      let chart = echart.init(document.getElementById("myEcharts"), "auto");
      // let chart = echart.init(document.getElementById("myEcharts1"), "auto");

      var intOffsetPanel=50;
      var intOffsetX=25;
      var intScreenWidth=document.body.scrollWidth-intOffsetPanel;
      var intPieWidth = intScreenWidth*2/22;
      // pieRadius.value=[45, intPieWidth/2];
      pieRadius.value=[intPieWidth/2-10, intPieWidth/2];
      let pieYaxis="45%";

      // console.log(intPieWidth);    
      var intPieSpace=(intScreenWidth-90-intPieWidth*6)/4.4; 
      // if(collapsed.value==true){
      //   intPieSpace=(intScreenWidth-90-intPieWidth*6)/4.4
      // }
      // else{
      //   intPieSpace=(intScreenWidth-90-intPieWidth*6)/5
      // }
     

      //  console.log(intPieSpace); 

      let pieXaxis1=intOffsetX+intPieWidth;
      let pieXaxis2=intOffsetX+intPieWidth*2+intPieSpace;
      let pieXaxis3=intOffsetX+intPieWidth*3+2*intPieSpace;
      let pieXaxis4=intOffsetX+intPieWidth*4+3*intPieSpace;
      let pieXaxis5=intOffsetX+intPieWidth*5+4*intPieSpace;

      // console.log(pieXaxis1); 
      // console.log(pieXaxis2); 
      // console.log(pieXaxis3); 
      // console.log(pieXaxis4); 
      // console.log(pieXaxis5); 
      
      // 把配置和数据放这里

      var colorList=['#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac'];
      let option={
        // color:['#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac', '#0090ff', '#06d3c4', '#ffbc32', '#2ccc44', '#ff3976', '#6173d6', '#914ce5', '#42b1cc', '#ff55ac'],
        tooltip: {
          trigger: 'item',
          formatter: "{a} <br/>{b} : {c} ({d}%)",
          // enabled: false

        },

        stillShowZeroSum: false,
        // hover: {mode: null},
        
        legend: {   //图例文字
            orient:'horizontal',
            data:[],
            top: '80%',
            right:'30%',
            icon: "circle", //这个字段控制形状
            itemGap: 10,    //设置间距
            textStyle:{     //图例文字的样式
                color:'#424F65',
                fontSize:14,
                fontWeight:700,
                rich:{    //这里面的 a、b 是在formatter中定义的
                    a:{
                        width:50,
                        fontSize:14,
                        fontWeight:700,
                        color:"#666",
                    },
                    b:{
                        width:60,
                        fontSize:14,
                        fontWeight:700,
                        align: 'right',
                        color:'#3EF771',
                    },
                },
            },
            // 重写legend显示样式 legend显示内容
            // formatter: function(name) {
            //     let data = option.series[0].data;
            //     let total = 0;
            //     let tarValue = 0;
            //     for (let i = 0, l = data.length; i < l; i++) {
            //         total += data[i].value;
            //         if (data[i].name == name) {
            //             tarValue = data[i].value;
            //         }
            //     }
            //     let p = (tarValue / total * 100).toFixed(2);
            //     return ['{a|'+name+'}{b|'+ (p?parseFloat(p):0) +'%}']
            // },
          },


          series: [
            //series 1 data
              {
                name: 'Function Group：',
                type: 'pie',
                radius: pieRadius.value,
                center: [pieXaxis1, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                itemStyle: {
                    color: function(params) {
                        return colorList[params.dataIndex]
                    }                      
                  },
                label: {
                    show: true,
                    position: 'outside',
                    formatter:function (params) {
                          return params.name + ": " + params.percent + "%"
                      },
                    fontSize:11,
                    // fontWeight:"bold",
                    // color:"black"
              },
              emphasis: {
                // scale:true,
                // scaleSize:20,
                label: {
                  show: true,
                  // fontSize: '18',
                  // fontWeight: 'bold'
                },
                itemStyle: {
                    // Color in emphasis state.
                    // color: 'red',
                 },
              },
                selectedMode: 'single',
                data: grpByFunctionResults.value
          },

         //series 1 data
              {
                name: 'Function',
                type: 'pie',
                radius: pieRadius.value[0],
                center: [pieXaxis1, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                silent: true,//disable hover click event in series
                itemStyle: {
                    color: "#ffffff"                      
                  },
                label: {
                    show: true,
                    position: 'center',
                    formatter:function (params) {
                          return params.name 
                      },
                    fontSize:18,
                    fontWeight:"bold",
                    color:"#000000"
              },
                data: [{value:1, name: "Function"}]
          },

            //series 2 data
        {
                name: 'NDP：',
                type: 'pie',
                radius: pieRadius.value,
                center: [pieXaxis2, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                itemStyle: {
                    color: function(params) {
                        return colorList[params.dataIndex]
                    }                      
                  },
                label: {
                    show: true,
                    position: 'outside',
                    formatter:function (params) {
                          // return params.name + ": " + params.value + " ("+params.percent + "%)"
                          return params.name + ": " + params.percent + "%"
                     },
                    fontSize:12,
                    // fontWeight:"bold",
                    // color:"#000000"
                  },

                data: grpByTierResults.value
          },

        //series 1 data
              {
                name: 'Tier',
                type: 'pie',
                radius: pieRadius.value[0],
                center: [pieXaxis2, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                silent: true,//disable hover click event in series
                itemStyle: {
                    color: "#ffffff"                      
                  },
                label: {
                    show: true,
                    position: 'center',
                    formatter:function (params) {
                          return params.name 
                      },
                    fontSize:18,
                    fontWeight:"bold",
                    color:"#000000"
                                        
              },
                data: [{value:1, name: "Tier"}]
          },

           //series 3 data
        {
                name: 'Status：',
                type: 'pie',
                radius: pieRadius.value,
                center: [pieXaxis3, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                itemStyle: {
                    color: function(params) {
                        return colorList[params.dataIndex]
                    }                      
                  },
                label: {
                    show: true,
                    position: 'outside',
                    formatter:function (params) {
                          // return params.name + ": " + params.value + " ("+params.percent + "%)"
                          return params.name + ": " + params.percent + "%"
                      },
                    fontSize:11,
                    // fontWeight:"bold",
                    // color:"#000000"                 
              },

                data: grpByStatusResults.value
          },

        //series 1 data
              {
                name: 'Status',
                type: 'pie',
                radius: pieRadius.value[0],
                center: [pieXaxis3, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                silent: true,//disable hover click event in series
                itemStyle: {
                    color: "#ffffff"                      
                  },
                label: {
                    show: true,
                    position: 'center',
                    formatter:function (params) {
                          return params.name 
                      },
                    fontSize:18,
                    fontWeight:"bold",
                    color:"#000000"
              },
                data: [{value:1, name: "Status"}]
          },

         //series 4 data
        {
                name: 'Impact Level：',
                type: 'pie',
                radius: pieRadius.value,
                center: [pieXaxis4, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                itemStyle: {
                    color: function(params) {
                        return colorList[params.dataIndex]
                    }                      
                  },
                label: {
                    show: true,
                    position: 'outside',
                    formatter:function (params) {
                          // return params.name + ": " + params.value + " ("+params.percent + "%)"
                          return params.name + ": " + params.percent + "%"
                      },
                    fontSize:11,
                    // fontWeight:"bold",
                    // color:"#000000"
              },

                data:grpByImpactResults.value
          },

        //series 1 data
              {
                name: 'Impact',
                type: 'pie',
                radius: pieRadius.value[0],
                center: [pieXaxis4, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                silent: true,//disable hover click event in series
                itemStyle: {
                    color: "#ffffff"                      
                  },
                label: {
                    show: true,
                    position: 'center',
                    formatter:function (params) {
                          return params.name 
                      },
                    fontSize:18,
                    fontWeight:"bold",
                    color:"#000000"
              },
                data: [{value:1, name: "Impact Level"}]
          },

         //series 5 FTE data
        {
                name: 'Assigned FTE：',
                type: 'pie',
                radius: pieRadius.value,
                center: [pieXaxis5, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                itemStyle: {
                    color: function(params) {
                        return colorList[params.dataIndex]
                    }                      
                  },
                label: {
                    show: true,
                    position: 'outside',
                    formatter:function (params) {
                          // return params.name + ": " + params.value + " ("+params.percent + "%)"
                          return params.name + ": " + params.percent + "%"
                      },
                    fontSize:11,
                    // fontWeight:"bold",
                    // color:"#000000"
              },

                data:sumByFunctionGroup.value
          },


        //series 1 data
              {
                name: 'FTE',
                type: 'pie',
                radius: pieRadius.value[0],
                center: [pieXaxis5, pieYaxis],//环形图--显示位置
                avoidLabelOverlap: false,
                silent: true,//disable hover click event in series
                itemStyle: {
                    color: "#ffffff"                      
                  },
                label: {
                    show: true,
                    position: 'center',
                    formatter:function (params) {
                          return params.name 
                      },
                    fontSize:18,
                    fontWeight:"bold",
                    color:"#000000"
              },
                data: [{value:1, name: "FTE"}]
          },


        ],

        


      };

      chart.setOption(option);
      
      window.onresize = function() {
        //自适应大小
        chart.resize();
        initChart();
      };
    };

    const refreshChart=(chart)=>{

      pieRadius.value=['25%', '40%'];
      
      // 把配置和数据放这里
      let option={
        color:['#57FF64','#FFA53C','#675AFF','#FF457E','#39D7DE','#026DF0','#0233F0','#026FF0','#02DDF0','#056DF0','#0F6DF0','#0277F0','#0288F0'],
        tooltip: {
          trigger: 'item',
        },
        
        legend: {   //图例文字
            orient:'horizontal',
            top: '70%',
            right:'35%',
            icon: "circle", //这个字段控制形状
            itemGap: 10,    //设置间距
            textStyle:{     //图例文字的样式
                color:'#424F65',
                fontSize:14,
                fontWeight:700,
                rich:{    //这里面的 a、b 是在formatter中定义的
                    a:{
                        width:50,
                        fontSize:14,
                        fontWeight:700,
                        color:"#666",
                    },
                    b:{
                        width:60,
                        fontSize:14,
                        fontWeight:700,
                        align: 'right',
                        color:'#3EF771',
                    },
                },
            },
            // 重写legend显示样式 legend显示内容
            // formatter: function(name) {
            //     let data = option.series[0].data;
            //     let total = 0;
            //     let tarValue = 0;
            //     for (let i = 0, l = data.length; i < l; i++) {
            //         total += data[i].value;
            //         if (data[i].name == name) {
            //             tarValue = data[i].value;
            //         }
            //     }
            //     let p = (tarValue / total * 100).toFixed(2);
            //     return ['{a|'+name+'}{b|'+ (p?parseFloat(p):0) +'%}']
            // },
          },


          series: [
            //series 1 data
              {
                name: '提示：',
                type: 'pie',
                radius: pieRadius.value,
                center: ['15%', '40%'],//环形图--显示位置
                avoidLabelOverlap: false,
                label: {
                    show: true,
                    position: 'outside',
                    normal: {
                        show: true,
                        position: 'center',
                        // formatter:function(){
                        //     return 'Functions'
                        // },

                    },
                    fontSize:17,
                    color:"#666"
              },

                data: grpByFunctionResults.value
          },


            //series 2 data
        {
                name: '提示：',
                type: 'pie',
                radius: pieRadius.value,
                center: ['35%', '40%'],//环形图--显示位置
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center',
                    normal: {
                        show: true,
                        position: 'center',
                        // formatter:function(){
                        //     return ' Tiers'
                        // },
                    },
                    fontSize:17,
                    color:"#666"
              },

                data: grpByTierResults.value
          },


           //series 3 data
        {
                name: '提示：',
                type: 'pie',
                radius: pieRadius.value,
                center: ['55%', '40%'],//环形图--显示位置
                avoidLabelOverlap: false,
                label: {
                    show: false,
                    position: 'center',
                    normal: {
                        show: true,
                        position: 'center',
                        // formatter:function(){
                        //     return ' FTE'
                        // },
                    },
                    fontSize:17,
                    color:"#666"
              },

                data: grpByFunctionResults.value
          },

         //series 4 data
        {
                name: '提示：',
                type: 'pie',
                radius: pieRadius.value,
                center: ['75%', '40%'],//环形图--显示位置
                avoidLabelOverlap: false,
                label: {
                    show: true,
                    position: 'center',

                    fontSize:17,
                    color:"#666"
              },

                data:grpByImpactResults.value
          },


        ],
      };

      chart.setOption(option);
      
      window.onresize = function() {
        //自适应大小
        chart.resize();
      };
    }

    const groupBy=(list, key)=>{
      const obj={};
      list.map(item=>{
        if (!obj[item[key]]){
          obj[item[key]]=[];
        }
        obj[item[key]].push(item);
      });
      return obj;
    };

    const reloadEcharts=(obj)=>{
        console.log(obj)
        

    }

    const getUniqueArray=(arr, keyProps)=> {
      const kvArray = arr.map(entry => {
        const key = keyProps.map(k => entry[k]).join('|');
        return [key, entry];
      });
      const map = new Map(kvArray);
      return Array.from(map.values());
      };   
            
    const uniqueValueListSelected= (keyname)=> {
          //  var output = [];
          var keys   = [];
          //  var subTotals = 0;
          dataSource.value.forEach(function (record) {
            if(record[keyname]!=null){
              var key = record[keyname].toUpperCase();
              if (keys.indexOf(key) === -1) {
                  keys.push(key);
                  //  output.push(record);
              }}
          });

          return keys;
    };

    const columnsList = reactive([
      {
 
      },
    ]);
    const columnsFTE = reactive([
      {
 
      },
    ]);
    const selectedRowKeyList = ref(1);
    const currentPage = ref(1);
    const currentPageSize = ref(1);
    const filteredInfo = ref();
    const sortedInfo = ref();

    const sortArrayByKey=(array, key)=> {
        return array.sort(function(a, b) {
            var x = a[key]; var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    };

   const uniqueCapitalLetterListSelected= (keyname)=> {
        //  var output = [];
         var keys   = [];
         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();
             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };


//   const groupBy=(array, f)=> {
//        let groups = {};
//        array.forEach(function (o) {
//          var group = JSON.stringify(f(o));
//          groups[group] = groups[group] || [];
//          groups[group].push(o);
//        });
//     return Object.keys(groups).map(function (group) {
//       return groups[group];
//     })
//  };

  const calcDashBoardMetrics=(ds)=>{

      //calculate the fte summary;
      ds.forEach((item)=>{
          // console.log(item);
          item.fte_total=calcSummary([item.fte_bex,item.fte_cddra,item.fte_cdsa,item.fte_dm,item.fte_sp]).toFixed(2);
          item.fsp_total=calcSummary([item.fsp_bex,item.fsp_cddra,item.fsp_cdsa,item.fsp_dm,item.fsp_sp]).toFixed(2);
          item.totalresource=calcSummary([item.fte_total,item.fsp_total]).toFixed(2);
          // console.log(item);
      });


      //calculate the fte summary;
      totalResources.totalBexFTE =  0;
      totalResources.totalBexFSP = 0;
       totalResources.totalBex = 0;

      totalResources.totalCDDRAFTE = 0;
      totalResources.totalCDDRAFSP = 0;
      totalResources.totalCDDRA = 0;

      totalResources.totalCDSAFTE = 0;
      totalResources.totalCDSAFSP = 0;
      totalResources.totalCDSA = 0;

      totalResources.totalDMFTE = 0;
      totalResources.totalDMFSP =0;
      totalResources.totalDM = 0;

      totalResources.totalSPFTE = 0;
      totalResources.totalSPFSP = 0;
      totalResources.totalSP = 0;

      totalResources.totalFTE=0;
      totalResources.totalFSP=0;

      totalResources.totalResource=0;
      
      ds.forEach((item)=>{
          // console.log(item);
          item.fte_total=calcSummary([item.fte_bex,item.fte_cddra,item.fte_cdsa,item.fte_dm,item.fte_sp]).toFixed(2);
          item.fsp_total=calcSummary([item.fsp_bex,item.fsp_cddra,item.fsp_cdsa,item.fsp_dm,item.fsp_sp]).toFixed(2);
          item.totalresource=calcSummary([item.fte_total,item.fsp_total]).toFixed(2);
          // console.log(item);

          totalResources.totalBexFTE =  calcSummary([ totalResources.totalBexFTE,item.fte_bex]);
          totalResources.totalBexFSP = calcSummary([ totalResources.totalBexFSP,item.fsp_bex]);
          totalResources.totalBex = calcSummary([ totalResources.totalBexFTE,totalResources.totalBexFSP]);

          totalResources.totalCDDRAFTE = calcSummary([totalResources.totalCDDRAFTE,item.fte_cddra]);
          totalResources.totalCDDRAFSP = calcSummary([totalResources.totalCDDRAFSP, item.fsp_cddra]);
          totalResources.totalCDDRA = calcSummary([ totalResources.totalCDDRAFTE,totalResources.totalCDDRAFSP]);

          totalResources.totalCDSAFTE = calcSummary([totalResources.totalCDSAFTE,item.fte_cdsa]);
          totalResources.totalCDSAFSP = calcSummary([totalResources.totalCDSAFSP,item.fsp_cdsa]);
          totalResources.totalCDSA = calcSummary([totalResources.totalCDSAFTE,totalResources.totalCDSAFSP]);
          
          totalResources.totalDMFTE = calcSummary([totalResources.totalDMFTE,item.fte_dm]);
          totalResources.totalDMFSP = calcSummary([totalResources.totalDMFSP,item.fsp_dm]);
          totalResources.totalDM = calcSummary([totalResources.totalDMFTE,totalResources.totalDMFSP]);

          totalResources.totalSPFTE = calcSummary([totalResources.totalSPFTE,item.fte_sp]);
          totalResources.totalSPFSP = calcSummary([totalResources.totalSPFSP,item.fsp_sp]);
          totalResources.totalSP = calcSummary([totalResources.totalSPFTE,totalResources.totalSPFSP]);

          totalResources.totalFTE=calcSummary([totalResources.totalBexFTE,
          totalResources.totalCDDRAFTE,
          totalResources.totalCDSAFTE,
          totalResources.totalDMFTE,
          totalResources.totalSPFTE]);

          totalResources.totalFSP=calcSummary([totalResources.totalBexFSP,
          totalResources.totalCDDRAFSP,
          totalResources.totalCDSAFSP,
          totalResources.totalDMFSP,
          totalResources.totalSPFSP]);

          totalResources.totalResource=calcSummary([totalResources.totalFTE,totalResources.totalFSP]);

          // item.totalresource=totalResources.totalResource;
          // item.fte_total=totalResources.totalFTE;
          // item.fsp_total=totalResources.totalFSP
          
      });

      totalResources.totalBex=totalResources.totalBex.toFixed(2);
      totalResources.totalCDDRA=totalResources.totalCDDRA.toFixed(2);
      totalResources.totalCDSA=totalResources.totalCDSA.toFixed(2);
      totalResources.totalDM=totalResources.totalDM.toFixed(2);
      totalResources.totalSP=totalResources.totalSP.toFixed(2);
      totalResources.totalResource=totalResources.totalResource.toFixed(2);

      // console.log("Print resources: "+totalResources.totalCDSAFTE);
      // console.log("Print resources: "+totalResources.totalDMFTE);
      // console.log("Print resources: "+totalResources.totalFTE);
                 
      var jsonData, grpByResult;
      var i=0;

      grpByTierResults.value=[];
      grpByResult=groupBy(Array.from(ds),'tier');
      Object.values(grpByResult).forEach(element=> {
        jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
        grpByTierResults.value.push(jsonData);
        i+=1;
      });

      i=0;
      grpByFunctionResults.value=[];
      grpByResult=groupBy(Array.from(ds),'function_name');
      // console.log(grpByResult);

      Object.values(grpByResult).forEach(element=> {
        jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
        grpByFunctionResults.value.push(jsonData);
        i+=1;
      });

      i=0;
      grpByImpactResults.value=[];
      grpByResult=groupBy(Array.from(ds),'impact_level');
      Object.values(grpByResult).forEach(element=> {
        jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
        grpByImpactResults.value.push(jsonData);
        i+=1;
      });

      grpByStatusResults.value=groupBy(Array.from(ds),'status');

      // console.log(grpByStatusResults.value);

      //calculate the numbers of each tier/function NDPs
      totalActiveNDPs.value=grpByStatusResults.value["ACTIVE"]!=null?grpByStatusResults.value["ACTIVE"].length:0;
      totalOnHoldNDPs.value=grpByStatusResults.value["ON HOLD"]!=null?grpByStatusResults.value["ON HOLD"].length:0;
      totalCompletedNDPs.value=grpByStatusResults.value["COMPLETED"]!=null?grpByStatusResults.value["COMPLETED"].length:0;
      totalTerminatedNDPs.value=grpByStatusResults.value["TERMINATED"]!=null?grpByStatusResults.value["TERMINATED"].length:0;
      totalOtherNDPs.value=grpByStatusResults.value["PLAN"]!=null?grpByStatusResults.value["PLAN"].length:0;
      totalNDPs.value=totalActiveNDPs.value+totalOnHoldNDPs.value+totalTerminatedNDPs.value+totalCompletedNDPs.value+totalOtherNDPs.value;

      //calculate FTE
      // let sumFTE = ds.reduce((item, {
      //   function_name, fte_total
      // })=>(item[function_name]=(item[function_name]||0)+parseFloat(fte_total), item),{});


      // console.log(sumFTE);
      sumByFunctionGroup.value=[];
      if(totalResources.totalResource){
      sumByFunctionGroup.value=[
        {"name": "BEX", "value": totalResources.totalBex},
        {"name": "CDDRA", "value": totalResources.totalCDDRA},
        {"name": "CDSA", "value": totalResources.totalCDSA},
        {"name": "DM", "value": totalResources.totalDM},
        {"name": "SP", "value": totalResources.totalSP},
      ];
      }

      // totalFTE.value=0;
      // Object.values(sumFTE).forEach(()=> {
      //   jsonData={"name": Object.keys(sumFTE)[i], "value": parseFloat(Object.values(sumFTE)[i]).toFixed(2)};
      //   sumByFunctionGroup.value.push(jsonData);
      //   if(Object.values(sumFTE)[i]!=null){          
      //     totalFTE.value=parseFloat(Object.values(sumFTE)[i]+totalFTE.value);
      //   }
      //   i+=1;
      // });

      // console.log(sumByFunctionGroup.value);
      // console.log(totalFTE.value);

      i=0;
      grpByStatusResults.value=[];
      grpByResult=groupBy(Array.from(ds),'status');
      Object.values(grpByResult).forEach(element=> {
        jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
        grpByStatusResults.value.push(jsonData);
        i+=1;
      });

      // refreshChart(myDashBoardChart.value);
      initChart();
  }

  const handleSearchInputChange=()=> {
    
      // console.log(userStudyID.value)
    if(blSearchInCacheOrBackend.value==false){
      dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));

      dataSource.value = dataSource.value.filter(
        (item) =>
          (
          item.project_name.toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.project_lead!=null?item.project_lead:"").toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.project_manager!=null?item.project_manager:"").toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.horizon_wpid!=null?item.horizon_wpid:"").toLowerCase().includes(inputValue.value.toLowerCase()) 
          ) 
      );

      // functionChecklist.value=uniqueCapitalLetterListSelected('userid').sort((a, b) => (a > b) ? 1 : -1);

        // statusChecklist.value=uniqueValueListSelected('status').sort((a, b) => (a > b) ? 1 : -1);

        //   if (menuKey.value=='tier'){
        //     functionChecklist.value=uniqueValueListSelected('function_name').sort((a, b) => (a > b) ? 1 : -1);
        //   }
        //   else if(menuKey.value=='function_name'){
        //     functionChecklist.value=uniqueValueListSelected('sub_function_name').sort((a, b) => (a > b) ? 1 : -1);
        //   }

      // statusChecklist.value=uniqueValueListSelected('function_name').sort((a, b) => (a > b) ? 1 : -1);

      // console.log(statusChecklist.value);
      // localStorage.setItem("protocolid", userProtocolID.value);
      // localStorage.setItem("studyid", userStudyID.value);
      localStorage.setItem("searchterm", inputValue.value);

      calcDashBoardMetrics(dataSource.value);

      // console.log(totalResources.value);

      // grpByTierResults.value=groupBy(Array.from(dataSource.value),function (item) {return [item.function_name];});

      // var jsonData, grpByResult;
      // var i=0;

      // grpByTierResults.value=[];
      // grpByResult=groupBy(Array.from(dataSource.value),'tier');
      // Object.values(grpByResult).forEach(element=> {
      //   jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
      //   grpByTierResults.value.push(jsonData);
      //   i+=1;
      // });

      // i=0;
      // grpByFunctionResults.value=[];
      // grpByResult=groupBy(Array.from(dataSource.value),'function_name');
      // // console.log(grpByResult);

      // Object.values(grpByResult).forEach(element=> {
      //   jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
      //   grpByFunctionResults.value.push(jsonData);
      //   i+=1;
      // });

      // i=0;
      // grpByImpactResults.value=[];
      // grpByResult=groupBy(Array.from(dataSource.value),'impact_level');
      // Object.values(grpByResult).forEach(element=> {
      //   jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
      //   grpByImpactResults.value.push(jsonData);
      //   i+=1;
      // });

      // // i=0;
      // // grpByResult=groupBy(Array.from(dataSource.value),'function_name');
      // // Object.values(grpByResult).forEach(element=> {
      // //   jsonData={"name": Object.keys(grpByResult)[i], "value": element.length};
      // //   grpByResult.value.push(jsonData);
      // //   i+=1;
      // // });


      // grpByStatusResults.value=groupBy(Array.from(dataSource.value),'status');

      // // console.log(grpByStatusResults.value);

      // //calculate the numbers of each tier/function NDPs
      // totalActiveNDPs.value=grpByStatusResults.value["Active"]!=null?grpByStatusResults.value["Active"].length:0;
      // totalOnHoldNDPs.value=grpByStatusResults.value["On Hold"]!=null?grpByStatusResults.value["On Hold"].length:0;
      // totalCompletedNDPs.value=grpByStatusResults.value["Completed"]!=null?grpByStatusResults.value["Completed"].length:0;
      // totalTerminatedNDPs.value=grpByStatusResults.value["Terminated"]!=null?grpByStatusResults.value["Terminated"].length:0;
      // totalOtherNDPs.value=grpByStatusResults.value["Unknown"]!=null?grpByStatusResults.value["Unknown"].length:0;
      // totalNDPs.value=totalActiveNDPs.value+totalOnHoldNDPs.value+totalTerminatedNDPs.value+totalCompletedNDPs.value+totalOtherNDPs.value;

      // totalTier0NDPs.value=grpByStatusResults["Active"].length;
      // totalTier1NDPs.value=dataSource.value.filter(
      //     (item) =>
      //       (
      //       item.tier.toLowerCase().includes('tier 1') 
      //       ) 
      //   ).length;
      // totalTier2NDPs.value=dataSource.value.filter(
      //     (item) =>
      //       (
      //       item.tier.toLowerCase().includes('tier 2') 
      //       ) 
      //   ).length;
      // totalTier3NDPs.value=dataSource.value.filter(
      //     (item) =>
      //       (
      //       item.tier.toLowerCase().includes('tier 3') 
      //       ) 
      //   ).length;

        // initChart();
        

        // console.log(totalTier3NDPs.value);

    };
  };


  const handleSearchInput2=()=> {
    
    //   console.log("handleSearchinput:" + blSearchInCacheOrBackend.value)

      if(blSearchInCacheOrBackend.value==false){
        dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));

        dataSource.value = dataSource.value.filter(
            (item) =>
            (
          item.project_name.toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.project_lead!=null?item.project_lead:"").toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.project_manager!=null?item.project_manager:"").toLowerCase().includes(inputValue.value.toLowerCase()) ||
          (item.horizon_wpid!=null?item.horizon_wpid:"").toLowerCase().includes(inputValue.value.toLowerCase()) 
            ) 
        );

        localStorage.setItem("searchterm", inputValue.value);
      }else if(blSearchInCacheOrBackend.value==true){
         
            if (inputValue.value==""){
                return;
            }

            if (inputValue.value.toString().length<=2){
                return;
            }

            //construct the where clause with the input value;
            //if contains && then treat as a and logic;

            var whereClause="";
            var seq=0;

            if (inputValue.value.toLowerCase().indexOf("&")!=-1){

                inputValue.value.toLowerCase().split("&").forEach((item)=>{

                    if(seq==0){
                        whereClause="(lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    else{
                        whereClause= whereClause + " and (lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    seq=seq+1;
                })

                f_queryMysql("do-ndp-list","*",whereClause, '0,100');
                return;

            }
         
            if (inputValue.value.toLowerCase().indexOf("and")!=-1){

                inputValue.value.toLowerCase().split("and").forEach((item)=>{

                    if(seq==0){
                        whereClause="(lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    else{
                        whereClause= whereClause + " and (lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    seq=seq+1;
                })

                f_queryMysql("do-ndp-list","*",whereClause ,'0,100');
                return;

            }

            if (inputValue.value.toLowerCase().indexOf("or")!=-1){

                inputValue.value.toLowerCase().split("or").forEach((item)=>{

                    if(seq==0){
                        whereClause="(lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    else{
                        whereClause= whereClause + " or (lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    seq=seq+1;
                })

                f_queryMysql("do-ndp-list","*",whereClause,'0,100' );
                return;

            };

            if (inputValue.value.toLowerCase().indexOf(",")!=-1){

                inputValue.value.toLowerCase().split(",").forEach((item)=>{

                    if(seq==0){
                        whereClause="(lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    else{
                        whereClause= whereClause + " or (lower(project_name) like '%" + item.trim() + "%' or lower(project_desc) like '%" + item.trim()+ "%' or lower(comment) like '%" + item.trim()+ "%'or lower(project_lead) like '%" + item.trim()+ "%'or lower(project_manager) like '%" + item.trim()+ "%' or find_in_set('"+item.trim()+"', lower(tagname)))";
                    }
                    seq=seq+1;
                })

                f_queryMysql("do-ndp-list","*",whereClause,'0,100' );
                return;

            };

            //for single condition clause
            // console.log(whereClause)
            whereClause="(lower(project_name) like '%" + inputValue.value.toLowerCase().trim() + "%' or lower(project_desc) like '%" + inputValue.value.toLowerCase().trim()+ "%' or lower(comment) like '%" + inputValue.value.toLowerCase().trim()+ "%'or lower(project_lead) like '%" + inputValue.value.toLowerCase().trim()+ "%'or lower(project_manager) like '%" + inputValue.value.toLowerCase().trim()+ "%' or find_in_set('"+inputValue.value.toLowerCase().trim()+"', lower(tagname)))";

            f_queryMysql("do-ndp-list","*",whereClause,'0,100' );
            // console.log(whereClause)
            
      }

            // calcDashBoardMetrics(dataSource.value);
            // handleChange();

    };


    const getConfigList=()=>{

      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("varlist", 'category seq code codename');
      params.append("filter", encodeURIComponent('active="Y" and rmfl="N"'));
      params.append("byvar", encodeURIComponent('category seq code codename'));
      params.append("keytablename", '_xd_nmpa-nda-codelist');
      params.append("action", 'read');

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      axios({
        method: "post",
        url: "util/general-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // console.log(response);
          // this.errorMessage = "";
          // this.successMessage = "";
          // this.inputValue = "";

          dataSourceOrigin.value = response.data.records;

          dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));
         
         //retrieve the code list from the dictionary
          dataSource.value.forEach(function (record) {
              // console.log(record['category'])
              if(record['category']=='FUNCTION_NAME'){
                ndpfunctionlist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='TIER'){
                ndptierlist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='STATUS'){
                ndpstatuslist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='BUSINESS_UNIT'){
                ndpbusinessunitlist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='SUB_FUNCTION_NAME'){
                ndpsubfunctionlist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='GDO_CATEGORY'){
                ndpgdocategorylist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='IMPACT_LEVEL'){
                ndpimpactlevellist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='NDP_TYPE'){
                ndpdefinitiontypelist.value.push({value: record['code'], text: record['codename']})
              }
              else if(record['category']=='TAGNAME'){
                // ndptagnamelist.value.push({value: record['code'], text: record['codename']})
              }

         });

          console.log("Debug: "+ndpdefinitiontypelist.value);
          

        })
        .catch((error) => {
          console.log("login error");
          // this.$router.push({ path: this.$router.currentRoute.value.fullPath || "/login" });
          // var redirect = decodeURIComponent(
          //   this.$route.query.redirect || process.env.VUE_APP_baseURL
          // );
          //console.log(this.$router.currentRoute.value.fullPath);
          // this.$router.push({ path: redirect });   
          alert(error.message);
          return;
        });

    };

    const getUserRole=()=>{

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
    //   params.append("keytablename", 'study_info');

      //retrieve user role information, determin if admin;
      axios
        .post(
          `util/nmpa-dict-user-info.php`,
          params
        )
        .then((response) => {
            isAdmin.value=response.data.alevel==='1'? true:false;
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
    }

  const f_queryMysql=(tbname, varlist, filter, limit, byvar)=>{

      loadText.value="Searching in database...";
      tagNameSwitchCheck.value=false;
      isLoading.value=true;
      varlist=varlist!=null?varlist:"*";
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("varlist", varlist);

      if(limit !=null){
        params.append("limit", limit);
      }
      if(filter !=null){
        params.append("filter", encodeURIComponent(filter));
      }
      if(byvar !=null){
        params.append("byvar", encodeURIComponent(byvar));
      }
      params.append("keytablename", tbname);
      params.append("action", 'read');
      params.append("debug", 'Y');

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      axios({
        method: "post",
        url: "ndp/ndp-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          console.log(response);
          dataSourceOrigin.value = response.data.records;
          dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));
          isLoading.value=false;
          loadText.value="Loading...";
        //   message.success(response.data.records.length);
        //   ndptagnamelist.value=getTagNameList("tagname");

        calcDashBoardMetrics(dataSource.value)

        })
        .catch((error) => {
          console.log(error);
          alert(error.message);
          isLoading.value=false;
          loadText.value="Loading...";
          return;
        });

    };

    const getNDPList=()=>{

      isLoading.value=true;
      tagNameSwitchCheck.value=false;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      // params.append("varlist", 'cat seq code codename');
      // params.append("filter", encodeURIComponent('domain="NDP"'));
      // params.append("byvar", encodeURIComponent('cat seq code codename'));
      params.append("keytablename", '_xd_nmpa-study-info');
      params.append("action", 'read');

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      axios({
        method: "post",
        url: "util/general-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // console.log(response);
          dataSourceOrigin.value = response.data.records;
          dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));
          dataSourceFilter.value=dataSource.value;
        //   calcDashBoardMetrics(dataSource.value);

          //update the tagname list

          // console.log(uniqueValueListSelected("tagname"));
          // var tagNameList=uniqueValueListSelected("tagname")

          // tagNameList.forEach((item)=>{
          //     console.log(item)
          //     if(item.toString()!=""){
          //       item.toString().split(/\s*,\s*/).forEach((tag)=>{
          //         if (ndptagnamelist.value.indexOf(tag) === -1) {
          //             ndptagnamelist.value.push(tag);
          //         }
          //       })
          //     }              
          // });

        //   ndptagnamelist.value=getTagNameList("tagname");
           isLoading.value=false;

          // console.log(ndptagnamelist.value)

        })
        .catch((error) => {
          isLoading.value=false;
          console.log(error);
          alert(error.message);
          return;
        });

    };

  const getTagNameList=(keyName)=>{
          var tagNameList=uniqueValueListSelected(keyName);
          var strOutputArray=[];
          tagNameList.forEach((item)=>{
              if(item.toString()!=""){
                item.toString().split(/\s*,\s*/).forEach((tag)=>{
                  if (strOutputArray.indexOf(tag) === -1) {
                      strOutputArray.push(tag);
                  }
                })
              }              
          });
          return strOutputArray;
  };

   const uniqueCapitalLetterListSelected2=(keyname)=>{
        //  var output = [];
         var keys   = [];

        //  console.log(keyname);

         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };


    const handleTagNameSwitchCheck=()=>{
        // console.log(tagNameSwitchCheck.value)
        if(tagNameSwitchCheck.value==true){
          dataSource.value=dataSourceOrigin.value.filter(
          (item) => item.tagname!=null? item.tagname.toString().split(/\s*,\s*/).indexOf("BP22") !=-1:""
          );
        }
        else{
          dataSource.value=dataSourceOrigin.value
        }

        calcDashBoardMetrics(dataSource.value);

    };

    const handleChange = (pagination, filters, sorter, extra) => {

      console.log("Various parameters", pagination, filters, sorter);
      filteredInfo.value = filters;
      sortedInfo.value = sorter;
      currentPage.value = pagination.current;
      currentPageSize.value = pagination.pageSize;

      // console.log(filters);

      Object.assign(dataSourceFilter.value,extra.currentDataSource);
      // totalResources.value.forEach((item)=>{
      //   item.value=0;
      // });
      


      // extra.currentDataSource.forEach((item)=>{
      //     // console.log(item);
      //     item.fte_total=calcSummary([item.fte_bex,item.fte_cddra,item.fte_cdsa,item.fte_dm,item.fte_sp]).toFixed(2);
      //     item.fsp_total=calcSummary([item.fsp_bex,item.fsp_cddra,item.fsp_cdsa,item.fsp_dm,item.fsp_sp]).toFixed(2);
      //     item.totalresource=calcSummary([item.fte_total,item.fsp_total]).toFixed(2);
      //     // console.log(item);

      //     totalResources.totalBexFTE =  calcSummary([ totalResources.totalBexFTE,item.fte_bex]);
      //      totalResources.totalBexFSP = calcSummary([ totalResources.totalBexFSP,item.fsp_bex]);
      //     totalResources.totalCDDRAFTE = calcSummary([totalResources.totalCDDRAFTE,item.fte_cddra]);
      //     totalResources.totalCDDRAFSP = calcSummary([totalResources.totalCDDRAFSP, item.fsp_cddra]);
      //     totalResources.totalCDSAFTE = calcSummary([totalResources.totalCDSAFTE,item.fte_cdsa]);
      //     totalResources.totalCDSAFSP = calcSummary([totalResources.totalCDSAFSP,item.fsp_cdsa]);
      //     totalResources.totalDMFTE = calcSummary([totalResources.totalDMFTE,item.fte_dm]);
      //     totalResources.totalDMFSP = calcSummary([totalResources.totalDMFSP,item.fsp_dm]);
      //     totalResources.totalSPFTE = calcSummary([totalResources.totalSPFTE,item.fte_sp]);
      //     totalResources.totalSPFSP = calcSummary([totalResources.totalSPFSP,item.fsp_sp]);

      //     totalResources.totalFTE=calcSummary([totalResources.totalBexFTE,
      //     totalResources.totalCDDRAFTE,
      //     totalResources.totalCDSAFTE,
      //     totalResources.totalDMFTE,
      //     totalResources.totalSPFTE]);
      //     totalResources.totalFSP=calcSummary([totalResources.totalBexFSP,
      //     totalResources.totalCDDRAFSP,
      //     totalResources.totalCDSAFSP,
      //     totalResources.totalDMFSP,
      //     totalResources.totalSPFSP]);

      //     totalResources.totalResource=calcSummary([totalResources.totalFTE,totalResources.totalFSP]);
      // });

      // console.log(totalResources);

      calcDashBoardMetrics(extra.currentDataSource);

    };

    const dropdownValue = "";

    const newVisible = ref(false);
    const editVisibleBasic = ref(false);
    const editVisibleBudget = ref(false);
    const translationFormVisible = ref(false);
    const isLoading = ref(false);
    const isLoadingTranslation = ref(false);
    const Loading = ref(false);
    const isGlobalTerms = ref(true);
    const currentTableName = ref("nds-list-tier");

    const currentTerm = ref("");
    const originalTerm = ref("");
    const originalStatus = ref("");
    const originalComment = ref("");

    //Form setup;
    const formRef = ref();
    const formState = reactive({
      // project_name: "",
      // project_desc:"",
      // tier: "",
      // horizon_wpid: "",
      // project_stdtc: "",
      // project_endtc: "",
      // comment: "",
      // project_lead: "",
      // project_manager: "",
      // auditlog: "",
      // status: "",
      // optic:""
    });

    const formNew = reactive({
      function_name:"",
      business_unit: "",
      project_name: "",
      project_desc:"",
      tier: "",
      horizon_wpid: "",
      project_stdtc: "",
      project_endtc: "",
      comment: "",
      project_lead: localStorage.getItem("username"),
      project_lead_email: localStorage.getItem("email"),
      project_manager: "",
      auditlog: "",
      status: "",
      progress:"",
      version: 1.0,
      impact_level:null,
      fte_bex:0.00,
      fte_cddra:0.00,
      fte_cdsa:0.00,
      fte_dm:0.00,
      fte_sp:0.00,
      fsp_bex:0.00,
      fsp_cddra:0.00,
      fsp_cdsa:0.00,
      fsp_dm:0.00,
      fsp_sp:0.00,
      fte_total:0.00,
      fsp_total:0.00,

      resource_saving:0.00,
      budget_saving:0.00,

      budget_comment:"",
      tagname:"",

      optic:"N"
    });

     const rulesRef = reactive({
      project_name: [{
        required: true,
        message: 'NDP name',
      }, {
        min: 3,
        max: 100,
        message: 'Length should be 3 to 100',
        trigger: 'blur',
      }],

      project_desc: [{
        required: true,
        message: 'NDP description',
      },{
        min: 5,
        max: 1000,
        message: 'Length should be 5 to 1000',
        trigger: 'blur',
      }],

      function_name: [{
        required: true,
        message: 'DO line function that supports',
      }],

      business_unit: [{
        required: true,
        message: 'GDO category',
      }],

      impact_level: [{
        required: true,
        message: 'Impact level',
      }],

      project_type: [{
        required: true,
        message: 'NDP definition type',
      }],

      project_lead: [{
        required: true,
        message: 'NDP initiator',
      }],

      project_lead_email: [{
        required: true,
        message: 'Email',
      }],

      tier: [{
        required: true,
        message: 'NDP category',
      }],

      status: [{
        required: true,
        message: 'NDP status',
      }],

      project_stdtc: [{
        required: true,
        message: 'Planned start date',
      }],

      project_endtc: [{
        required: true,
        message: 'Planned end date',
      }],
    });   

    const showDrawerNew = () => {

      // console.log(userProtocolID.value);      
      // editRow.value = [];
      // formState.protocolid=userProtocolID.value;
      // formState.studyid=userStudyID.value;
      // formState.xlcat=currentTableName.value.split('-')[1].toUpperCase();
      // formState.xlscat=currentTableName.value.split('-')[2].toUpperCase();
      // formState.xltestcd="";
      // formState.xltestcd="";
      // formState.xlmodify="";
      // formState.xlcomment="";
      editVisibleBasic.value = true;
      
    };
    const showDrawerEdit = (record) => {
      // editVisibleBasic.value = true;
        // editVisibleBasic.value = true; 
        // strNewOrEdit.value='Edit';
        // this.selectCurrentItem(record); 
        // console.log(moment(record.project_stdtc));
        // ndp_stdtc.value=moment(record.project_stdtc);
    };

    const cellEdit = (column_name, key) => {
      // console.log("this is for a test");
      editableData[key] = cloneDeep(
        dataSource.value.filter((item) => key === item.record_id)[0]
      );
      // editableData[key] = dataSource[key];
      // console.log(dataSource[key]);
      originalTerm.value = editableData[key][column_name];
    };

    const cellSave = (column_name, key) => {
      Object.assign(
        dataSource.value.filter((item) => key === item.record_id)[0],
        editableData[key]
      );

      // dataSource[key] = editableData[key];

      currentTerm.value=dataSource.value.filter((item) => key === item.record_id)[0][column_name];
      // console.log(originalTerm.value);
      // console.log(currentTerm.value);

      if (originalTerm.value != currentTerm.value
        // dataSourceOrigin.value[key].xlmodify != strCurrentTerm.value
      ) {
        var params = new URLSearchParams(editableData[key]);
        params.append("action", "cell-update");
        params.append("key_name", 'record_id');
        params.append("key_value", key);
        params.append("column_name", column_name);
        params.append("column_value", currentTerm.value);

        params.append("keytablename", 'do-ndp-list');

        params.append("debug", 'Y');

        // params.append("original-term", originalTerm.value);
        // params.append("modified-term", currentTerm.value);
        params.append("userid",localStorage.getItem("userid"));
        // params.append(
        //   "jwt-token",
        //   encodeURIComponent(localStorage.getItem("accessToken"))
        // );
        axios
          .post(`ndp/ndp-dict-update-cell.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              // dataSource.value.filter((item) => key === item.uid)[0].xlauditlog=response.data.auditlog;
              // dataSource.value.filter((item) => key === item.uid)[0].xlstat='ACTIVE';

              //additionally added for the clone copy operation due to a clone copy used as datasource for more efficiency;
              Object.assign(
                dataSourceOrigin.value.filter((item) => key === item.record_id)[0],
                editableData[key]
              );
        
            }
          });
      }
      delete editableData[key];
    };

    const onCloseNew = () => {
      newVisible.value = false;
      editVisibleBasic.value = false;
      editVisibleBudget.value=false;
      translationFormVisible.value = false;
      // formState.value = [];
    };
    const onCloseEdit = () => {
      newVisible.value = false;
      editVisibleBasic.value = false;
      editVisibleBudget.value=false;
      translationFormVisible.value = false;
      formState.value = [];
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const onCloseTranslationForm = () => {
      translationFormVisible.value = false;
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const incrementNumber = () => {
      let i = 0;
      return (index) => {
        if (pagination.current === 1) {
          return index++;
        }
        return (i = i + 1);
      };
    };

    const fromCurrentIndex = incrementNumber();

    const pagination = {
      pageSize: 50, // 默认每页显示数量
      position: "top",
      showSizeChanger: true, // 显示可改变每页数量
      pageSizeOptions: ["5", "10", "20", "50", "100"], // 每页数量选项
      showTotal: (total) => lang.value==='cn'?'总共' + ` ${total} 条` + pageTotalLabel.value: 'Total' + ` ${total} ` + pageTotalLabel.value, // 显示总数
      showSizeChange: (current, pageSize) => (this.pageSize = pageSize), // 改变每页数量时更新显示
    };

    const state = reactive({
      rootSubmenuKeys: [
        "ndp-list-tier",
        "ndp-list-function_name",      
         "ndp-list-status",      
          "ndp-list-tagname",      
           "ndp-list-project_type",      
      ],

      selectedRowKeys: [],
      selectedRows: [],
      // selectedRowList: [],

      openKeys: [], //openKeys: ["study-variable-label"],
      groupData: [],
      value: [],
      fetching: false,
      pagination,
      selectedKeys: [],
      // filteredInfo:[],
      options: [],
      searchText: "",
      destroy: true,
      searchedColumn: "",
    });

    const hasSelected = computed(() => state.selectedRowKeys.length > 0);

    const onSelectChange = (selectedRowKeys,selectedRows) => {
      // console.log('selectedRowKeys changed: ', selectedRowKeys);

      state.selectedRows=selectedRows;

      state.selectedRowKeys = selectedRowKeys;

      var selectedTerms='';

      // console.log(state.selectedRows);
      for (var item in state.selectedRows){
        selectedTerms+=state.selectedRows[item].record_id + ""; 
      }

      // console.log(selectedTerms);
      
      // selectedRowKeyList.value=selectedRowKeys;
        // console.log(state.selectedRowKeys);
        
        if (state.selectedRowKeys.length>0){
                // console.log(selectedTermsLength);    
            if (lang.value==='cn'){
              successMessage.value="已选定 " + state.selectedRowKeys.length + " 行";
            }
            else{
              successMessage.value=state.selectedRowKeys.length + " rows selected.";
            }
          // successMessage.value=state.selectedRowKeys.length + " rows selected.";
          // successMessage.value=state.selectedRowKeys;
          // successMessage.value=state.selectedRowKeys.length + " rows selected. \n\n" + state.selectedRowKeys
        }
        else{
          successMessage.value="";
          errorMessage.value="";
          // state.selectedRowKeys.value="";
        }

        // successMessage.value=state.selectedRowKeys;
    };

    const current1 = ref(1);
    const current2 = ref(2);
    const current = ref(1);
    const menuKey = ref('');
    const pageSizeRef = ref(10);
    const pageSizeOptions = ref(["5", "10", "20", "50", "100", "200"]);
    const total = ref(50);

    //for the in-cell edit ;
    const dataSource = ref([]);
    const dataSourceOrigin = ref([]);
    const dataSourceFilter = ref([]);
    const dataSourceStudy = ref([]);
    const count = computed(() => this.dataSource.length + 1);
    // const editableData = reactive({});

    const onShowSizeChange = (current, pageSize) => {
      // console.log(pageSize);
      pageSizeRef.value = pageSize;
    };

    const onChange = (pageNumber) => {
      console.log("Page: ", pageNumber);
    };

    const onOpenChange = (openKeys) => {
      const latestOpenKey = openKeys.find(
        (key) => state.openKeys.indexOf(key) === -1
      );

      if (state.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
        state.openKeys = openKeys;
      } else {
        state.openKeys = latestOpenKey ? [latestOpenKey] : [];
      }
    };

    const handleSearch = (selectedKeys, confirm, dataIndex) => {
      confirm();
      state.searchText = selectedKeys[0];
      state.searchedColumn = dataIndex;
    };

    const handleReset = clearFilters => {
      clearFilters();
      state.searchText = '';
    };

    const calcSummary =(numbers)=>{
      // return parseFloat(a)+parseFloat(b)
      	var total = 0;
        for (var i = 0; i < numbers.length; i++) {
          total += parseFloat(numbers[i]);
        }
        return total;
    };
    const calcMultiply =(numbers)=>{
      // return parseFloat(a)+parseFloat(b)
      	var total = 1;
        for (var i = 0; i < numbers.length; i++) {
          total = (total*parseFloat(numbers[i]));
        }
        return total;
    };

    const totalResources=reactive({
      totalBexFTE: 0,
      totalBexFSP: 0,
      totalBex:0,

      totalCDDRAFTE:0,
      totalCDDRAFSP:0,
      totalCDDRA:0,

      totalCDSAFTE:0,
      totalCDSAFSP:0,
      totalCDSA:0,

      totalDMFTE: 0,
      totalDMFSP: 0,
      totalDM:0,

      totalSPFTE: 0,
      totalSPFSP: 0,
      totalSP:0,

      totalFTE: 0,
      totalFSP: 0,

      totalResource: 0
    });

    // const totalResources = computed(() => {
    //   let totalBexFTE = 0;
    //   let totalBexFSP = 0;
    //   let totalCDDRAFTE = 0;
    //   let totalCDDRAFSP = 0;
    //   let totalCDSAFTE = 0;
    //   let totalCDSAFSP = 0;
    //   let totalDMFTE = 0;
    //   let totalDMFSP = 0;
    //   let totalSPFTE = 0;
    //   let totalSPFSP = 0;

    //   let totalFTE = 0;
    //   let totalFSP = 0;
    //   let totalResource = 0;

    //   dataSourceFilter.value.forEach(({
    //     fte_bex, fsp_bex,
    //     fte_cddra, fsp_cddra,
    //     fte_cdsa, fsp_cdsa,
    //     fte_dm, fsp_dm,
    //     fte_sp, fsp_sp
    //   }) => {
    //     // console.log(fte_bex);
    //     totalBexFTE =  calcSummary([totalBexFTE,fte_bex]);
    //     totalBexFSP = calcSummary([totalBexFSP,fsp_bex]);
    //     totalCDDRAFTE = calcSummary([totalCDDRAFTE,fte_cddra]);
    //     totalCDDRAFSP = calcSummary([totalCDDRAFSP, fsp_cddra]);
    //     totalCDSAFTE = calcSummary([totalCDSAFTE,fte_cdsa]);
    //     totalCDSAFSP = calcSummary([totalCDSAFSP,fsp_cdsa]);
    //     totalDMFTE = calcSummary([totalDMFTE,fte_dm]);
    //     totalDMFSP = calcSummary([totalDMFSP,fsp_dm]);
    //     totalSPFTE = calcSummary([totalSPFTE,fte_sp]);
    //     totalSPFSP = calcSummary([totalSPFSP,fsp_sp]);

    //     totalFTE=calcSummary([totalBexFTE,totalCDDRAFTE,totalCDSAFTE,totalDMFTE,totalSPFTE]);
    //     totalFSP=calcSummary([totalBexFSP,totalCDDRAFSP,totalCDSAFSP,totalDMFSP,totalSPFSP]);

    //     totalResource=calcSummary([totalFTE,totalFSP]);

    //     // console.log(totalBexFTE,totalBexFSP);
        
    //   });
    //   return {
    //     totalBexFTE,totalBexFSP,
    //     totalCDDRAFTE,totalCDDRAFSP,
    //     totalCDSAFTE,totalCDSAFSP,
    //     totalDMFTE,totalDMFSP,
    //     totalSPFTE,totalSPFSP,
    //     totalFTE,totalFSP,
    //     totalResource
    //   };
    // });

    const loadText=ref("Loading...");
    const dueDate =ref(0);
    const collapsed=ref(true);
    const reloadStatus=ref(false);
    return {
      ...toRefs(state),
      ndpgdocategorylist,
      ndpimpactlevellist,
      ndpdefinitiontypelist,
      loadText,
      dueDate,
      reloadStatus,
      calcDashBoardMetrics,
      blSearchInCacheOrBackend,
      SearchInCacheOrBackend:ref("Backend Search"),
      totalResources,
      ndp_stdtc: ref(),
      ndp_endtc: ref(),
      totalFTEColor: ref("blue"),
      totalFSPColor: ref("green"),
      totalColor: ref("red"),
      dayjs,
      calcSummary,
      calcMultiply,
      resetForm,
      clearForm,
      pieRadius,
      strNewOrEdit,
      warningValue,
      valueFTEType,
      sortArrayByKey,
      globalFunctionList,
      grpByTierResults,
      grpByFunctionResults,
      grpByStatusResults,
      grpByImpactResults,
      sumByFunctionGroup,
      tagNameSwitchCheck,
      activeKey: ref('1'),
      initChart,
      myDashBoardChart,
      refreshChart,
      totalTier0NDPs,
      totalTier1NDPs,
      totalTier2NDPs,
      totalTier3NDPs,
      totalActiveNDPs,
      totalCompletedNDPs,
      totalOnHoldNDPs,
      totalTerminatedNDPs,
      totalOtherNDPs,
      totalNDPs,
      totalFTE,
      totalInternalFTE,
      totalExternalFTE,
      formNew,
      pageTotalLabel,
      handleSearchInputChange,
      handleSearchInput2,
      getUniqueArray,
      reloadEcharts,
      uniqueValueListSelected,
      uniqueCapitalLetterListSelected,
      uniqueCapitalLetterListSelected2,
      getTagNameList,
      inputValue,
      onChangePickDate,
      ndptierlist,
      ndpfunctionlist,
      ndpstatuslist,
      ndptagnamelist,
      ndpsubfunctionlist,
      ndpbusinessunitlist,
      menuKey,
      functionChecklist,
      statusChecklist,
      statusList,
      userconfig,
      radioStyle,
      isAdmin,
      getConfigList,
      getUserRole,
      getNDPList,
      f_queryMysql,
      onSelectChange,
      hasSelected,
      columnTitle,
      selectedRowKeyList,
      handleSearch,
      handleReset,
      searchText: '',
      searchInput,
      searchedColumn: '',
      // clickedItem,
      strUserName,
      strUserID,
      originalTerm,
      originalStatus,
      originalComment,
      currentTerm,
      isLogin,
      onOpenChange,
      pageSizeOptions,
      current,
      formState,
      formRef,
      rulesRef,
      dropdownValue,
      editableData,
      cellEdit,
      cellSave,
      currentPage,
      currentPageSize,
      columnsList,
      columnsFTE,
      dataSource,
      dataSourceFilter,
      dataSourceOrigin,
      dataSourceStudy,
      Loading,
      lang,
      handleChange,
      handleTagNameSwitchCheck,
      headers: {
        authorization: "authorization-text",
      },
      // fileList,
      isLoading,
      isLoadingTranslation,
      isGlobalTerms,
      currentTableName,
      pagination,
      pageSize: pageSizeRef,
      total,
      onShowSizeChange,
      current1,
      current2,
      onChange,
      // onCellEdit,
      // onCellSave,
      onCloseNew,
      onCloseEdit,
      // onSubmit,
      showDrawerNew,
      showDrawerEdit,
      successMessage,
      errorMessage,
      // edit,
      // options,
      // save,
      state,
      count,
      newVisible,
      editVisibleBasic,
      editVisibleBudget,
      collapsed,
      selectedKeys: ref(["1"]),
    };
  },

  mounted: function () {

    this.initChart();
    this.strUserName=localStorage.getItem("username");
    localStorage.setItem("currentHREF",window.location.href);
    localStorage.setItem("currentAPPName","DOS-DNGB");

    this.getUserRole();
    this.getConfigList();
    this.getNDPList();
    this.columnsList=this.lang==='cn'?this.userconfig.columnStudyInfoCN:this.userconfig.columnStudyInfoCN;
    // this.columnsFTE=this.lang==='cn'?this.userconfig.columnStudyTaskCN:this.userconfig.columnStudyTaskCN;
    this.strUserID=localStorage.getItem('userid').toUpperCase();

    var loginDateTime = new Date(parseInt(localStorage.getItem('loginDateTime'))).getTime();
    // this.dueDate=Date.now()+ 1000 * 60 * 60 * 24 * 2 ;
    this.dueDate=loginDateTime+ 1000 * 60 * 60 * 12;

    // console.log(this.totalResources);

    // const tds = document.getElementsByTagName("td");
    // console.log(tds);
    // tds.forEach ((td) => {
    //   console.log(td.innerHTML);
    //   if (td.innerHTML == '0.00') {
    //   td.classList.add("valuestyle");
    //   console.log("ok")
    //   }
    // })

          //   this.columnsList.splice(3,0,{
          //   title: "ND Type",
          //   dataIndex: "project_type",
          //   width: 350,
          //   key: "project_type",
          //   // ellipsis: true,
          //   slots: {
          //       customRender: "project_type",
          //   },
          //  filters:this.ndpdefinitiontypelist,
          //   onFilter: (value, record) => {
          //       record.project_type=record.project_type||"";
          //       return record.project_type.toUpperCase().includes(value);
          //   },
            
          //   sorter: (a, b) => a.project_type.length - b.project_type.length,
          //   sortDirections: ['descend', 'ascend'],
          // });


  },
  // watch:{
  // 	dataSource:function () {
  //     console.log(this.dataSource.length);
  //   },

  //   tagNameSwitchCheck: function(){
  //     console.log(this.tagNameSwitchCheck);
  //   },
  // },

 computed: {
   uniqueCapitalLetterList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },

   uniqueValueList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname];

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },
   uniqueStudyList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },


},

  watch:{
      columnsList:function(){
        console.log(this.columnsList);
      }

  },

  methods: {

    bodyClick() {
      this.menuVisible = false;
      document.body.removeEventListener("click", this.bodyClick);
      },    

    logout() {
      if (localStorage.getItem("accessToken")) {
        localStorage.removeItem("accessToken");
        this.$router.go();
        // this.$router.push({ path: process.env.VUE_APP_baseURL+"login"});
      }
    },


    filterNDPByFTE(cond){

        // this.dataSource = this.dataSourceOrigin   
        Object.assign(this.dataSource,this.dataSourceOrigin )
        this.calcDashBoardMetrics(this.dataSource)

        if(cond!=null){
            // console.log(this.dataSource);
          if(cond=='>0'){
            this.dataSource = this.dataSource.filter((item) =>  item.totalresource>0   
            )
          }
          else if (cond=='=0'){this.dataSource = this.dataSource.filter((item) =>  item.totalresource==0   
            )

          }

          else if (cond=='>=4'){this.dataSource = this.dataSource.filter((item) =>  item.totalresource>=4   
            )

          }
          else if (cond=='<4'){this.dataSource = this.dataSource.filter((item) =>  item.totalresource>0  && item.totalresource<4
            )
          }

          this.calcDashBoardMetrics(this.dataSource)
            // console.log(this.dataSource)

        }
      
    },

    onFinish() {
      alert("Token expired, please log in again！");
      if (localStorage.getItem("accessToken")) {
        localStorage.removeItem("accessToken");
        this.$router.go();
        // this.$router.push({ path: process.env.VUE_APP_baseURL +"login" });
      }
    },

    resetFields() {
      // console.log(formRef.value);
      // console.log(this.$refs.formRef);
      // console.log(this.$refs[project_name]);
      // this.$refs.formRef.project_name="";
      // console.log(this.formState);
      // console.log(this.formNew);
      Object.assign( this.formState,this.formNew);
      // console.log(this.formState);
      // console.log(this.formNew);
    },


    backupSelectedItemsAsXLS:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            // this.isloading=true;

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("Please select the NDPs to be exported!");
              return;
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName="DNGB_NDP_List_" + run_dt+ ".xlsx";

            // let selectedItems_full = [
            //     ['record_id', 'TAGNAME', 'TIER', 'BUSINESS_UNIT', 'FUNCTION_NAME', 'GDD_CATEGORY', 'PROJECT_NAME', 'PROJECT_DESC', 'PROJECT_LEAD', 'PROJECT_MANAGER', 'PROJECT_STDTC', 'PROJECT_ENDTC', 'PROJECT_TYPE', 'IMPACT_LEVEL', 'STATUS', 'STAGE', 'MOUSERID', 'MODTC', 'PROGRESS', 'BUDGET_YEAR', 'FTE_BEX', 'FTE_CDDRA', 'FTE_CDSA', 'FTE_DM', 'FTE_SP', 'FTE_DO', 'FSP_BEX', 'FSP_CDDRA', 'FSP_CDSA', 'FSP_DM', 'FSP_SP', 'FSP_DO', 'FTE_TOTAL', 'FSP_TOTAL', 'TOTALRESOURCE', 'RESOURCE_SAVING', 'BUDGET_SAVING', 'HORIZON_WPID', 'BUDGET_PLAN', 'BUDGET_SPENT', 'COMMENT', 'BUDGET_COMMENT']
            // ] // 表格表头

            // let selectedItems_general = [
            //     ['record_id', 'TIER', 'BUSINESS_UNIT', 'FUNCTION_NAME', 'GDD_CATEGORY', 'PROJECT_NAME', 'PROJECT_DESC', 'PROJECT_LEAD', 'PROJECT_MANAGER', 'PROJECT_STDTC', 'PROJECT_ENDTC', 'PROJECT_TYPE', 'IMPACT_LEVEL', 'STATUS',  'PROGRESS', 'BUDGET_YEAR', 'FTE_BEX', 'FTE_CDDRA', 'FTE_CDSA', 'FTE_DM', 'FTE_SP', 'FTE_DO', 'FSP_BEX', 'FSP_CDDRA', 'FSP_CDSA', 'FSP_DM', 'FSP_SP', 'FSP_DO', 'FTE_TOTAL', 'FSP_TOTAL', 'TOTALRESOURCE', 'HORIZON_WPID', 'COMMENT', 'TAGNAME']
            // ] // 表格表头

            let selectedItems_resources = [
                ['record_id', 'TAGNAME', 'TIER', 
                'BUSINESS_UNIT', 'FUNCTION_NAME', 'GDD_CATEGORY', 
                'PROJECT_NAME', 'PROJECT_DESC', 'PROJECT_LEAD', 'PROJECT_MANAGER', 
                'STATUS','PROJECT_STDTC', 'PROJECT_ENDTC', 
                'PROJECT_TYPE', 'IMPACT_LEVEL',
                'FTE_BEX', 'FTE_CDDRA', 'FTE_CDSA', 'FTE_DM', 'FTE_SP', 'FTE_DO', 
                'FSP_BEX', 'FSP_CDDRA', 'FSP_CDSA', 'FSP_DM', 'FSP_SP', 'FSP_DO', 
                'FTE_TOTAL', 'FSP_TOTAL', 'TOTALRESOURCE', 
                'HORIZON_WPID', 'COMMENT', 'BUDGET_COMMENT']
            ] // 表格表头
            // JSON.parse(JSON.stringify(this.state.selectedRowList)).forEach (item => {
            //     let rowData = []
            //     rowData = [
            //         item.xltest,
            //         item.xlmodify,
            //     ]
            //     tableData.push(rowData)
            // })

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            const arrayUniqueByKey=this.getUniqueArray(this.dataSourceFilter,['project_name', 'project_desc']);

            // this.currentTableName = localStorage.getItem("keytablename");
            // var strRootList = new Array();
            // strRootList = this.currentTableName.split("-");

            arrayUniqueByKey.forEach (item => {
                let rowData = []
                rowData = [
                    item.record_id,item.tagname,item.tier,
                    item.business_unit,item.function_name,item.gdd_category,
                    item.project_name,item.project_desc,item.project_lead,item.project_manager,
                    item.status,item.project_stdtc,item.project_endtc,
                    item.project_type,item.impact_level,
                    item.fte_bex,item.fte_cddra,item.fte_cdsa,item.fte_dm,item.fte_sp,item.fte_do,
                    item.fsp_bex,item.fsp_cddra,item.fsp_cdsa,item.fsp_dm,item.fsp_sp,item.fsp_do,
                    item.fte_total,item.fsp_total,item.totalresource,
                    item.horizon_wpid,
                    item.comment,item.budget_comment
                ]
                
                    if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.record_id)>0){
                    // selectedItems_full.push(rowData)
                    // selectedItems_general.push(rowData)
                    selectedItems_resources.push(rowData)
                }

            })

            // console.log(this.state.selectedRowKeys)
            // console.log(selectedItems)


            // let ws_full = XLSX.utils.aoa_to_sheet(selectedItems_full);
            // let ws_general = XLSX.utils.aoa_to_sheet(selectedItems_general);
            let ws_resources = XLSX2.utils.aoa_to_sheet(selectedItems_resources);

            // console.log(this.dataSource);

            // ws_full["!cols"]=[{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:300},{wpx:300},{wpx:300},{wpx:100},{wpx:300}];

            // ws_general["!cols"]=[{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:100},{wpx:300},{wpx:300},{wpx:300},{wpx:100},{wpx:300}];

            ws_resources["!cols"]=[{wpx:40},{wpx:70},{wpx:60},{wpx:100},{wpx:100},{wpx:100},
            {wpx:300},{wpx:500},{wpx:120},{wpx:120},{wpx:100},{wpx:80},{wpx:80},{wpx:100},{wpx:100}];

            var s = ws_resources['!ref'];
            /* new format */
            var fmt = "0.00";
            /* change cell format of range B2:D4 */
            var range = { s: {r:1, c:15}, e: {r:selectedItems_resources.length-1, c:29} };

            ws_resources['!autofilter']={ref:"A1:AE1"};
            // console.log(range);

            for(var R = range.s.r; R <= range.e.r; ++R) {
              for(var C = range.s.c; C <= range.e.c; ++C) {
                var cell = ws_resources[XLSX2.utils.encode_cell({r:R,c:C})];
                cell.t = 'n';
                cell.w = undefined;
                cell.z = fmt;                
              }
            }

            // ws_resources[20].s = { // styling for all cells
            //     font: {
            //         name: "arial"
            //     },
            //     alignment: {
            //         vertical: "center",
            //         horizontal: "center",
            //         wrapText: '1', // any truthy value here
            //     },
            //     border: {
            //         right: {
            //             style: "thin",
            //             color: "000000"
            //         },
            //         left: {
            //             style: "thin",
            //             color: "000000"
            //         },
            //     }
            // };

            // for (i in ws_resources) {
            //     if (typeof(ws_resources[i]) != "object") continue;
            //     let cell = XLSX2.utils.decode_cell(i);

            //     ws_resources[i].s = { // styling for all cells
            //         font: {
            //             name: "arial"
            //         },
            //         alignment: {
            //             vertical: "center",
            //             horizontal: "center",
            //             wrapText: '1', // any truthy value here
            //         },
            //         border: {
            //             right: {
            //                 style: "thin",
            //                 color: "000000"
            //             },
            //             left: {
            //                 style: "thin",
            //                 color: "000000"
            //             },
            //         }
            //     };

            //     if (cell.c == 0) { // first column
            //         ws_resources[i].s.numFmt = "DD/MM/YYYY HH:MM"; // for dates
            //         ws_resources[i].z = "DD/MM/YYYY HH:MM";
            //     } else { 
            //         ws_resources[i].s.numFmt = "00.00"; // other numbers
            //     }

            //     if (cell.r == 0 ) { // first row
            //         ws_resources[i].s.border.bottom = { // bottom border
            //             style: "thin",
            //             color: "000000"
            //         };
            //     }

            //     if (cell.r % 2) { // every other row
            //         ws_resources[i].s.fill = { // background color
            //             patternType: "solid",
            //             fgColor: { rgb: "b2b2b2" },
            //             bgColor: { rgb: "b2b2b2" } 
            //         };
            //     }
            // }

            // var s = ws_resources['!ref'];
            // var rows = s.substr(s.length - 1, 1);
            // var columns = ['project_name', 'project_desc'];
            // for (var j = 0; j < columns.length; j++) {
            //     for (var i = 1; i <= rows; i++) {
            //         if (i == 1) {
            //             ws_resources[columns[j] + i].s = { //样式  
            //                 font: {
            //                     bold: true,
            //                     italic: false,
            //                     underline: false
            //                 },
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: false
            //                 }
            //             };
            //         }
            //         else {
            //             ws_full[columns[j] + i].s = { //样式  
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: true
            //                 }
            //             };
            //         }
            //     }
            // }
            
            let wb = XLSX2.utils.book_new()
            // XLSX.utils.book_append_sheet(wb, ws_full, 'NDP LIST') // 工作簿名称
            // XLSX.utils.book_append_sheet(wb, ws_general, 'NDP Overview') // 工作簿名称
            XLSX2.utils.book_append_sheet(wb, ws_resources, 'NDP Overview') // 工作簿名称
            XLSX2.writeFile(wb, fileName) // 保存的文件名

            //  this.isloading=false;
    },

    onRowDelete: function (id) {
      this.dataSource.value = this.dataSource.value.filter(
        (item) => item.id !== id
      );
    },

   onRowCopy: function (record) {
      // this.visible.value = false;
      var params = new URLSearchParams(record);
      params.append("action", "rowcopy");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-new.php", params)
        .then((response) => {
          // console.log(response);
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            //this.getAllObservations();
          }
        });
    },

    onSubmitNew: function () {
      // this.visible.value = false;

      this.formRef.validate().then(() => {
          var params = new URLSearchParams(this.formState);
          var seq=0;
          var varlist="";
          let originalItem=Object.entries(this.formState);
          originalItem.forEach(function (item) {         
              // console.log(currentItem[i]);

              if(['ndp_uuid', 'record_id', 'cruserid', 'crdtc', 'modtc', 'rmfl', 'fte_do', 'fte_total', 
                  'totalresource', 'fsp_total', 'mouserid', 'auditlog'].indexOf(item[0])===-1){
          
                if (seq==0){
                  varlist=item[0]
                }
                else{
                  varlist=varlist+ ' '+item[0]
                } 
                seq=seq+1;
              // params.append(item[0], encodeURIComponent(item[1]));
              };
          });

          // console.log(varlist);

          params.append("userid", localStorage.getItem('userid'));
          params.append("email",localStorage.getItem("email"));
          params.append("action", "create");
          // params.append("project_name", this.formState.project_name);
          // params.append("project_desc", this.formState.project_desc);
          // params.append("tier", this.formState.tier);
          // params.append("function_name", this.formState.function_name);
          // params.append("sub_function_name", this.formState.sub_function_name);
          // params.append("project_lead_email", this.formState.project_lead_email);
          // params.append("project_manager_email", this.formState.project_manager_email);
          // params.append("status", this.formState.status);
          // params.append("comment", this.formState.comment);
          // params.append("project_stdtc", this.formState.project_stdtc);
          // params.append("project_endtc", this.formState.project_endtc);

          params.append("debug", 'Y');
          params.append("varlist",varlist);

          console.log("Variable list:" + varlist);

          params.append("keytablename", 'do-ndp-list');
          // params.append(
          //   "jwt-token",
          //   encodeURIComponent(localStorage.getItem("accessToken"))
          // );
          axios
            .post("ndp/ndp-dict-new.php", params)
            .then((response) => {
              // console.log(response);
              if (response.data.error) {
                // this.errorMessage = response.data.message;
                message.error(response.data.message);
              } else {
                // this.successMessage = response.data.message;
                message.success(response.data.message);

              }
            });
      }).catch(error => {
        console.log('error', error);
      });

    },

    onSubmitEdit: function (key,type) {

      // this.formState.project_stdtc=moment(this.ndp_stdtc).format("YYYY-MM-DD");
      // this.formState.project_endtc=moment(this.ndp_endtc).format("YYYY-MM-DD");

      // this.formState.project_stdtc=dayjs(this.ndp_stdtc,"YYYY-MM-DD");
      // this.formState.project_endtc=dayjs(this.ndp_endtc,"YYYY-MM-DD");

      // console.log(this.formState.project_stdtc);

    if(type=="row-update"){
      this.formRef.validate().then(() => {
          var params = new URLSearchParams(this.formState);

          // console.log(this.clickedItem);
          //identify which values have been changed;
          let originalItem=Object.entries(this.clickedItem);
          let currentItem=Object.values(this.formState);

          var i=0;
          var seq=0;
          var varlist='';
          var strChangelog='';
          originalItem.forEach(function (item) {         
              // console.log(currentItem[i]);

              if (currentItem[i]!=item[1]){            
                if (seq==0){
                  varlist=item[0]
                  strChangelog ="[" + item[0] + "] from " + item[1] + " to " + currentItem[i]
                }
                else{
                  varlist=varlist+ ' '+item[0]
                  strChangelog = strChangelog + "@@@@[" +  item[0] + "] from " + item[1] + " to " + currentItem[i]
                } 
                seq=seq+1;
                // params.append(item[0], encodeURIComponent(item[1]));
              }
              i=i+1;
          });

          if(varlist==""){
            message.error("No changes made!");
            return;
          }

          // console.log(strChangelog);
          params.append("userid",this.strUserID);
          params.append("varlist", varlist);        
          params.append("auditlog",encodeURIComponent(strChangelog));   
          params.append("action", type);
          params.append("key_name", 'record_id');
          params.append("key_value", key);
          params.append("keytablename", '_xd-nmpa-study-info');
          params.append("debug", 'Y');
          
          axios
            .post(`util/general-update-row.php`, params)
            .then((response) => {
              // console.log( this.editRow);
              // console.log(this.formState);

              // this.clickedItem = this.editRow;
              if (response.data.error) {
                // console.log(response);
                // this.errorMessage = response.data.message;
                message.error(response.data.message);
              } else {
                // console.log(response);
                // this.successMessage = response.data.message;
                message.success(response.data.message);
                this.editVisibleBasic = false;
                this.dataSource.filter((item) => this.formState.record_id === item.record_id)[0].auditlog=response.data.auditlog;

                Object.assign(this.clickedItem, this.formState);          

                //additionally added for the updates of original copy;
                Object.assign(
                  this.dataSourceOrigin.filter((item) => item.record_id === this.formState.record_id)[0],
                  this.formState
                );

                //refresh the tagnamelist
                
                // this.getAllObservations();
                // console.log(this.successMessage);
              }
            });
      }).catch(error => {
        console.log('error', error);
      });

    }
    else{
        var params = new URLSearchParams(this.formState);

          // console.log(this.clickedItem);
          //identify which values have been changed;
          let originalItem=Object.entries(this.clickedItem);
          let currentItem=Object.values(this.formState);

          var i=0;
          var seq=0;
          var varlist='';
          var strChangelog='';
          originalItem.forEach(function (item) {         
              // console.log(currentItem[i]);

              if (currentItem[i]!=item[1]){            
                if (seq==0){
                  varlist=item[0]
                  strChangelog ="[" + item[0] + "] from " + item[1] + " to " + currentItem[i]
                }
                else{
                  varlist=varlist+ ' '+item[0]
                  strChangelog = strChangelog + "@@@@[" +  item[0] + "] from " + item[1] + " to " + currentItem[i]
                } 
                seq=seq+1;
                // params.append(item[0], encodeURIComponent(item[1]));
              }
              i=i+1;
          });

          if(varlist==""){
            message.error("No changes made!");
            return;
          }

          // console.log(strChangelog);
          params.append("userid",this.strUserID);
          params.append("varlist", varlist);        
          params.append("auditlog",encodeURIComponent(strChangelog));   
          params.append("action", type);
          params.append("key_name", 'record_id');
          params.append("key_value", key);
          params.append("keytablename", '_xl-nmpa-study-info');
          params.append("debug", 'Y');
          
          axios
            .post(`util/general-update-row.php`, params)
            .then((response) => {
              // console.log( this.editRow);
              // console.log(this.formState);

              // this.clickedItem = this.editRow;
              if (response.data.error) {
                // console.log(response);
                // this.errorMessage = response.data.message;
                message.error(response.data.message);
              } else {
                // console.log(response);
                // this.successMessage = response.data.message;
                message.success(response.data.message);
                this.editVisibleBasic = false;
                this.dataSource.filter((item) => this.formState.record_id === item.record_id)[0].auditlog=response.data.auditlog;

                Object.assign(this.clickedItem, this.formState);          

                //additionally added for the updates of original copy;
                Object.assign(
                  this.dataSourceOrigin.filter((item) => item.record_id === this.formState.record_id)[0],
                  this.formState
                );

                //refresh the tagnamelist
                
                // this.getAllObservations();
                // console.log(this.successMessage);
              }
            });
    }
    },

    edit(rowData) {
      let _editData = {};
      Objects.assign(_editData, rowData); //浅拷贝对象
      this.editData = _editData;
    },

    removeItem: function (recordKey) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData.xlauditlog);
      var params = new URLSearchParams();
      params.append("id", recordKey);
      params.append("action", "delete");
      params.append("debug", "Y");
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", 'do-ndp-list');
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`ndp/ndp-dict-governance.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => item.record_id !== recordKey
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => item.record_id !== recordKey
            );

            // this.getAllObservations();
          }
        });
    },
  
    removeAllItem: function (keylist) {
      // console.log (keylist);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (keylist);
      var params = new URLSearchParams();
      params.append("debug", "Y");
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", 'do-ndp-list');
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `ndp/ndp-dict-delete-records.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => keylist.indexOf(item.record_id) ===-1
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => keylist.indexOf(item.record_id)===-1
            );
            // this.getAllObservations();
          }
        });
    },

    selectCurrentItem: function (item, mode) {
      Object.assign(this.editRow, item);
      this.clickedItem = item;
      // console.log(this.editRow);
      if(mode=='edit'){
        this.formState = this.editRow;
      }
      else{
        // this.formNew = this.editRow;
      }
     
    //   this.ndp_stdtc=moment(item.project_stdtc);
    //   this.ndp_endtc=moment(item.project_endtc);

      // console.log(moment(item.project_stdtc).format("YYYY-MM-DD"));
    },

    toFormData: function (obj) {
      var form_data = new FormData();
      for (var key in obj) {
        form_data.append(key, obj[key]);
      }
      return form_data;
    },

    clearMessage: function () {
      this.errorMessage = "";
      this.successMessage = "";
    },


    queryTermsByTestName: function (searchItemValue) {
      // this.isLoading = true;

      //  console.log(searchItemValue, this.userStudyID);
      
      this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));
     if (searchItemValue){
        // console.log('Show selected protocol with search item:', searchItemValue, this.userStudyID);
        this.dataSource = this.dataSource.filter((item) =>
          item.status.toLowerCase().startsWith(searchItemValue.toLowerCase()) ||
          item.tier.toLowerCase().startsWith(searchItemValue.toLowerCase()) ||
          item.function_name.toLowerCase().startsWith(searchItemValue.toLowerCase())

        );
      }

    },

    queryByMenuiItems: function (obj) {

      // console.log(obj);

      // console.log(this.isAdmin);

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      this.columnTitle="";

      var params = new URLSearchParams();

      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));

      let strList = new Array();
      let strByVariable = '';
      let strByValue = '';

      strList = obj.keyPath[0].split("-");

      console.log(obj);

      // localStorage.setItem('menuKey', strList[2]);
      this.menuKey=strList[2];
      
      this.currentTableName = strList[0]+"-"+strList[1];
      strByVariable=strList[2];
      strByValue = obj.key.split("_")[0];
      
      params.append("action", 'read');
      params.append("keytablename", '_xd_nmpa-study-info');

      if (strByValue!='ALL'){
        // params.append("filter", strByVariable + '="'+encodeURIComponent(strByValue)+'"');
         params.append("filter", encodeURIComponent('find_in_set("'+strByValue+'",' + strByVariable+')'));
      }
       
      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "util/general-query-menuitem.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          this.inputValue = "";

          this.dataSourceOrigin = response.data.records;

          this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

          //save the current query condition into the local storage
          localStorage.setItem("query-params",params);

          this.statusChecklist=this.uniqueValueListSelected('status').sort((a, b) => (a > b) ? 1 : -1);
          
          // console.log(this.menuKey);

          if (this.menuKey=='tier'){
            this.functionChecklist=this.uniqueValueListSelected('function_name').sort((a, b) => (a > b) ? 1 : -1);
          }
          else if(this.menuKey=='function_name'){
            this.functionChecklist=this.uniqueValueListSelected('sub_function_name').sort((a, b) => (a > b) ? 1 : -1);
          }

          this.calcDashBoardMetrics(this.dataSource);


          //calculate the total value;

          // this.dataSource.forEach((item)=>{
          //     // console.log(item);
          //     item.fte_total=this.calcSummary([item.fte_bex,item.fte_cddra,item.fte_cdsa,item.fte_dm,item.fte_sp]);
          //     item.fsp_total=this.calcSummary([item.fsp_bex,item.fsp_cddra,item.fsp_cdsa,item.fsp_dm,item.fsp_sp]);
          //     // console.log(item);
          // });

        })
        .catch((error) => {
          // console.log(error);
          // this.errorMessage = error.response.data.message;
          this.isLoading = false;

          alert(error.message);
          return;
          // alert(error.message);
          // logout();
        });
    },

    clearSelection : function(){
      //reset all row selections;      
      this.errorMessage="";
      this.successMessage="";
      this.state.selectedRowKeys=[];     

      // this.dataSource.columns.resetFields;

      // alert(this.successMessage) 
    },

    selectAllItems : function(){
      //reset all row selections;
      this.state.selectedRowKeys=[];
      this.dataSource.filter((item) => this.state.selectedRowKeys.push(item.record_id));

      // this.dataSource.filter((item) => this.state.selectedRows.push(item));

      // this.state.selectedRowKeys=[];
      // console.log(this.state.selectedRowKeys);    
      
      // var selectedTerms =[];
      // this.dataSource.filter((item) => selectedTerms.push(item.email));

      // var selectedTermsLength=0;

      // for (var item in selectedTerms){
      //   selectedTermsLength+=selectedTerms[item].length; 
      // }

      // console.log(selectedTermsLength);    
      if (this.lang==='cn'){
        this.successMessage="已选定 " + this.state.selectedRowKeys.length + " 行";
      }
      else{
        this.successMessage=this.state.selectedRowKeys.length + " rows selected.";
      }
     
      // this.successMessage=this.state.selectedRowKeys;
    },

    handleDropdonwlist() {
      // console.log("dropdownlist");
      // console.log(this.dropdownValue);
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
 
  },
});
</script>

<style>
#app .logo {
  height: 48px;
  background: rgba(10, 248, 2, 0.85);
  color:rgba(14, 13, 13, 0.85);
  font-weight: bold;
  font-size: 16px;
  margin: 10px 2px 16px 2px;
  padding:6px 0px 0px 0px
}

#app .trigger {
  font-size: 18px;
  line-height: 32px;
  background: rgb(0, 242, 9,0.65);
  margin: 0px 5px 0px 5px;
  padding: 0px 12px 0px 5px;
  cursor: pointer;
  transition: color 0.3s;
}

#app .trigger:hover {
  color: #1890ff;
}

.highlight {
  background-color: rgb(255, 192, 105);
  padding: 0px;
}

.zerovaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  content: "";
  /* background-color: rgb(226, 221, 221); */
  color: rgb(218, 214, 214);
  font-size: 16px;
}

/*high value for FSP*/
.highfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  font-weight: bold;
  
  content: "";
  background-color: rgb(253, 252, 179, 0.95);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}

/*high value for FTE*/
.highftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  font-weight: bold;
  content: "";
  background-color: rgb(255, 216, 205,0.95);
  color: rgb(0, 0, 0,0.5);
  font-size: 16px;
}

.ftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.65);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}

.fspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.65);
  color: rgb(0, 0, 0,0.65);
  font-size: 16px;
}


.totalftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalhighftevaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 216, 205,0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}

.totalhighfspvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(253, 252, 179, 0.5);
  color: rgb(255, 0, 0,0.65);
  font-size: 16px;
}


.totalvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(4, 168, 31,0.65);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.totalresource {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgba(255, 0, 0, 0.85);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.totalhighvaluestyle {
  width: 100%;
  height: 100%;
  text-align: center;
  font-weight: bold;
  /* padding: 12px; */
  background-color: rgb(255, 0, 0,0.5);
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.ant-table-cell{
  text-align: center  ;
}

.totalftecolor{
  color: rgb(6, 3, 161);
}

.ant-typography {
    color: rgba(9, 121, 37);
    font-weight: bold;
    /* overflow-wrap: break-word; */
    text-align: center;
}

#components-table-demo-summary tfoot th,
#components-table-demo-summary tfoot td {
  background: #fafafa;
}
[data-theme='dark'] #components-table-demo-summary tfoot th,
[data-theme='dark'] #components-table-demo-summary tfoot td {
  background: #1d1d1d;
}

/* .boxW,
.normalB {
  :global {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
      padding: 8px 8px !important;
    }
    .ant-table-thead > tr > th {
      background-color: rgb(110, 193, 199);
      font-size: 24px；;
    }
    .ant-table-thead > tr > th:hover {
      background-color: rgb(9, 75, 80);
      font-size: 24px；;
    }
    .ant-table-thead
      > tr
      > th.ant-table-column-has-actions.ant-table-column-has-sorters:hover {
      background: rgb(192, 244, 248);
      font-size: 24px；;
    }
  }
} */


.site-layout .site-layout-background {
  background: rgb(31, 29, 29);
}

.editable-cell {
  position: relative;}

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding-right: 24px;
  }

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding: 5px 24px 5px 5px;
  }

  .editable-cell .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    right: 0;
    width: 20px;
    cursor: pointer;
  }

  .editable-cell .editable-cell-icon {
    margin-top: 4px;
    display: none;
  }

  .editable-cell-icon-check {
    line-height: 28px;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }

  .editable-add-btn {
    margin-bottom: 8px;
  }


.editable-cell:hover .editable-cell-icon {
  display: inline-block;
}

.ant-statistic-content {
    color: #eed2c0;
    font-size: 14px;
}

/* .ant-statistic-countdown {
    color: #413d3d;
    font-size: 14px;
} */

.ant-table-thead > th {
  color: white;
  background: #d46114 !important;
  font-size: 16px;
}

.ant-table-tbody > tr {
  color: rgb(0, 0, 0);
  /* background: #f0f1ee !important; */
  border: 0px !important;
  font-size: 16px;
}

.ant-table-tbody > tr:hover {
  color: rgb(255, 5, 5) !important;
  /* font-weight: bold; */
  /* font-weight: 600; */
  /* background: rgb(243, 247, 25); */
  /* font-size: 16px !important; */
}

.ant-upload-list-item {
  position: fixed !important;
  height: 22px;
  /* width: 200px  !important; */
  margin-top: 0px !important;
  font-size: 14px !important;
}
</style>