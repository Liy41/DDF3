<template>
  <a-layout>
    <!-- :style="{ overflow: 'auto', height: '100vh', position: 'fixed', left: 0 }" -->
    <a-layout-sider v-model:collapsed="collapsed" collapsible :trigger="null"        >
       <div class="logo" align="center">{{this.lang==='cn'? '诺 译 通': 'DO Translator'}}</div>
      <a-menu
        theme="dark"
        mode="inline"
        :openKeys="openKeys"
        v-model:selectedKeys="selectedKeys"
        @openChange="onOpenChange"
        @click="queryTermsByMenuiItems"
      >
        <a-sub-menu key="1-global-config">
          <template #title>
            <span>
              <DatabaseOutlined />
              <span>{{this.lang==='cn'? '设置': 'Setting'}}</span>
            </span>
          </template>
          <a-menu-item
            v-for="(item, index) in userconfig.studyTracker"
            :key="item.key+'-'+item.value+ '-'+index"
            >{{ this.lang==='cn'? item.name_cn:item.name_en }}</a-menu-item
          >
        </a-sub-menu>

      </a-menu>
    </a-layout-sider>
    <!-- :style="{ marginLeft: '200px' }" -->
    <a-layout>
      <a-layout-header
        style="background: #fff; padding: 0"
        :style="{
          margin: '0px',
          padding: '0px 0px 0px 0px',
          position: 'fixed',
          zIndex: 1,
          width: '100%',
        }"
      >
        <menu-unfold-outlined
          v-if="collapsed"
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        />
        <menu-fold-outlined
          v-else
          class="trigger"
          @click="() => (collapsed = !collapsed)"
        />

        <a-button v-if="(isAdmin===true || isGlobalTerms===false)"
          style="margin: 20px 2px 10px 2px; float: center"
          type="primary" 
          ghost
          @click="showDrawerNew"
          ><PlusOutlined /></a-button
        >

        <a-popconfirm
          v-if="selectedRowKeys != '' && (isAdmin===true || isGlobalTerms===false)"
          title="您确定要删除所选术语吗?"
          @confirm="removeAllItem(this.state.selectedRowKeys)"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary"
            ghost
            ><MinusOutlined /></a-button
          >
        </a-popconfirm>

        <a-popconfirm
          v-if="selectedRowKeys != '' && (isAdmin===true || isGlobalTerms===false)"
          title="您确定要锁定当前所选术语吗?"
          @confirm="lockAllItems(this.state.selectedRowKeys)"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" 
            ghost
            ><LockOutlined />{{this.lang==='cn'? '锁定': 'Lock'}}</a-button
          >
        </a-popconfirm>

        <a-popconfirm
          v-if="selectedRowKeys != '' && (isGlobalTerms===false)"
          title="您确定要解锁当前所选术语吗?"
          @confirm="unlockAllItems(this.state.selectedRowKeys)"
        >
          <a-button
            style="margin: 20px 2px 10px 2px; float: center"
            type="primary" 
            ghost
            ><UnlockOutlined />{{this.lang==='cn'? '解锁': 'Unlock'}}</a-button
          >
        </a-popconfirm>

        <a-dropdown v-if="isAdmin===true || isGlobalTerms===false" :trigger="['click']" >  <a >
            &nbsp; <DownOutlined />
          </a>
          <template #overlay>
            <a-menu>
              <a-menu-item key="1" @click="exportSelectedItemsAsXLS"><ExportOutlined />{{this.lang==='cn'? '导出为Excel文件': 'Export as Excel (.xlsx)'}}</a-menu-item>
              <a-menu-item key="2" @click="exportSelectedItemsAsCSV"><ExportOutlined />{{this.lang==='cn'? '导出为csv格式文本文件': 'Export as comma seperated text file (.csv)'}}</a-menu-item>
              <a-menu-item key="3" @click="exportSelectedItemsAsTAB"><ExportOutlined />{{this.lang==='cn'? '导出为Tab分隔文本文件': 'Export as TAB seperated text file (.txt)'}}</a-menu-item>
              <a-menu-item key="4" @click="exportSelectedItemsAsXNDICT"><ExportOutlined />{{this.lang==='cn'? '导出为API字典文件': 'Export as API Dictionary (.txt)'}}</a-menu-item>
              <a-menu-item key="5" @click="exportSelectedItemsAsSAS"><ExportOutlined />{{this.lang==='cn'? '导出为SAS程序文件': 'Export as SAS program (.sas)'}}</a-menu-item>
              <a-menu-item key="6" @click="exportSelectedItemsByEmail"><ExportOutlined />{{this.lang==='cn'? '邮件发送': 'Send Email'}}</a-menu-item>
              <a-menu-item key="7" @click="showUploadModal"><UploadOutlined />{{this.lang==='cn'? '上传术语': 'Upload terms from file'}}</a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>

    <span style="position: absolute; right:0; padding: 0px 200px 0px 0px">
      
        <div>
         
          <a-input-search
            style="margin: 20px 2px 10px 2px; width: 200px; float: center"
            v-model:value="inputValue"
            allow-clear
            placeholder=""
            enter-button
            @change="handleSearchInput"
            @search="handleSearchInput"
          />

          <a-button v-for="entry in languages" :key="entry.title" @click="changeLocale(entry.language)">
            <flag :iso="entry.flag" v-bind:squared=false />
          </a-button>
        

        <a-button  v-if="isLogin=true"
         style="margin: 20px 5px 10px 0px; float: center;" 
          type="link"
          @click="logout"
          ><LoginOutlined /> {{this.lang==='cn'? strUserName: 'Logout'}}  </a-button>
        <a-button  v-else
         style="margin: 20px 50px 10px 5px; float: center;" 
          type="icons-list"          
          ><LogoutOutlined /></a-button>
          </div>
          </span>          

          <div class="ant-layout-header-searchbar" align="left"        
           :style="{
          margin: '0px 100px 0px 0px',
          padding: '5px 80px 0px 70px',
          position: 'relative',
          zIndex: 1,
          width: '100%',
        }"> 
        
        <a-button type="link"   @click="selectAllItems()">{{this.lang==='cn'? '全选': 'Select All'}}</a-button>
        <a-button type="link"  @click="clearSelection()">{{this.lang==='cn'? '清除选定': 'Clear Selection'}}</a-button>

        </div>
   
        <template>
          <a-drawer
            title="添加项目 (如一个项目包含多项研究，请分别添加)"
            :width="600"
            :visible="newVisible"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="formNew" layout="vertical">
              <!-- <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交名称（不可修改）" name="protocolid">
                    <a-select v-model:value="uploadProtocolID"  ref="select"
                               @change="handleProtocolSelect">
                      <a-select-option v-for="study in globalProtocolList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号（不可修改）" name="studyid">
                    <a-select v-model:value="uploadStudyID"  ref="select"
                               @change="handleStudySelect">
                      <a-select-option v-for="study in globalStudyList" :key="study">
                      {{ study }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row> -->

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交名称（不可修改）" name="protocolid">
                    <a-input
                      v-model:value="formNew.protocolid" 
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：ENTRESTO"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号（不可修改）" name="studyid">
                    <a-input
                      v-model:value="formNew.studyid" 
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：CLCZ696B2301"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="项目标题中文（可选）" name="studytitle">
                    <a-input
                      v-model:value="formNew.xltestcd"
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="项目标题"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="治疗领域" name="taname">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formNew.taname"
                    >
                      <a-select-option value="Cardiovascular Disease">Cardiovascular</a-select-option>
                      <a-select-option value="Metabolism">Metabolism</a-select-option>
                      <a-select-option value="Oncology">Oncology</a-select-option>
                      <a-select-option value="Ophthalmology"
                        >Ophthalmology</a-select-option
                      >
                      <a-select-option value="Dermatology"
                        >Dermatology
                      </a-select-option>
                      <a-select-option value="NeuroScience">NeuroScience</a-select-option>
                      <a-select-option value="Others">Others</a-select-option>/
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="适应症" name="indication">
                    <a-input
                      v-model:value="formNew.indication"
                      placeholder="适应症"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="EDC类型" name="xledctype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formNew.xledctype"
                    >
                      <a-select-option value="OCRDC">OC RDC</a-select-option>
                      <a-select-option value="RAVE">RaveX</a-select-option>    
                      <a-select-option value="OTHER">Others</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="CRF文件格式类型" name="xlcrftype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="formNew.xlcrftype"
                    >
                      <a-select-option value="OC">Standard OC Format</a-select-option>
                      <a-select-option value="RAVE">Standard RAVE Format</a-select-option>
                      <a-select-option value="PICTURE">Picture Format</a-select-option>
                      <a-select-option value="OTHER">Other Format</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究数据类型" name="xldttype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="formNew.xldttype"
                    >
                      <a-select-option value="CDISC">CDISC</a-select-option>
                      <a-select-option value="Legacy">Legacy</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据说明文件格式类型" name="xlspectype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="formNew.xlspectype"
                    >
                      <a-select-option value="DefineXML">Define.XML</a-select-option>
                      <a-select-option value="Spreadsheet">Spreadsheet (.xlsx)</a-select-option>
                      <a-select-option value="RAP-M8">RAP Module 8 (.pdf)</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究结束日期" name="xlendtc">
                    <a-date-picker v-model:value="formNew.xlendtc" @Change="onChangePickDate"
                      format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                      />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据可用日期（GPS）" name="xldadtc">
                    <a-date-picker v-model:value="formNew.xldadtc" 
                    format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交日期（计划）" name="xldpdtcp">
                    <a-date-picker v-model:value="formNew.xldpdtcp" 
                      format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                      :disabled-date="disabledDate" />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="翻译完成日期（计划）" name="xltcdtcp">
                    <a-date-picker v-model:value="formNew.xltcdtcp" 
                    format="YYYY-MM-DD" picker="date" valueFormat="YYYY-MM-DD"
                    :disabled-date="disabledDate"/>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                 <a-form-item label="RA负责人" name="xlrapoc">
                    <a-select v-model:value="formNew.xlrapoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="DO负责人" name="xldopoc">
                    <a-select v-model:value="formNew.xldopoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="SP负责人" name="xlsppoc">
                    <a-select v-model:value="formNew.xlsppoc"  ref="select"                               >
                    <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                     {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>             
                <a-col :span="10">
                  <a-form-item label="DM负责人" name="xldmpoc">
                    <a-select v-model:value="formNew.xldmpoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="CD负责人" name="xlcdpoc">
                    <a-select v-model:value="formNew.xlcdpoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>       
                <a-col :span="10">
                  <a-form-item label="RWS负责人" name="xlmwpoc">
                    <a-select v-model:value="formNew.xlmwpoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.username }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>


              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="注释" name="xlcomment">
                    <a-input
                      placeholder=""
                      v-model:value="formNew.xlcomment"
                    />
                  </a-form-item>
                </a-col>
              </a-row>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseNew"
                >取消</a-button
              >
              <a-button type="primary" @click="onSubmitNew">确定</a-button>
            </div>
          </a-drawer>
        </template>


        <template>
          <a-drawer
            title="编辑项目"
            :width="600"
            :visible="editVisible"
            :destroyOnClose="true"
            :body-style="{ paddingBottom: '80px' }"
            @close="onCloseNew"
          >
            <a-form :model="form" layout="vertical">
              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交名称（不可修改）" name="protocolid">
                    <a-input
                      v-model:value="form.protocolid" disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：ENTRESTO"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="研究编号（不可修改）" name="studyid">
                    <a-input
                      v-model:value="form.studyid" disabled
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="例如：CLCZ696B2301"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="项目标题中文（可选）" name="studytitle">
                    <a-input
                      v-model:value="form.xltestcd"
                      style="width: 100%"
                      addon-before=""
                      addon-after=""
                      placeholder="项目标题"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="治疗领域" name="taname">
                    <a-select
                      placeholder="请选择："
                      v-model:value="form.taname"
                    >
                      <a-select-option value="Cardiovascular Disease">Cardiovascular</a-select-option>
                      <a-select-option value="Metabolism">Metabolism</a-select-option>
                      <a-select-option value="Oncology">Oncology</a-select-option>
                      <a-select-option value="Ophthalmology"
                        >Ophthalmology</a-select-option
                      >
                      <a-select-option value="Dermatology"
                        >Dermatology
                      </a-select-option>
                      <a-select-option value="NeuroScience">NeuroScience</a-select-option>
                      <a-select-option value="Others">Others</a-select-option>/
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="适应症" name="indication">
                    <a-input
                      v-model:value="form.indication"
                      placeholder="适应症"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="EDC类型" name="xledctype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="form.xledctype"
                    >
                      <a-select-option value="OCRDC">OC RDC</a-select-option>
                      <a-select-option value="RAVE">RaveX</a-select-option>    
                      <a-select-option value="OTHER">Others</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="CRF文件格式类型" name="xlcrftype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="form.xlcrftype"
                    >
                      <a-select-option value="OC">Standard OC Format</a-select-option>
                      <a-select-option value="RAVE">Standard RAVE Format</a-select-option>
                      <a-select-option value="PICTURE">Picture Format</a-select-option>
                      <a-select-option value="OTHER">Other Format</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究数据类型" name="xldttype">
                    <a-select
                      placeholder="请选择："
                      v-model:value="form.xldttype"
                    >
                      <a-select-option value="CDISC">CDISC</a-select-option>
                      <a-select-option value="Legacy">Legacy</a-select-option>                     
                    </a-select>
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据说明文件格式类型" name="xlspectype">
                                       <a-select
                      placeholder="请选择："
                      v-model:value="form.xlspectype"
                    >
                      <a-select-option value="DefineXML">Define.XML</a-select-option>
                      <a-select-option value="Spreadsheet">Spreadsheet (.xlsx)</a-select-option>
                      <a-select-option value="RAP-M8">RAP Module 8 (.pdf)</a-select-option>
                      
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="研究结束日期" name="xlendtc">
                    <a-date-picker v-model:value="form.xlendtc" @Change="onChangePickDate"
                      format="YYYY-MM-DD"
                      />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="数据可用日期（GPS）" name="xldadtc">
                    <a-date-picker v-model:value="form.xldadtc" 
                    format="YYYY-MM-DD"
                    />
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="项目递交日期（计划）" name="xldpdtcp">
                    <a-date-picker v-model:value="form.xldpdtcp" 
                      format="YYYY-MM-DD"
                      :disabled-date="disabledDate" />
                  </a-form-item>
                </a-col>
                <a-col :span="10">
                  <a-form-item label="翻译完成日期（计划）" name="xltcdtcp">
                    <a-date-picker v-model:value="form.xltcdtcp" 
                    format="YYYY-MM-DD"
                    :disabled-date="disabledDate"/>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                 <a-form-item label="RA负责人" name="xlrapoc">
                    <a-select v-model:value="form.xlrapoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>

                <a-col :span="10">
                  <a-form-item label="DO负责人" name="xldopoc">
                    <a-select v-model:value="form.xldopoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="SP负责人" name="xlsppoc">
                    <a-select v-model:value="form.xlsppoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>             
                <a-col :span="10">
                  <a-form-item label="DM负责人" name="xldmpoc">
                    <a-select v-model:value="form.xldmpoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>

              <a-row :gutter="20">
                <a-col :span="10">
                  <a-form-item label="CD负责人" name="xlcdpoc">
                    <a-select v-model:value="form.xlcdpoc"  ref="select"                               >
                     <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>       
                <a-col :span="10">
                  <a-form-item label="RWS负责人" name="xlmwpoc">
                    <a-select v-model:value="form.xlmwpoc"  ref="select"                               >
                      <a-select-option v-for="user, index in globalUserList" :key="index" :value="user.userid">
                      {{ user.userid }}
                      </a-select-option>
                    </a-select>
                  </a-form-item>
                </a-col>
              </a-row>


              <a-row :gutter="20">
                <a-col :span="20">
                  <a-form-item label="注释" name="xlcomment">
                    <a-input
                      placeholder=""
                      v-model:value="form.xlcomment"
                    />
                  </a-form-item>
                </a-col>
              </a-row>
            </a-form>
            <div
              :style="{
                position: 'absolute',
                right: 0,
                bottom: 0,
                width: '100%',
                borderTop: '1px solid #e9e9e9',
                padding: '10px 16px',
                background: '#fff',
                textAlign: 'right',
                zIndex: 1,
              }"
            >
              <a-button style="margin-right: 8px" @click="onCloseEdit"
                >取消</a-button
              >
              <a-button type="primary" @click="onSubmitEdit">更新</a-button>
            </div>
          </a-drawer>
        </template>

        <!-- <a style="margin:4px 5px 15px 20px; float: center; color: red">Total records: {{dataSource.length}}</a> -->
    

      </a-layout-header>

      <a-layout-content
        :style="{
          margin: '50px 0px 0px 10px',
          padding: '50px 0px 0px 0px',
          background: '#fff',
          minHeight: '700px',
        }" 
      >
    

      <a-spin tip="Loading..." :spinning="isLoading">
          <a-table
            class="list"
            :data-source="dataSource"
            rowKey="id"
            :row-selection="{selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange, columnTitle:columnTitle}"
            :scroll={y:600}
            :columns="columnsList"
            :customRow="customRightClick"
            @change="handleChange"
            size="middle"
            tableLayout="fixed"
            :pagination="pagination"
          >

            <template #seq="{ index }">
                {{ (index + 1)+(currentPage-1)*currentPageSize }}
              </template>

   
            <template #action="{ record }" align="left">

              <a-button type="link"
                  @click="
                  editVisible = true;
                  selectCurrentItem(record);
                ">
                {{this.lang==='cn'?'编辑':'Edit'}}</a-button>

              <a-popconfirm
                v-if="
                  dataSource.length === -1 "
                title="您确定要删除当前记录吗?"
                @confirm="removeItem(record.id)"
              >
                <a-button type="link">{{this.lang==='cn'?'删除':'Delete'}}</a-button>
              </a-popconfirm>

            </template>

            <template #expandedRowRender="{ record }">
              <!-- <p style="margin: 0">
                Last modified date：{{ record.xlmodtc }} {{ record.xlmouser }} 
              </p> -->
              <p style="margin: 0">
                Study ID: {{ record.studyid}}
              </p>
              <p style="margin: 0"  v-if="record.xlcomment != 'null' && record.xlcomment != ''">
                Comments: {{ record.xlcomment }}
              </p>
              <p>SP Contact: {{record.xlsppoc}} &nbsp;&nbsp;&nbsp;&nbsp; 
                  DM Contact: {{record.xldmpoc}} &nbsp;&nbsp;&nbsp;&nbsp;
                  RA Contact: {{record.xlrapoc}} &nbsp;&nbsp;&nbsp;&nbsp;
                  CD Contact: {{record.xlcdpoc}} &nbsp;&nbsp;&nbsp;&nbsp;
                  RWS Contact: {{record.xlmwpoc}}  </p>
              <pre ></pre>
              <p
                style="margin: 0;"
                v-if="record.xlauditlog != 'null' && record.xlauditlog != ''">
                <pre>{{ record.xlauditlog }}</pre>
              </p>
            </template>
             
          </a-table>
          
        </a-spin>
       

        <div class="fix"></div>
        <div class="modal col-md-6" id="editmodal" v-if="showingeditModal">
          <div class="modalheading">
            <p class="center">Edit</p>
            <p class="right close" @click="showingeditModal = false">x</p>
          </div>
          <div class="modalbody">
            <div class="modalcontent">
              <table class="form">
                <tr>
                  <th>Item Name</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xltestcd"
                      disabled="disabled"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Source Description</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xltest"
                      disabled="disabled"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Target Description</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xlmodify"
                      width="228"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Status</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xlstat"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Category</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xlcat"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Sub Category</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xlscat"
                    />
                  </td>
                </tr>
                <tr>
                  <th>Comment</th>
                  <th>:</th>
                  <td>
                    <input
                      type="text"
                      placeholder=""
                      v-model="clickedItem.xlcomment"
                    />
                  </td>
                </tr>
              </table>
              <div class="margin" align="center">
                <a-button
                  type="primary"
                  @click="
                    showingeditModal = false;
                    updateItem();
                  "
                  >Update</a-button
                >
              </div>
            </div>
          </div>
        </div>


         <div class="fix" align="left"        
           :style="{
          margin: '0px 0px 0px 0px',
          padding: '0px 50px 0px 0px',
          position: 'relative',
          zIndex: 1,
          width: '95%',
        }"> 

        </div>

      </a-layout-content>        

      <a-layout-footer style="text-align: center">
          <div style="margin-right: 0px;
                      margin-bottom: 10px;
                      margin-left: 0px;
                      margin-top: 30px;"><span>Powered by Data42, ©2020 </span></div>   
          <p class="errorMessage" v-if="errorMessage">{{ errorMessage }}</p>
          <p class="successMessage" style="text-align: left" v-if="successMessage">
            {{ successMessage }}
          </p>
      </a-layout-footer>
    </a-layout>
  </a-layout>
</template>

<script>
// SmileOutlined, DownOutlined, DeleteOutlined, AppstoreTwoTone,
// import EditableCell from "@/components/EditableCell.vue";
import XLSX from 'xlsx';
import {
  // UserOutlined, VideoCameraOutlined,UploadOutlined,
  PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined,ClusterOutlined, ReadOutlined,LockOutlined,
  UnlockOutlined,
  SlackOutlined,
  ReloadOutlined,
  GooglePlusOutlined,
  LoginOutlined,
  LogoutOutlined,
  SmileTwoTone,
  UserOutlined,
  RobotOutlined,
  TranslationOutlined,
  PushpinOutlined,
  SmileOutlined,
  DownOutlined,
  MinusOutlined,
  DeleteOutlined,
  MenuUnfoldOutlined,
  MailOutlined,
  AppstoreOutlined,
  UploadOutlined,
  ExportOutlined,
  ToolOutlined,
  CheckOutlined,
  EditOutlined,
  SearchOutlined,
  SettingOutlined,
  PlusOutlined,
  MenuFoldOutlined,
} from "@ant-design/icons-vue";
// import axios from "axios";
import axios from '@/axios';
import locale from 'ant-design-vue/es/date-picker/locale/zh_CN';
import moment from 'moment';
import 'moment/dist/locale/zh-cn';

import { computed, defineComponent, onUpdated, onMounted, reactive, ref, toRefs, watch } from "vue";
import { cloneDeep, debounce, stubString } from "lodash-es";
import { message } from "ant-design-vue";
import config from "../common/config.js";
import nmpaapi from "../common/nmpa-api.js";

export default defineComponent({
  components: {
    // UserOutlined,
    // VideoCameraOutlined,
    SearchOutlined,
    PartitionOutlined,TableOutlined,DatabaseOutlined,MenuOutlined,ClusterOutlined, ReadOutlined,LockOutlined,
    UnlockOutlined,
    SlackOutlined,
    GooglePlusOutlined,
    ReloadOutlined,
    LoginOutlined,
    LogoutOutlined,
    SmileTwoTone,
    UserOutlined,
    TranslationOutlined,
    RobotOutlined,
    PushpinOutlined,
    SmileOutlined,
    DownOutlined,
    MinusOutlined,
    DeleteOutlined,
    UploadOutlined,
    CheckOutlined,
    EditOutlined,
    PlusOutlined,
    MailOutlined,
    AppstoreOutlined,
    SettingOutlined,
    MenuUnfoldOutlined,
    ExportOutlined,
    ToolOutlined,
    MenuFoldOutlined,
  },

  data() {
    return {

      languages: [
          // { flag: 'us', language: 'en', title: 'English' },
          { flag: 'cn', language: 'cn', title: 'Chinese' },
          { flag: 'us', language: 'en', title: 'English' },
      ],

      contextMenuVisible: false,
      contextMenuStyle: {
        position: "absolute",
        top: "0",
        left: "0",
        border: "1px solid #eee"
      },

      customRightClick: record => ({      
        on: {
          contextmenu: e => {
            e.preventDefault();
            this.menuData = record;
            this.contextMenuVisible = true;
            this.contextMenuStyle.top = e.clientY + "px";
            this.contextMenuStyle.left = e.clientX + "px";
            document.body.addEventListener("click", this.bodyClick);
          }
        }
      }),

      locale,

      // userconfig: config,
      nmpaapi: nmpaapi,
      fileList: [],
      uploading: false,
      showingModal: false,
      showingeditModal: false,
      showingdeleteModal: false,
      // inputValue: "",
      // dataSource: [],
      // cellEdit: ref({}),
      // clickedItem: {},
      editRow: {},    
      studylist:[],
      // letterList: [],
    };
  },

  setup() {
    // const fileList = ref([]);
    // const uploading = ref(false);


    const disabledDate = current => {
      // Can not select days before today and today
      return current && current < moment().endOf('day');
    };

    // const  dataSource=ref([]);

    let lastFetchId = 0;
    const pageTotalLabel=ref('');
    const userconfig=reactive(config);
    const statusList=reactive(config.statusList);

    //for status bar at bottom
    // const uploadFile = ref('');

    //for upload purpose
    const inputValue = ref('');
    const uploadVisible = ref(false);
    const progressValue = ref('');
    const letterList = ref([]);
    const userStudyList = ref([]);
    const userProtocolList = ref([]);
    const globalStudyList = ref([]);
    const globalProtocolList = ref([]);
    const globalUserList = ref([]);
    const uploadFile = ref([]);
    const defaultPercent = ref(0);//for upload progress
    const uploadProtocolID = ref('');
    const uploadStudyID = ref('');
    const userProtocolID = ref('');
    const userStudyID = ref('');
    const uploadFileWithoutDuplicate=ref(1);
    const uploadDescription = ref('');
    const uploadComment = ref('');
    const uploadTermScope = ref(2);
    const uploadTermAccess = ref(2);
    const uploadTermCategory=ref('variable-label');
    const uploadTermType=ref('General');
    const radioStyle = reactive({
      display: 'block',
      height: '50px',
      lineHeight: '30px',
    });

    const onChangePickDate=()=>{
      console.log(moment(formNew.xlendtc).format("YYYY-MM-DD"));
    };

    const beforeUpload=(file)=> {

        var fileExtName=file.name.substring(file.name.lastIndexOf('.')+1).toLowerCase();
        const isTxtCSV = fileExtName === "txt" || fileExtName === "csv";
        // const isTxtCSV = file.type === 'text/plain' || file.type === 'application/vnd.ms-excel' 
        if (!isTxtCSV) {
            message.error('只能上传文本格式文件!')
        }
        const isLt5M = file.size / 1024 / 1024 < 5
        if (!isLt5M) {
            message.error('文件大小不得大于5MB!')
        }

        uploadFile.value[0]=file.name;

        return isTxtCSV && isLt5M
    };

    const uploadTerms=(file)=> {

      // console.log(file.file.name);

      if (uploadTermScope.value === 2 && (uploadStudyID.value==='' || uploadProtocolID.value==='') ){
          errorMessage.value="Protocol or Study ID not selected, please check.";
          return;
      }

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      if(uploadDescription.value===''){
        uploadDescription.value=localStorage.getItem('userid') + '|' +file.file.name.toUpperCase();
      }
      else{
        uploadDescription.value=uploadDescription.value.toUpperCase();
      }

      let formdata = new FormData()
      formdata.append('protocolid', uploadProtocolID.value)
      formdata.append('studyid', uploadStudyID.value)
      formdata.append('description', uploadDescription.value)
      formdata.append('scope', uploadTermScope.value)
      formdata.append('category', uploadTermCategory.value)
      formdata.append('removeduplicate', uploadFileWithoutDuplicate.value)  
      formdata.append('type', uploadTermType.value)
      formdata.append('access', uploadTermAccess.value)
      formdata.append('comment', uploadComment.value)
      formdata.append('file', file.file)
      formdata.append("userid",localStorage.getItem("userid"));

      const config = {
        onUploadProgress: progressEvent => {
          // progressEvent.loaded:已上传文件大小
          // progressEvent.total:被上传文件的总大小
        //   defaultPercent.value = Number((progressEvent.loaded / progressEvent.total * 100).toFixed(2))
          defaultPercent.value=parseInt( Math.round((progressEvent.loaded / progressEvent.total ) * 100 ))
        }
      }

      axios.post(`util/nmpa-dict-upload-csv.php`,formdata,config).then(
          response => {
            if (response.data.error) {
            message.error(response.data.message);

          } else {
            message.success(response.data.message);

            message.success("正在写入数据库，请耐心等待！");

            formdata.append('filename', response.data.filename);
            formdata.append('keytablename', localStorage.getItem("keytablename"));

            axios.post(`util/nmpa-dict-import-upload-v3.php`,formdata,config).then(
                response => {
                    if (response.data.error) {
                    message.error(response.data.message);

                } else {
                    message.success(response.data.message);
                    uploadVisible.value=false;
                    // console.log(response.data);
                }
                }).catch((error) => {
                        console.log(error.data);
                        message.error(error.data.message);
                    })
                // console.log(response.data);
            }
      }).catch((error) => {
            console.log(error.data);
            message.error(error.data.message);
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
      })
    };


    const stripe = ref();
    const columnTitle = ref(' ');
    const successMessage = ref("");
    const errorMessage = ref("");
    const searchInput = ref();
    const strUserName =  ref("");
    const editableData = reactive({});
    const clickedItem=reactive({});

    const isLogin = ref(false);
    const isAdmin = ref(false);
    const lang =ref('cn');
    const lblTranslationStatus = ref("正在翻译，请稍候... ...");

    const columnsList = reactive([
      {
 
      },
    ]);

    const selectedRowKeyList = ref(1);
    const currentPage = ref(1);
    const currentPageSize = ref(1);
    const filteredInfo = ref();
    const sortedInfo = ref();

   const uniqueCapitalLetterListSelected= (keyname)=> {
        //  var output = [];
         var keys   = [];
         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();
             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };

  const handleSearchInput=()=> {
    
      // console.log(userStudyID.value)

      dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));

      if (userProtocolID.value && userStudyID.value !="---Show All---"){
        dataSource.value = dataSource.value.filter(
          (item) =>
           item.studyid.toUpperCase()==userStudyID.value
        );
      }
      else if (userProtocolID.value && userProtocolID.value !="---Show All---" && userStudyID.value ==="---Show All---"){
        dataSource.value = dataSource.value.filter(
          (item) =>
           item.protocolid.toUpperCase()==userProtocolID.value
        );
      }

    };

    //add item into global library
    const AddIntoGlobalDict=(item)=>{

     
      var params = new URLSearchParams();

      params.append("keytablename", encodeURIComponent(currentTableName.value));
      params.append("action", 'append');
      params.append("userid", localStorage.getItem('userid'));

      params.append("xltest", encodeURIComponent(item.xltest));
      params.append("xltestcd", encodeURIComponent(item.xltestcd));
      params.append("xlmodify", encodeURIComponent(item.xlmodify));

      params.append("xlcat", encodeURIComponent(item.xlcat));
      params.append("xlscat", encodeURIComponent(item.xlscat));
      params.append("xltype", encodeURIComponent(item.xltype));

      params.append("protocolid", encodeURIComponent(item.protocolid));
      params.append("studyid", encodeURIComponent(item.studyid));   
      
      params.append("xlcomment", encodeURIComponent(item.xlcomment));

      axios
        .post(
          `terms/nmpa-api-dict-add.php`,
          params
        )
        .then((response) => {
          // console.log(response.data);
          message.success(response.data.message);

        })
        .catch((error) => {
          // console.log(error);
          message.error(resposne.data.message);
          // errorMessage.value = error;
        });

    };
    //upload modal operation


    const getUserRole=()=>{

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      //retrieve user role information, determin if admin;
      axios
        .post(
          `util/nmpa-dict-user-info.php`,
          params
        )
        .then((response) => {
            isAdmin.value=response.data.alevel==='1'? true:false;
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
    }

    const showUploadModal = () => {

      uploadVisible.value = true;

      // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      // //retrieve user role information, determin if admin;
      // axios
      //   .post(
      //     `util/nmpa-dict-user-info.php`,
      //     params
      //   )
      //   .then((response) => {
      //       isAdmin.value=response.data.alevel==='1'? true:false;
      //   })
      //   .catch((error) => {
      //     // console.log(error);
      //     errorMessage.value = error;
      //   });

      uploadTermAccess.value=2;
      uploadTermScope.value=2;

      //populate the default value;      
      uploadDescription.value = "";

      axios
        .post(
          `terms/nmpa-dict-study-list.php`,
          params
        )
        .then((response) => {

          dataSourceStudy.value=response.data.records;
          globalProtocolList.value=[];
          dataSourceStudy.value.forEach(function (record) {

             var key = record['protocolid'].toUpperCase();

             if (globalProtocolList.value.indexOf(key) === -1) {
                 globalProtocolList.value.push(key);
             }
         });

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });
    };

    // const handleUserProtocolSelect2 =()=>{
    //   //update the studylist dynamically
    //     userStudyList.value=[];
    //     userStudyID.value='';
    //     dataSourceStudy.value.forEach(function (record) {
    //       var key = record['studyid'].toUpperCase();
    //       if (record['protocolid'].toUpperCase() == userProtocolID.value){
    //         // globalStudyList.value.push(record['studyid'].toUpperCase());
    //         if (userStudyList.value.indexOf(key) === -1) {
    //              userStudyList.value.push(key);
    //          }
    //       }
    //       userStudyID.value=userStudyList.value[0];
    //   });

    // };

    const handleUserProtocolSelect =()=>{
      //update the studylist dynamically
        userStudyList.value=["---Show All---"];
        userStudyID.value='';
        // console.log(userProtocolID.value);    
        dataSourceOrigin.value.forEach(function (record) {
          var key = record['studyid'].toUpperCase();
          // console.log(userProtocolID.value);
          if (record['protocolid'].toUpperCase() == userProtocolID.value){
            // globalStudyList.value.push(record['studyid'].toUpperCase());
            if (userStudyList.value.indexOf(key) === -1) {
                 userStudyList.value.push(key);
             }
          }
         
          // localStorage.setItem("protocolid", userProtocolID.value);
          // localStorage.setItem("studyid", userStudyID.value);
          // localStorage.setItem("searchterm", inputValue.value);

          // this.handleSearchInput();
          // handleSearchInput();
      });

          localStorage.setItem("userStudyList", userStudyList.value);
          userStudyID.value=userStudyList.value[0];
          // console.log(userStudyID.value);
          handleSearchInput();
    };

   const uniqueCapitalLetterListSelected2=(keyname)=>{
        //  var output = [];
         var keys   = [];

        //  console.log(keyname);

         dataSource.value.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
   };

    // const handleUserStudySelect=()=>{
      
    //   console.log(userStudyID.value)

    //   dataSource.value = JSON.parse(JSON.stringify(dataSourceOrigin.value));
    //   if (userStudyID.value){
    //     dataSource.value = dataSource.value.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(inputValue.value.toLowerCase()) 
    //         ) && item.studyid.toUpperCase()==userStudyID.value
    //     );
    //   }
    //   else{
    //      dataSource.value = dataSource.value.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(inputValue.value.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(inputValue.value.toLowerCase()) 
    //         ) 
    //     );
    //   }

    //   letterList.value=uniqueCapitalLetterListSelected2('xltest').sort((a, b) => (a > b) ? 1 : -1);

    //   localStorage.setItem("protocolid", userProtocolID.value);
    //   localStorage.setItem("studyid", userStudyID.value);
    //   localStorage.setItem("searchterm", inputValue.value);

    //   handleSearchInput();

    // };

    // this.userProtocolList=this.uniqueStudyList('protocolid').sort((a, b) => (a > b) ? 1 : -1);

    const handleProtocolSelect =()=>{
      //update the studylist dynamically
        globalStudyList.value=[];
        uploadStudyID.value='';
        dataSourceStudy.value.forEach(function (record) {
          var key = record['studyid'].toUpperCase();
          if (record['protocolid'].toUpperCase() == uploadProtocolID.value){
            // globalStudyList.value.push(record['studyid'].toUpperCase());
            if (globalStudyList.value.indexOf(key) === -1) {
                 globalStudyList.value.push(key);
             }
          }
          uploadStudyID.value=globalStudyList.value[0];
      });

    };

    const handleStudySelect =()=>{
      //update the studylist dynamically
        uploadDescription.value='';
      //   dataSourceStudy.value.forEach(function (record) {
      //     if (record['studyid'].toUpperCase() == uploadStudyID.value){
      //       uploadDescription.value = record['studytitle'];
      //     }
      // });

    };

    // const rowSelection = {
    //   onChange: (selectedRowKeys, selectedRows) => {
    //     // console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);        
    //     selectedRowKeyList.value=selectedRowKeys;
    //     // console.log(selectedRows);
    //     selectedRowList.value=selectedRows;

    //     if (selectedRowKeyList.value !=""){
    //       successMessage.value=selectedRowKeyList.value;
    //     }
    //     else{
    //       successMessage.value="";
    //       selectedRowKeyList.value="";
    //     }
        
    //   },

    //   // {selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange, columnTitle:columnTitle}

    //   getCheckboxProps: record => ({
    //     // disabled: record.name === 'Disabled User',
    //     // // Column configuration not to be checked
    //     // name: record.name,
    //   }),
      

    // };

    const handleChange = (pagination, filters, sorter) => {
      // console.log("Various parameters", pagination, filters, sorter);
      filteredInfo.value = filters;
      sortedInfo.value = sorter;
      currentPage.value = pagination.current;
      currentPageSize.value = pagination.pageSize;
      // console.log("this is currentpage:", currentPage);
    };

    const dropdownValue = "";

    const newVisible = ref(false);
    const editVisible = ref(false);
    const translationFormVisible = ref(false);
    const isLoading = ref(false);
    const isLoadingTranslation = ref(false);
    const Loading = ref(false);
    const isGlobalTerms = ref(true);
    const currentTableName = ref("global-dataset-label");

    const currentTerm = ref("");
    const originalTerm = ref("");
    const originalStatus = ref("");
    const originalComment = ref("");

    const showDrawerNew = () => {

      // //retrieve the protocol and study list from database;
      var params = new URLSearchParams();
      params.append("userid", localStorage.getItem('userid'));
      params.append("keytablename", 'study_info');

      // //retrieve user role information, determin if admin;
      // axios
      //   .post(
      //     `util/nmpa-dict-user-info.php`,
      //     params
      //   )
      //   .then((response) => {
      //       isAdmin.value=response.data.alevel==='1'? true:false;
      //   })
      //   .catch((error) => {
      //     // console.log(error);
      //     errorMessage.value = error;
      //   });

      axios
        .post(
          `terms/nmpa-dict-user-list.php`,
          params
        )
        .then((response) => {
          
          // dataSourceStudy.value=response.data.records;
          globalUserList.value=response.data.records;
        //   dataSourceStudy.value.forEach(function (record) {
        //      globalUserList.value.push(record['userid'].toUpperCase());
        //  });

        // console.log("DEBUG:>>>" + response.data.records);

        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = error;
        });

      newVisible.value = true;
      // console.log(globalUserList);
    };
    const showDrawerEdit = () => {
      editVisible.value = true;
    };  

    const showDrawerTranslation = (term) => {
      // translationFormVisible.value = true;
      // console.log(term);

      isLoadingTranslation.value = true;

      var params = new URLSearchParams();
      params.append("src", encodeURIComponent(term));
      params.append("from", "en");
      params.append("to", "zh");

      //automatically translate the source with xn api
      lblTranslationStatus.value = "已完成翻译：";
      axios
        .post(
          `terms/nmpa-online-translator-xn.php`,
          params
        )
        .then((response) => {
          // console.log(JSON.parse(response.data).tgt_text);
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifyxn = JSON.parse(
            response.data
          ).tgt_text;
          //   this.successMessage = response.data.message;
          // lblTranslationStatus.value = "小牛翻译已完成";
          lblTranslationStatus.value = lblTranslationStatus.value + "小牛 ";
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "小牛翻译出现异常";
        });

      //automatically translate the source with baidui api

      axios
        .post(
          `terms/nmpa-online-translator-bd.php`,
          params
        )
        .then((response) => {
          // console.log(response.data.trans_result[0]["dst"]); //test ok
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifybd =
            response.data.trans_result[0]["dst"];

          lblTranslationStatus.value = lblTranslationStatus.value + "百度 ";
          //   this.successMessage = response.data.message;
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "Baidu翻译出现异常";
        });

      //automatically translate the source with gg api
      // lblTranslationStatus.value = "正在谷歌翻译，请稍候";
      axios
        .post(
          `terms/nmpa-online-translator-gg.php`,params
        )
        .then((response) => {
          // console.log(response);
          // this.dataSource = response.data.records;
          // console.log(this.dataSource);
          formTranslationResults.xlmodifygg = response.data["1"];
          //   this.successMessage = response.data.message;

          lblTranslationStatus.value = lblTranslationStatus.value + "谷歌  ";
        })
        .catch((error) => {
          // console.log(error);
          errorMessage.value = "Google翻译出现异常";
        });
      // formTranslationResults.xlmodifyxn = "this";

      isLoadingTranslation.value = false;
    };

    const selectTranslationResult = (key, translationplatform) => {
      // console.log(key);
      let strResult = "";
      if (translationplatform == "xn") {
        strResult = formTranslationResults.xlmodifyxn;
        // console.log(formTranslationResults.xlmodifyxn);
      } else if (translationplatform == "gg") {
        strResult = formTranslationResults.xlmodifygg;
      } else if (translationplatform == "bd") {
        strResult = formTranslationResults.xlmodifybd;
      } else if (translationplatform == "yd") {
        strResult = formTranslationResults.xlmodifyyd;
      } else if (translationplatform == "am") {
        strResult = formTranslationResults.xlmodifyam;
      }

      //write back to the data source;

      // console.log(strResult);

      // lblTranslationStatus.value = "翻译完成";

      dataSource.value.filter(
        (item) => key === item.id
      )[0].xlmodify = strResult;

      //additionally added for the clone copy operation due to a clone copy used as datasource for more efficiency;
      dataSourceOrigin.value.filter(
        (item) => key === item.id
      )[0].xlmodify = strResult;
    };

    const form = reactive({
      protocolid: "",
      studyid: "",
      studytitle:"",
      taname:"",
      indication:"",
      xldopoc:"",
      xlrapoc:"",
      xlsppoc:"",
      xldmpoc:"",
      xlmwpoc:"",
      xlcdpoc:"",
      xltcdtcp:"",
      xlendtc:"",
      xldpdtcp:"",
      seq: "",
      xltest: "",
      xltestcd: "",
      xlmodify: "",
      xlcat: "",
      xlscat: "",
      xlcomment: "",
      xltype: "",
      xldttype:"",
      xlspectype:"",
      xlcrftype:"",
      xledctype:"",
      xlcruser: "",
      xlmouser: "",
      xlmodtc: "",
      xlauditlog: "",
    });

    const formNew = reactive({
      protocolid: "",
      studyid: "",
      studytitle:"",
      taname:"",
      indication:"",
      xldopoc:"",
      xlrapoc:"",
      xlsppoc:"",
      xldmpoc:"",
      xlmwpoc:"",
      xlcdpoc:"",
      xltcdtcp:"",
      xlendtc:"",
      xldpdtcp:"",
      seq: "",
      xltest: "",
      xltestcd: "",
      xlmodify: "",
      xlcat: "",
      xlscat: "",
      xlcomment: "",
      xltype: "",
      xldttype:"",
      xlspectype:"",
      xlcrftype:"",
      xledctype:"",
      xlcruser: "",
      xlmouser: "",
      xlmodtc: "",
      xlauditlog: "",
    });

    const formTranslationResults = reactive({
      xlmodifyxn: "",
      xlmodifygg: "",
      xlmodifybd: "",
      xlmodifyyd: "",
      xlmodifyam: "",
    });

    const refreshSelect =()=>{
        var params = new URLSearchParams();
        params.append("action", "query");
        params.append("userid",localStorage.getItem("userid").toUpperCase());
        params.append(
          "keytablename",
          encodeURIComponent(currentTableName.value)
        );
        axios
          .post(`terms/nmpa-dict-study-list.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              console.log(response.data.records);

            }});
    };

    const cellEdit = (key) => {
      // console.log("this is for a test");
      editableData[key] = cloneDeep(
        dataSource.value.filter((item) => key === item.id)[0]
      );
      // editableData[key] = dataSource[key];
      // console.log(dataSource[key]);
      originalTerm.value = editableData[key].xlmodify;
    };

    const cellSave = (key) => {
      Object.assign(
        dataSource.value.filter((item) => key === item.id)[0],
        editableData[key]
      );

      // dataSource[key] = editableData[key];

      //additionally added for the clone copy operation due to a clone copy used as datasource for more efficiency;
      Object.assign(
        dataSourceOrigin.value.filter((item) => key === item.id)[0],
        editableData[key]
      );
      // Object.assign(dataSourceOrigin[key], editableData[key]);
      //dataSourceOrigin['ID']=editableData[key];

      // console.log(currentTableName.value);
      //update to database accordingly
      // alert("this is for a test" + editableData[key].xlmodify);

      // console.log("Edit Data", strCurrentTerm.value);
      // console.log(
      //   "ds",
      //   dataSource.value.filter((item) => key === item.id)[0].xlmodify
      // );

      // console.log(
      //   "dsorigin",
      //   dataSourceOrigin.value.filter((item) => key === item.id)[0].xlmodify
      // );

      currentTerm.value=dataSource.value.filter((item) => key === item.id)[0].xlmodify;
      // console.log(originalTerm.value);
      // console.log(currentTerm.value);

      if (originalTerm.value != currentTerm.value
        // dataSourceOrigin.value[key].xlmodify != strCurrentTerm.value
      ) {
        var params = new URLSearchParams(editableData[key]);
        params.append("action", "cell-update");
        params.append("id", key);
        params.append("original-term", originalTerm.value);
        // params.append("modified-term", currentTerm.value);
        params.append("userid",localStorage.getItem("userid"));
        params.append(
          "keytablename",
          encodeURIComponent(currentTableName.value)
        );
        // params.append(
        //   "jwt-token",
        //   encodeURIComponent(localStorage.getItem("accessToken"))
        // );
        axios
          .post(`terms/nmpa-dict-update-cell.php`, params)
          .then((response) => {
            if (response.data.error) {
              // alert(response.data.message);
              // errorMessage.value = response.data.message;
              message.error(response.data.message);
            } else {
              // successMessage.value = response.data.message;
              message.success(response.data.message);
              dataSource.value.filter((item) => key === item.id)[0].xlauditlog=response.data.auditlog;
              dataSource.value.filter((item) => key === item.id)[0].xlstat='ACTIVE';
            }
          });
      }
      delete editableData[key];
    };

    const onCloseNew = () => {
      newVisible.value = false;
      editVisible.value = false;
      uploadVisible.value=false;
      translationFormVisible.value = false;
      form.value = [];
    };
    const onCloseEdit = () => {
      newVisible.value = false;
      editVisible.value = false;
      uploadVisible.value=false;
      translationFormVisible.value = false;
      form.value = [];
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const onCloseTranslationForm = () => {
      translationFormVisible.value = false;
      //this.cacheData = JSON.parse(JSON.stringify(this.dataSource ));
    };

    const handleUploadChange = (info) => {
      if (info.file.status !== "uploading") {
        console.log(info.file);
      }

      if (info.file.status === "done") {
        message.success(`${info.file.name} file uploaded successfully`);
        // console.log(this.file);
      } else if (info.file.status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    };

    const incrementNumber = () => {
      let i = 0;
      return (index) => {
        if (pagination.current === 1) {
          return index++;
        }
        return (i = i + 1);
      };
    };

    const fromCurrentIndex = incrementNumber();

    const pagination = {
      pageSize: 10, // 默认每页显示数量
      position: "top",
      showSizeChanger: true, // 显示可改变每页数量
      pageSizeOptions: ["5", "10", "20", "50", "100"], // 每页数量选项
      showTotal: (total) => lang.value==='cn'?'总共' + ` ${total} 条` + pageTotalLabel.value: 'Total' + ` ${total} ` + pageTotalLabel.value, // 显示总数
      showSizeChange: (current, pageSize) => (this.pageSize = pageSize), // 改变每页数量时更新显示
    };

    const state = reactive({
      rootSubmenuKeys: [
        "global-terms-library",
        "study-dataset-label",
        "study-variable-label",
        "study-variable-logic",
        "study-variable-codelist",
        "study-crf-question",
        "study-ct-drugname",
       
      ],

      selectedRowKeys: [],
      selectedRows: [],
      // selectedRowList: [],

      openKeys: ["1-global-config"],
      groupData: [],
      value: [],
      fetching: false,
      pagination,
      selectedKeys: [],
      options: [],
      searchText: "",
      destroy: true,
      searchedColumn: "",
    });

    const hasSelected = computed(() => state.selectedRowKeys.length > 0);

    const onSelectChange = (selectedRowKeys,selectedRows) => {
      // console.log('selectedRowKeys changed: ', selectedRowKeys);

      state.selectedRows=selectedRows;

      state.selectedRowKeys = selectedRowKeys;

      var selectedTerms='';

      // console.log(state.selectedRows);
      for (var item in state.selectedRows){
        selectedTerms+=state.selectedRows[item].xltest + ""; 
      }

      // console.log(selectedTerms);
      
      // selectedRowKeyList.value=selectedRowKeys;
        // console.log(state.selectedRowKeys);
        
        if (state.selectedRowKeys.length>0){
                // console.log(selectedTermsLength);    
            if (lang.value==='cn'){
              successMessage.value="已选定 " + state.selectedRowKeys.length + " 条术语 (" + selectedTerms.length + " 字符)";
            }
            else{
              successMessage.value=state.selectedRowKeys.length + " rows selected. (" + selectedTerms.length + " characters)";
            }
          // successMessage.value=state.selectedRowKeys.length + " rows selected.";
          // successMessage.value=state.selectedRowKeys;
          // successMessage.value=state.selectedRowKeys.length + " rows selected. \n\n" + state.selectedRowKeys
        }
        else{
          successMessage.value="";
          errorMessage.value="";
          // state.selectedRowKeys.value="";
        }
    };

    const current1 = ref(1);
    const current2 = ref(2);
    const current = ref(1);
    const pageSizeRef = ref(10);
    const pageSizeOptions = ref(["5", "10", "20", "50", "100", "200"]);
    const total = ref(50);

    //for the in-cell edit ;
    const dataSource = ref([]);
    const dataSourceOrigin = ref([]);
    const dataSourceStudy = ref([]);
    const count = computed(() => this.dataSource.length + 1);
    // const editableData = reactive({});

    const onShowSizeChange = (current, pageSize) => {
      // console.log(pageSize);
      pageSizeRef.value = pageSize;
    };

    const onChange = (pageNumber) => {
      console.log("Page: ", pageNumber);
    };

    const onOpenChange = (openKeys) => {
      const latestOpenKey = openKeys.find(
        (key) => state.openKeys.indexOf(key) === -1
      );

      if (state.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
        state.openKeys = openKeys;
      } else {
        state.openKeys = latestOpenKey ? [latestOpenKey] : [];
      }
    };

    const handleSearch = (selectedKeys, confirm, dataIndex) => {
      confirm();
      state.searchText = selectedKeys[0];
      state.searchedColumn = dataIndex;
    };

    const handleReset = clearFilters => {
      clearFilters();
      state.searchText = '';
    };

    return {
      ...toRefs(state),
      formNew,
      onChangePickDate,
      disabledDate,
      pageTotalLabel,
      AddIntoGlobalDict,
      handleSearchInput,
      uniqueCapitalLetterListSelected,
      uniqueCapitalLetterListSelected2,
      userProtocolList,
      userStudyList,      
      globalUserList,
      globalProtocolList,
      globalStudyList,
      lang,
      inputValue,
      letterList,
      statusList,
      userconfig,
      uploadVisible,
      progressValue,
      uploadFile,
      beforeUpload,
      uploadTerms,
      defaultPercent,
      handleUploadChange,
      userProtocolID,
      uploadProtocolID,
      userStudyID,
      uploadStudyID,
      uploadFileWithoutDuplicate,
      uploadDescription,
      uploadComment,
      uploadTermScope,
      uploadTermAccess,
      uploadTermCategory,
      uploadTermType,
      handleUserProtocolSelect,
      // handleUserStudySelect,
      handleProtocolSelect,
      handleStudySelect,
      radioStyle,
      isAdmin,
      getUserRole,
      showUploadModal,
      refreshSelect,
      onSelectChange,
      hasSelected,
      columnTitle,
      selectedRowKeyList,
      // selectedRowList,
      // rowSelection,
      handleSearch,
      handleReset,
      searchText: '',
      searchInput,
      searchedColumn: '',
      // clickedItem,
      strUserName,
      originalTerm,
      originalStatus,
      originalComment,
      currentTerm,
      lblTranslationStatus,
      showDrawerTranslation,
      selectTranslationResult,
      onCloseTranslationForm,
      isLogin,
      translationFormVisible,
      onOpenChange,
      pageSizeOptions,
      current,
      form,
      formTranslationResults,
      dropdownValue,
      // EditableCell,
      editableData,
      cellEdit,
      cellSave,
      // onSubmitEdit,
      currentPage,
      currentPageSize,
      // listAllRecords,
      columnsList,
      dataSource,
      dataSourceOrigin,
      dataSourceStudy,
      Loading,
      handleChange,
      // uploading,
      // handleRemove,
      // beforeUpload,
      // handleUpload,
      headers: {
        authorization: "authorization-text",
      },
      // fileList,
      isLoading,
      isLoadingTranslation,
      isGlobalTerms,
      currentTableName,
      pagination,
      pageSize: pageSizeRef,
      total,
      onShowSizeChange,
      current1,
      current2,
      onChange,
      // onCellEdit,
      // onCellSave,
      onCloseNew,
      onCloseEdit,
      // onSubmit,
      showDrawerNew,
      showDrawerEdit,
      successMessage,
      errorMessage,
      // edit,
      // options,
      // save,
      state,
      count,
      newVisible,
      editVisible,
      collapsed: ref(false),
      selectedKeys: ref(["1"]),
    };
  },

  mounted: function () {

    this.strUserName=localStorage.getItem("username");
    this.lang=localStorage.getItem("country_code").toUpperCase()==='CN'?'cn':'en';

    this.getUserRole();


  },
  // watch:{
  // 	'$route':'getSelectedUsers'
  // },

 computed: {
   uniqueCapitalLetterList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].substring(0,1).toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },

  //  uniqueCapitalLetterListSelected: function () {
  //     var vm = this;
  //     return function (keyname) {
  //       //  var output = [];
  //        var keys   = [];

  //        vm.dataSource.forEach(function (record) {
  //            var key = record[keyname].substring(0,1).toUpperCase();

  //            if (keys.indexOf(key) === -1) {
  //                keys.push(key);
  //               //  output.push(record);
  //            }
  //        });

  //        return keys;
  //     };
  //  },

   uniqueValueList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = [];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname];

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },
   uniqueStudyList: function () {
      var vm = this;
      return function (keyname) {
        //  var output = [];
         var keys   = ["---Show All---"];

         vm.dataSourceOrigin.forEach(function (record) {
             var key = record[keyname].toUpperCase();

             if (keys.indexOf(key) === -1) {
                 keys.push(key);
                //  output.push(record);
             }
         });

         return keys;
      };
   },


},

  watch:{
      columnsList:function(){
        console.log(this.columnsList);
      }

  },

  methods: {

    bodyClick() {
      this.menuVisible = false;
      document.body.removeEventListener("click", this.bodyClick);
      },    

    changeLocale(locale) {
      this.lang = locale;

      localStorage.setItem("country_code",locale);
      // this.columnsList=[];
      var strRootList = new Array();
      strRootList = localStorage.getItem("keytablename").split("-");

      if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "label"
      ) {
        this.columnsList =this.lang==='cn'? this.userconfig.columnVariableLabelCN:this.userconfig.columnVariableLabelEN ;
        this.pageTotalLabel=this.lang==='cn'?"变量标签":"variable labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "dataset" &&
        strRootList[2] == "label"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnDatasetLabelCN:this.userconfig.columnDatasetLabelEN;
        this.pageTotalLabel=this.lang==='cn'?"数据集标签":"dataset labels";
      } else if (
        strRootList[0] == "study" &&
        strRootList[1] == "variable" &&
        strRootList[2] == "logic"
      ) {
        this.columnsList = this.lang==='cn'? this.userconfig.columnVariableLogicCN:this.userconfig.columnVariableLogicEN;
        this.pageTotalLabel=this.lang==='cn'?"变量逻辑":"variable logics";
      } else if (
        strRootList[0] == "global" &&
        strRootList[1] == "terms" &&
        strRootList[2] == "library"
      ) {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      } else {
        this.columnsList = this.lang==='cn'?this.userconfig.columnGlobalTermsCN:this.userconfig.columnGlobalTermsEN;
        this.pageTotalLabel=this.lang==='cn'?"术语":"terms";
      }

        // console.log(locale);
    },

    logout() {
      if (localStorage.getItem("accessToken")) {
        localStorage.removeItem("accessToken");
        this.$router.push({ path: process.env.VUE_APP_baseURL +"login" });
      }
    },

    getAllObservations(searchItemValue) {
      this.isLoading = true;

      var params = new URLSearchParams();
      params.append("action", encodeURIComponent("read"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      params.append("keyname", encodeURIComponent("xltest-xltestcd-xlmodify"));
      params.append("keyvalue", encodeURIComponent(searchItemValue));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-query.php`, params)
        .then((response) => {
          // console.log(response);
          this.clearMessage;
          this.dataSource = response.data.records;
          this.isLoading = false;
          // console.log(this.dataSource);
          //   this.successMessage = response.data.message;
        })
        .catch((error) => {
          // console.log(error);
          this.errorMessage = error.data.message;
        });
    },

    customUploadRequest: function (data) {
      // console.log("submit");
      const formData = new FormData();
      formData.append("file", data.file);
      // formData.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          "terms/nmpa-dict-label-upload.php?action=upload",
          formData
        )
        .then((response) => {
          this.fileList.push({
            uid: "00000001",
            name: data.file.name,
            status: "done",
            response: response,
          });
          // console.log(this.fileList);
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            this.getAllObservations();
          }
        });
    },

    onRowDelete: function (id) {
      this.dataSource.value = this.dataSource.value.filter(
        (item) => item.id !== id
      );
    },

    updateItem: function () {
      var formData = this.toFormData(this.clickedItem);
      params.append("action", "update");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-query.php", formData)
        .then((response) => {
          // console.log(response);
          this.clickedItem = this.editData;
          // this.clickedItem = {};
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            // this.getAllObservations();
          }
        });
    },

    onRowCopy: function (record) {
      // this.visible.value = false;
      var params = new URLSearchParams(record);
      params.append("action", "rowcopy");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("terms/nmpa-dict-new.php", params)
        .then((response) => {
          // console.log(response);
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            //this.getAllObservations();
          }
        });
    },

    onSubmitNew: function () {
      // this.visible.value = false;
      this.isLoading=true;

      // this.formNew.protocolid=this.uploadProtocolID;
      // this.formNew.studyid=this.uploadStudyID;

      var params = new URLSearchParams(this.formNew);
      params.append("action", "create");
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      params.append("userid", localStorage.getItem("userid"));


      let endtc = moment(this.formNew.xlendtc).format("YYYY-MM-DD");
      let dispatchdtc = moment(this.formNew.xldpdtcp).format("YYYY-MM-DD");
      let translationdtc = moment(this.formNew.xltcdtcp).format("YYYY-MM-DD");
      let GPSDatedtc = moment(this.formNew.xldadtc).format("YYYY-MM-DD");
      params.append("xlendtc1", endtc);
      params.append("xldpdtcp1", dispatchdtc);
      params.append("xltcdtcp1", translationdtc);
      params.append("xldadtc1", GPSDatedtc);

      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post("config/nmpa-dict-study-new.php", params)
        .then((response) => {
          // console.log(response);
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
            this.isLoading=false;
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            this.isLoading=false;

            //update the clone table;
            // console.log(this.formNew);

            // console.log(this.dataSource);

            // this.dataSource.push(this.formNew);


            // console.log(response);
            //this.getAllObservations();
          }
        });
    },

    onSubmitEdit: function () {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (this.strUserName);
      
      var params = new URLSearchParams(this.form);
      // console.log(this.clickedItem.xlmodify);
      // console.log(this.form.xlmodify);
      
      // this.originalTerm=this.clickedItem.xlmodify;
      // this.originalStatus=this.clickedItem.xlstat;
      this.originalComment=this.clickedItem.xlcomment;

      params.append("action", "row-update");
      params.append("userid",localStorage.getItem("userid"));
      let endtc = moment(this.form.xlendtc).format("YYYY-MM-DD");
      let dispatchdtc = moment(this.form.xldpdtcp).format("YYYY-MM-DD");
      let translationdtc = moment(this.form.xltcdtcp).format("YYYY-MM-DD");
      let GPSDatedtc = moment(this.form.xldadtc).format("YYYY-MM-DD");
      params.append("xlendtc1", endtc);
      params.append("xldpdtcp1", dispatchdtc);
      params.append("xltcdtcp1", translationdtc);
      params.append("xldadtc1", GPSDatedtc);

      // params.append("original-term", this.originalTerm);
      // params.append("original-comment", this.originalComment);
      // params.append("original-status", this.originalStatus);
      // params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`config/nmpa-dict-study-update.php`, params)
        .then((response) => {
          // console.log( this.editRow);
          // console.log(this.form);
          Object.assign(this.clickedItem, this.form);          

          //additionally added for the updates of original copy;
          Object.assign(
            this.dataSourceOrigin.filter((item) => item.id === this.form.id)[0],
            this.form
          );
          // this.clickedItem = this.editRow;
          if (response.data.error) {
            // console.log(response);
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // console.log(response);
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            this.editVisible = false;
            this.dataSource.filter((item) => this.form.id === item.id)[0].xlauditlog=response.data.auditlog;

            // this.getAllObservations();
            // console.log(this.successMessage);
          }
        });
    },

    uploadFile: function () {

      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      var params = new URLSearchParams();
      // params.append('id', recordKey);
      params.append("userid",localStorage.getItem("userid"));
      params.append("action","upload-csv");

      const { fileList } = this;
      fileList.forEach((file) => {
        params.append("file", file);
      });

      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `util/nmpa-dict-upload-csv.php`,params
        )
        .then((response) => {
          if (response.data.error) {
            this.errorMessage = response.data.message;
          } else {
            this.successMessage = response.data.message;
            // console.log(response.data);
          }
        });
    },

    edit(rowData) {
      let _editData = {};
      Objects.assign(_editData, rowData); //浅拷贝对象
      this.editData = _editData;
    },

    removeItem: function (recordKey, status, auditlog) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData.xlauditlog);
      var params = new URLSearchParams();
      params.append("id", recordKey);
      params.append("action", "delete");
      params.append("userid",localStorage.getItem("userid"));
      params.append("original-status", status);
      params.append("original-auditlog", auditlog);
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-governance.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => item.id !== recordKey
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => item.id !== recordKey
            );

            // this.getAllObservations();
          }
        });
    },
  
    termsGovernance: function (recordKey, action, value, status, auditlog) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("id", recordKey);
      params.append("action", action);

      params.append("userid",localStorage.getItem("userid"));
      params.append("original-status", status);
      params.append("original-auditlog", auditlog);

      params.append("keytablename", encodeURIComponent(this.currentTableName));

      // console.log (params);

      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-governance.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            this.clickedItem.xlstat = value;

            //additionally added for the updates of original copy;
            Object.assign(
              this.dataSourceOrigin.filter((item) => item.id === recordKey)[0],
              this.clickedItem
            );

           this.dataSource.filter((item) => recordKey === item.id)[0].xlauditlog=response.data.auditlog;

            // this.dataSource.value.filter((item) => recordKey === item.id)[0];

            // this.getAllObservations();
          }
        });
    },

    lockAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("lockall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-lockall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='LOCKED';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['APPROVED', 'DELETED', 'LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='LOCKED';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

  unlockAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("unlockall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-unlockall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ACTIVE';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===true ) {
                    record['xlstat']='ACTIVE';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },


  pendingAllItems: function (keylist) {
      // console.log (recordKey);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (formData);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("pendingall"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(`terms/nmpa-dict-pendingall.php`, params)
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            message.error(response.data.message);
          } else {
           
            // this.getAllObservations();

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='PENDING';
                }
       
          });

          this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0  && ['LOCKED'].includes(record['xlstat'].toUpperCase())===false ) {
                    record['xlstat']='PENDING';
                }
       
          });

           message.success(response.data.message);

          }
        });
    },

    handleAPITranslationBatch: function (keylist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      axios
        .post(
          `terms/nmpa-api-translator-batch-v2.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();

            // console.log(response.data.source.length, response.data.target.length)

            //update the status;
            this.dataSource.filter(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0) {
                    record['xlstat']='API';
                }

                for (var j = 0; j < response.data.source.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===response.data.source[j]){
                    record['xlmodify']=response.data.target[j]
                  }
                }                
          });

            this.dataSourceOrigin.forEach(function (record) {
                var key = record['id'];
                // console.log(key, keylist.indexOf(key), keylist)
                if (keylist.indexOf(key) >=0) {
                    record['xlstat']='API';
                }

                for (var j = 0; j < response.data.source.length; j++) {
                  // console.log(record['xltest'], response.data.source[j])
                  if (record['xltest']===response.data.source[j]){
                    record['xlmodify']=response.data.target[j]
                  }
                }                
          });
          }
          this.isLoading=false;
        });
    },

    handleDictionaryTranslationBatch: function (keylist) {
      this.isLoading=true;
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      axios
        .post(
          `terms/nmpa-dict-translator-batch.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();

          }
          this.isLoading=false;
        });
    },

    removeAllItem: function (keylist) {
      // console.log (keylist);
      // var formData = this.toFormData(this.clickedItem);
      // console.log (keylist);
      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(keylist));
      params.append("action", encodeURIComponent("filtereditems"));
      params.append("userid",localStorage.getItem("userid"));
      params.append("keytablename", encodeURIComponent(this.currentTableName));
      // params.append(
      //   "jwt-token",
      //   encodeURIComponent(localStorage.getItem("accessToken"))
      // );
      axios
        .post(
          `terms/nmpa-dict-delete-records.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);

            const dataSource = [...this.dataSource];
            this.dataSource = dataSource.filter(
              (item) => keylist.indexOf(item.id) ===-1
            );

            //additionally added for the updates of the original copy;
            this.dataSourceOrigin = dataSource.filter(
              (item) => keylist.indexOf(item.id)===-1
            );
            // this.getAllObservations();
          }
        });
    },

    selectCurrentItem: function (item) {
      Object.assign(this.editRow, item);
      this.clickedItem = item;
    //   console.log(this.editRow);
      this.form = this.editRow;
    },

    toFormData: function (obj) {
      var form_data = new FormData();
      for (var key in obj) {
        form_data.append(key, obj[key]);
      }
      return form_data;
    },

    clearMessage: function () {
      this.errorMessage = "";
      this.successMessage = "";
    },

    queryTermsByMenuiItems: function (obj) {

      // console.log(obj);

      // console.log(this.isAdmin);

      this.state.selectedRowKeys = [];
      this.isLoading = true;
      this.columnTitle="";

      var params = new URLSearchParams();
      var strList = new Array();
      strList = obj.key.split("-");

      // params.append("level", encodeURIComponent(obj.keyPath.length));
      params.append("userid", localStorage.getItem('userid'));
      params.append("email",localStorage.getItem("email"));
      params.append("keyvalue", strList[3].toLowerCase());

      // params.append("action", encodeURIComponent("read"));

      //retrieve the root key;

      var strRootList = new Array();

      if (
        strList[3].toLowerCase() == "user_list"
      ) 
      {
        this.columnsList =this.lang==='cn'? this.userconfig.columnUserListCN:this.userconfig.columnUserListCN ;
        this.pageTotalLabel=this.lang==='cn'?"用户":"Users";
      } 
      else if ( strList[3].toLowerCase() == "user_log_view"){
        this.columnsList =this.lang==='cn'? this.userconfig.columnUserLogCN:this.userconfig.columnUserLogCN ;
        this.pageTotalLabel=this.lang==='cn'?"日志":"User Log Files";
      }
      else if ( strList[3].toLowerCase() == "study_info")
      {
        this.columnsList = this.lang==='cn'?this.userconfig.columnStudyInfoCN:this.userconfig.columnStudyInfoCN;
        this.pageTotalLabel=this.lang==='cn'?"项目":"Studies";
      }
      else if ( strList[3].toLowerCase() == "study_task")
      {
        this.columnsList = this.lang==='cn'?this.userconfig.columnStudyTaskCN:this.userconfig.columnStudyTaskCN;
        this.pageTotalLabel=this.lang==='cn'?"任务":"Tasks";
      }

      // Add a request interceptor
      axios.interceptors.request.use(function (config) {
          // const token = store.getState().session.token;
          const token=localStorage.getItem("accessToken");
          config.headers.Authorization =  token;
          return config;
      });

      // console.log(this.currentTableName);
      axios({
        method: "post",
        url: "terms/nmpa-dict-query-config.php",
        data: params,
        // headers: {
        //   Authorization: localStorage.getItem("accessToken"),
        // },
      })
        .then((response) => {
          console.log(response);
          // this.inputValue=obj.key;
          this.isLoading = false;

          if (response.data.error) {
            this.errorMessage = response.data.message;
            alert("Your current session has expired, please log in again!");
              if (localStorage.getItem("accessToken")) {
                localStorage.removeItem("accessToken");
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              }else{
                this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
              };
            return;
          }

          this.errorMessage = "";
          this.successMessage = "";
          this.inputValue = "";

          this.dataSourceOrigin = response.data.records;

          this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));

          // this.userProtocolID="";

          // this.letterList=this.uniqueCapitalLetterList('xltest').sort((a, b) => (a > b) ? 1 : -1);
          // this.userProtocolList=this.uniqueStudyList('protocolid').sort((a, b) => (a > b) ? 1 : -1);


          // console.log("debug", this.userProtocolList, localStorage.getItem('protocolid'), this.userProtocolList.includes(localStorage.getItem('protocolid'))===false)

          // if (this.userProtocolID ==='' || (this.userProtocolID !='' && this.userProtocolList.includes(this.userProtocolID)===false)){
          //   this.userProtocolID=this.userProtocolList[0];            
          //   // this.userStudyID=this.userStudyList[0];                            
          // } 

          // if (this.userProtocolList.includes(localStorage.getItem('protocolid'))===false){
          //     this.userProtocolID=this.userProtocolList[0];      
          //      this.handleUserProtocolSelect();    
          //      this.userStudyID=this.userStudyList[0];      
          //      this.handleSearchInput();     
          // }
          // else{
          //     this.userProtocolID=localStorage.getItem('protocolid');
          //     this.userStudyID=localStorage.getItem('studyid');
          //     this.handleSearchInput();   
          // }
          

          // this.handleUserStudySelect();   
          // this.handleSearchInput();
         

          // localStorage.setItem("userProtocolList",this.userProtocolList);

          // console.log("debug", this.userProtocolList, localStorage.getItem('protocolid'), this.userProtocolList.includes(localStorage.getItem('protocolid'))===false)

          // if (this.userProtocolID ==='' || (this.userProtocolID !='' && this.userProtocolList.includes(this.userProtocolID)===false)){
          //   this.userProtocolID=this.userProtocolList[0];            
          //   // this.userStudyID=this.userStudyList[0];                            
          // } 
          
        })
        .catch((error) => {
          console.log(error);
          // this.errorMessage = error.response.data.message;
          this.isLoading = false;

          alert(error.message);
            // if (localStorage.getItem("accessToken")) {
            //   localStorage.removeItem("accessToken");
            //   this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            // }else{
            //   this.$router.push({ path: process.env.VUE_APP_baseURL+"login" });
            // };
          return;
          // alert(error.message);
          // logout();
        });
    },

    clearSelection : function(){
      //reset all row selections;      
      this.errorMessage="";
      this.successMessage="";
      this.state.selectedRowKeys=[];     
      // alert(this.successMessage) 
    },

    selectAllItems : function(){
      //reset all row selections;
      this.state.selectedRowKeys=[];
      this.dataSource.filter((item) => this.state.selectedRowKeys.push(item.id));

      // this.dataSource.filter((item) => this.state.selectedRows.push(item));

      // this.state.selectedRowKeys=[];
      // console.log(this.state.selectedRowKeys);    
      
      var selectedTerms =[];
      this.dataSource.filter((item) => selectedTerms.push(item.xltest));

      var selectedTermsLength=0;

      for (var item in selectedTerms){
        selectedTermsLength+=selectedTerms[item].length; 
      }

      // console.log(selectedTermsLength);    
      if (this.lang==='cn'){
        this.successMessage="已选定 " + this.state.selectedRowKeys.length + " 条术语 (" + selectedTermsLength + " 字符)";
      }
      else{
        this.successMessage=this.state.selectedRowKeys.length + " rows selected. (" + selectedTermsLength + " characters)";
      }
     
      // this.successMessage=this.state.selectedRowKeys;
    },

    exportSelectedItemsAsXLS:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("No items selected, please check!");
              return;
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".xlsx";

            let selectedItems = [
                ['SOURCE', 'TARGET', 'STATUS']
            ] // 表格表头

            // JSON.parse(JSON.stringify(this.state.selectedRowList)).forEach (item => {
            //     let rowData = []
            //     rowData = [
            //         item.xltest,
            //         item.xlmodify,
            //     ]
            //     tableData.push(rowData)
            // })

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            // console.log(tableData)

            let ws = XLSX.utils.aoa_to_sheet(selectedItems);
            ws["!cols"]=[{wpx:400},{wpx:400},{wpx:200}];
            // var s = ws['!ref'];
            // var rows = s.substr(s.length - 1, 1);
            // var columns = ['SOURCE', 'TARGET'];
            // for (var j = 0; j < columns.length; j++) {
            //     for (var i = 1; i <= rows; i++) {
            //         if (i == 1) {
            //             ws[columns[j] + i].s = { //样式  
            //                 font: {
            //                     bold: true,
            //                     italic: false,
            //                     underline: false
            //                 },
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: false
            //                 }
            //             };
            //         }
            //         else {
            //             ws[columns[j] + i].s = { //样式  
            //                 alignment: {
            //                     horizontal: "left",
            //                     vertical: "left",
            //                     wrap_text: true
            //                 }
            //             };
            //         }
            //     }
            // }
            
            let wb = XLSX.utils.book_new()
            XLSX.utils.book_append_sheet(wb, ws, 'LABEL') // 工作簿名称
            XLSX.writeFile(wb, fileName) // 保存的文件名
    },

   exportSelectedItemsAsCSV:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("No items selected, please check!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

          // The download function takes a CSV string, the filename and mimeType as parameters
          // Scroll/look down at the bottom of this snippet to see how download is called
          var exportAsCSV = function(content, fileName, mimeType) {
            var a = document.createElement('a');
            mimeType = mimeType || 'application/octet-stream';

            if (navigator.msSaveBlob) { // IE10
              navigator.msSaveBlob(new Blob([content], {
                type: mimeType
              }), fileName);
            } else if (URL && 'download' in a) { //html5 A[download]
              a.href = URL.createObjectURL(new Blob([content], {
                type: mimeType
              }));
              a.setAttribute('download', fileName);
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
            } else {
              location.href = 'data:application/octet-stream,' + encodeURIComponent(content); // only this mime type is supported
            }
          }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".csv";

            let selectedItems = [
                ['SOURCE', 'TARGET', 'STATUS']
            ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            // Building the CSV from the Data two-dimensional array
            // Each column is separated by ";" and new line "\n" for next row
            var csvContent = '';
            var dataString='';
            selectedItems.forEach(function(infoArray, index) {
              dataString = infoArray.join(';');
              csvContent += index < selectedItems.length ? dataString + '\n' : dataString;
            });
            
            // exportAsCSV(csvContent, 'dowload.csv', 'text/csv;encoding:utf-8');

            exportToCSV(fileName,selectedItems,',');
    },

   exportSelectedItemsAsTAB:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("No items selected, please check!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".txt";

            let selectedItems = [
                ['SOURCE', 'TARGET', 'STATUS']
            ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                    item.xlstat,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            exportToCSV(fileName,selectedItems,'\t');
    },

   exportSelectedItemsAsSAS:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("No items selected, please check!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += " '" + result + "'";
                    }
                    return "    VALUES ( " + finalVal + ')\n';
                };

                var csvFile = 'PROC SQL; \n';
                csvFile += '    CREATE TABLE NMPA_DICT_LABEL \n';
                csvFile += '    (SEQ, SOURCE CHAR(2000), TARGET CHAR(2000)); \n';
                csvFile += 'QUIT; \n\n';

                csvFile += 'PROC SQL; \n';
                csvFile += '    INSERT INTO NMPA_DICT_LABEL \n';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                csvFile += ';\n';
                csvFile += 'QUIT; \n';

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".sas";

            let selectedItems = [ ] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            let seq=1;
            this.dataSourceOrigin.forEach (item => {
                let rowData = [];                
                rowData = [
                    seq,
                    item.xltest,
                    item.xlmodify,
                ];
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.xlstat==='LOCKED'){
                seq=seq+1;
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                };
            })

            exportToCSV(fileName,selectedItems,',');
    },

    exportSelectedItemsByEmail:function(){

        if(this.state.selectedRowKeys==""){
          // alert("No items selected!")
          message.error("No items selected, please check!");
          return;
        }

        function exportToMailBody(rows) {
            var processRow = function (row) {
                var finalVal = '';
                for (var j = 0; j < row.length; j++) {
                    var innerValue = row[j] === null ? '' : row[j].toString();
                    if (row[j] instanceof Date) {
                        innerValue = row[j].toLocaleString();
                    };
                    var result = innerValue; //innerValue.replace(/"/g, '""');
                    finalVal += '<td>'+result+'</td>';
                }
                return finalVal ;
            };

            var mailbody = '';
            for (var i = 0; i < rows.length; i++) {
                if (i>0){
                mailbody += '<tr>' + '<td>' + i+ '</td>' + processRow(rows[i]) + '<td></td>' + '</tr>';
                }
                else{
                   mailbody += '<tr>' + '<td></td>' +processRow(rows[i]) + '<td>' + 'COMMENTS'+ '</td>' + '</tr>';
                }
            }
            return mailbody;
        }

        let selectedItems = [
            ['SOURCE', 'TARGET']
        ] // 表格表头

        // console.log(JSON.stringify(this.state.selectedRowKeys))
        this.dataSourceOrigin.forEach (item => {
            let rowData = []
            rowData = [
                item.xltest,
                item.xlmodify,
            ]
            
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0){
            selectedItems.push(rowData)
            // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
            }
        })
      
      var mailbody=exportToMailBody(selectedItems);

      // console.log(mailbody);

      var params = new URLSearchParams();
      params.append("keylist", encodeURIComponent(this.selectedRowKeys));
      params.append("action", "mailnotice");
      params.append("userid",localStorage.getItem("userid"));
      params.append("username",localStorage.getItem("username"));
      params.append("mailfrom",localStorage.getItem("email"));
      params.append("mailto",localStorage.getItem("email"));
      params.append("mailcc",localStorage.getItem("email"));
      params.append("mailsubject","DO Translation Message: Please help review the terms");
      params.append("mailbody",encodeURIComponent(mailbody));
      params.append("keytablename", encodeURIComponent(this.currentTableName));

      axios
        .post(
          `func/mail.php`,
          params
        )
        .then((response) => {
          // console.log(response);
          // this.clickedItem = {};
          if (response.data.error) {
            // this.errorMessage = response.data.message;
            message.error(response.data.message);
          } else {
            // this.successMessage = response.data.message;
            message.success(response.data.message);
            // this.getAllObservations();
          }
        });

    },

   exportSelectedItemsAsXNDICT:function(){

        // console.log(JSON.parse(JSON.stringify(this.selectedRowList.value)));

            if(this.state.selectedRowKeys==""){
              // alert("No items selected!")
              message.error("No items selected, please check!");
              return;
            }

            function exportToCSV(filename, rows, dlm) {
                var processRow = function (row) {
                    var finalVal = '';
                    for (var j = 0; j < row.length; j++) {
                        var innerValue = row[j] === null ? '' : row[j].toString();
                        if (row[j] instanceof Date) {
                            innerValue = row[j].toLocaleString();
                        };
                        var result = innerValue.replace(/"/g, '""');
                        if (result.search(/("|,|\n)/g) >= 0)
                            result = '"' + result + '"';
                        if (j > 0)
                            finalVal += dlm;
                        finalVal += result;
                    }
                    return finalVal + '\n';
                };

                var csvFile = '';
                for (var i = 0; i < rows.length; i++) {
                    csvFile += processRow(rows[i]);
                }

                var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
                if (navigator.msSaveBlob) { // IE 10+
                    navigator.msSaveBlob(blob, filename);
                } else {
                    var link = document.createElement("a");
                    if (link.download !== undefined) { // feature detection
                        // Browsers that support HTML5 download attribute
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", filename);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            }

            let run_dt = new Date().Format("yyyy-MM-ddThh-mm-ss");
            let fileName=localStorage.getItem("userid") + "_" + run_dt+ ".txt";

            let selectedItems = [] // 表格表头

            // console.log(JSON.stringify(this.state.selectedRowKeys))
            this.dataSourceOrigin.forEach (item => {
                let rowData = []
                rowData = [
                    item.xltest,
                    item.xlmodify,
                ]
                
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                if (JSON.stringify(this.state.selectedRowKeys).indexOf(item.id)>0 && item.xlstat==='LOCKED'){
                selectedItems.push(rowData)
                // console.log(JSON.stringify(this.state.selectedRowKeys).indexOf(item.id))
                }
            })

            exportToCSV(fileName,selectedItems,'\t');
    },

 
    queryTermsByTestName: function (searchItemValue) {
      // this.isLoading = true;
      
      this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));
      if (searchItemValue && this.studyid){
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase()) && item.studyid.toUpperCase()==this.studyid
        );
      }
      else if (searchItemValue){
        this.dataSource = this.dataSource.filter((item) =>
          item.xltest.toLowerCase().startsWith(searchItemValue.toLowerCase())
        );
      }
      else if (this.studyid){
        this.dataSource = this.dataSource.filter((item) =>
          item.studyid.toUpperCase()==this.studyid
        );
      }

      // this.isLoading = false;

      // var params = new URLSearchParams();

      // // params.append("level", encodeURIComponent(obj.keyPath.length));
      // // params.append("level", encodeURIComponent(strList[0]));
      // params.append("keyname", encodeURIComponent("xltest"));
      // params.append("keyvalue", encodeURIComponent(searchItemValue + "%"));
      // params.append("action", encodeURIComponent("read"));
      // params.append("keytablename", encodeURIComponent(this.currentTableName));

      // // console.log(searchItemValue);
      // axios
      //   .post(`terms/nmpa-dict-query.php`, params)
      //   .then((response) => {
      //     // this.inputValue=obj.key;
      //     this.isLoading = false;
      //     this.errorMessage = "";
      //     this.successMessage = "";
      //     this.inputValue = "";
      //     this.dataSource = response.data.records;
      //   })
      //   .catch((error) => {
      //     // console.log(error);
      //     this.errorMessage = error.data.message;
      //   });
    },

    // handleSearchInput() {
    //   this.dataSource = JSON.parse(JSON.stringify(this.dataSourceOrigin));
    //   if (this.userStudyID){
    //     this.dataSource = this.dataSource.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(this.inputValue.toLowerCase()) 
    //         ) && item.studyid.toUpperCase()==this.userStudyID
    //     );
    //   }
    //   else{
    //     this.dataSource = this.dataSource.filter(
    //       (item) =>
    //         (
    //         item.xltest.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xltestcd.toLowerCase().includes(this.inputValue.toLowerCase()) ||
    //         item.xlmodify.toLowerCase().includes(this.inputValue.toLowerCase()) 
    //         ) 
    //     );
    //   }

    //   this.letterList=this.uniqueCapitalLetterListSelected('xltest').sort((a, b) => (a > b) ? 1 : -1);

    //   localStorage.setItem("protocolid", this.userProtocolID);
    //   localStorage.setItem("studyid", this.userStudyID);
    //   localStorage.setItem("searchterm", this.inputValue);

    // },

    handleDropdonwlist() {
      // console.log("dropdownlist");
      // console.log(this.dropdownValue);
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.fileList = [...this.fileList, file];
      return false;
    },
    handleUpload() {
      const { fileList } = this;
      const formData = new FormData();
      fileList.forEach((file) => {
        formData.append("file", file);
      });
      formData.append("action", "upload-csv");
      formData.append("scope", "study");
      formData.append("type", "Labels");
      formData.append("userid",localStorage.getItem("userid"));
      formData.append(
        "keytablename",
        encodeURIComponent(this.currentTableName)
      );

      this.uploading = true;

      // You can use any AJAX library you like
      axios
        .post(
          "util/nmpa-dict-upload-csv.php",
          formData
        )
        .then((response) => {
          this.uploading = false;
          // console.log(response.data);
          // console.log("response : ", response);
          this.handleRemove();
        })
        .catch((e) => {
          console.log(e);
        });
    },

  },
});
</script>

<style>
#app .trigger {
  font-size: 18px;
  line-height: 64px;
  padding: 0 24px;
  cursor: pointer;
  transition: color 0.3s;
}

.highlight {
  background-color: rgb(255, 192, 105);
  padding: 0px;
}

/* .boxW,
.normalB {
  :global {
    .ant-table-thead > tr > th,
    .ant-table-tbody > tr > td {
      padding: 8px 8px !important;
    }
    .ant-table-thead > tr > th {
      background-color: rgb(110, 193, 199);
      font-size: 24px；;
    }
    .ant-table-thead > tr > th:hover {
      background-color: rgb(9, 75, 80);
      font-size: 24px；;
    }
    .ant-table-thead
      > tr
      > th.ant-table-column-has-actions.ant-table-column-has-sorters:hover {
      background: rgb(192, 244, 248);
      font-size: 24px；;
    }
  }
} */

#app .trigger:hover {
  color: #1890ff;
}

#app .logo {
  height: 32px;
  background: rgba(255, 255, 255, 0.3);
  margin: 16px;
}

.site-layout .site-layout-background {
  background: rgb(31, 29, 29);
}

.editable-cell {
  position: relative;}

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding-right: 24px;
  }

  .editable-cell-input-wrapper,
  .editable-cell-text-wrapper {
    padding: 5px 24px 5px 5px;
  }

  .editable-cell .editable-cell-icon,
  .editable-cell-icon-check {
    position: absolute;
    right: 0;
    width: 20px;
    cursor: pointer;
  }

  .editable-cell .editable-cell-icon {
    margin-top: 4px;
    display: none;
  }

  .editable-cell-icon-check {
    line-height: 28px;
  }

  .editable-cell-icon:hover,
  .editable-cell-icon-check:hover {
    color: #108ee9;
  }

  .editable-add-btn {
    margin-bottom: 8px;
  }


.editable-cell:hover .editable-cell-icon {
  display: inline-block;
}

.ant-table-thead > th {
  color: white;
  background: #d46114 !important;
  font-size: 16px;
}

.ant-table-tbody > tr {
  color: rgb(0, 0, 0);
  /* background: #f0f1ee !important; */
  border: 0px !important;
  font-size: 16px;
}

.ant-table-tbody > tr:hover {
  color: rgb(255, 0, 0) !important;
  /* font-weight: 600; */
  /* background: rgb(243, 247, 25) !important; */
  font-size: 16px !important;
}

.ant-upload-list-item {
  position: fixed !important;
  height: 22px;
  /* width: 200px  !important; */
  margin-top: 0px !important;
  font-size: 14px !important;
}
</style>