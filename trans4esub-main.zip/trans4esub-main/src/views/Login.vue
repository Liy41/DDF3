<template>
    <div class="pageAll">
    <div class="login-container">
        <h2 class="login-title">诺译通</h2>       
        <a-form ref="form" :model="form" class="login-form">
        <h2 class="title">NMPA外文数据库中文翻译平台</h2>       
        <a-form-item>
            <a-input class="inputBox" v-model:value.trim="uid" placeholder="5-2-1 ID">
            <template #prefix>
                <user-outlined type="user" />
            </template>       
            <template #suffix>
                <a-tooltip title="Login with your windows 5-2-1 credential">
                <info-circle-outlined style="color: rgba(0, 0, 0, 0.45)" />
                </a-tooltip>
            </template>    
            </a-input>
        </a-form-item>
        <a-form-item>
            
            <a-input-password class="inputBox" v-model:value.trim="upassword" placeholder="5-2-1 Password">
            <template #prefix>
                <LockOutlined type="password" />
            </template>
            </a-input-password>
        </a-form-item>
        <a-form-item>
           <a-button class="submit" type="primary" @click="HandleLogin"><LoginOutlined/>&nbsp;Login</a-button>
              <a-spin tip="Validating your credentials..." :spinning="isLoading">
                <span>
                  <p></p>
                <p class="errorMessage" v-if="errorMessage">{{ errorMessage }}</p>
                </span>
              </a-spin>

        </a-form-item>
        </a-form>
         
         <p class="login-foot" >Designed in 121.605834 E, 31.189467 N</p>
         <p class="login-foot" >Shanghai Campus, Novartis</p>
  </div>
 
  </div>
</template>

<script>
import { ref} from "vue";
// import { computed, defineComponent, reactive, ref, toRefs, watch } from "vue";
import axios from '@/axios';

import {
  // UserOutlined, VideoCameraOutlined,UploadOutlined,
  LoginOutlined,
  LockOutlined,
  UserOutlined,
  InfoCircleOutlined 
} from "@ant-design/icons-vue";
export default {
  
  components:{
      LockOutlined, 
      UserOutlined,
      InfoCircleOutlined,
      LoginOutlined},
  

  setup() {
    const uid = ref("");
    const upassword = ref("");
    const errorMessage=ref("");
    const isLoading = ref(false);
    const loading = ref(false);
    return {
      uid,
      upassword,
      errorMessage,
      isLoading,
      loading
    };
  },

  methods: {

     HandleLoginB() {
      this.isLoading=true;
      this.loading=true;

      var params = new URLSearchParams();
      params.append('uid', encodeURIComponent(this.uid));
      params.append("upassword", encodeURIComponent(this.upassword));
           axios
            .post(`auth/login.php`, params)
            .then((response) => {

              console.log(response.data);

              if (response.data.error) {
                this.isLoading=false;
                this.loading=false;
                alert(response.data.message);
                this.errorMessage = "Authentication Failed";    

              } else {
                // console.log(response.data);

                localStorage.setItem(
                  "accessToken",
                  "Bearer " + response.data.token
                );

                localStorage.setItem(
                  "loginDateTime",
                  Date.now()
                );
                
                localStorage.setItem(
                  "email",
                  response.data.email
                );

                localStorage.setItem(
                  "username",
                  response.data.username
                );

                localStorage.setItem(
                  "fullname",
                  response.data.username
                );

                localStorage.setItem(
                  "userid",
                  this.uid
                );

                if (localStorage.getItem('country_code')==null || localStorage.getItem('country_code')==''){
                  localStorage.setItem("country_code",'CN');
                };
                var redirect = decodeURIComponent(
                  this.$route.query.redirect || process.env.VUE_APP_baseURL
                );
                //console.log(this.$router.currentRoute.value.fullPath);
                this.$router.push({ path: redirect });

              }
            }).catch((error) => {
              this.errorMessage = "Authentication Failed";
            });
    },

    HandleLogin() {
      this.isLoading=true;
      this.loading=true;

      var params = new URLSearchParams();
      params.append('uid', encodeURIComponent(this.uid));
      params.append("upassword", encodeURIComponent(this.upassword));

      params.append('username', encodeURIComponent(this.uid));
      params.append("password", encodeURIComponent(this.upassword));

      // console.log("check api env"+ process.env.VUE_APP_LDAP);
      
      axios
        .post(`auth/login.php`, params)
        .then((response) => {
          if (response.data.error) {

            axios
                .get(process.env.VUE_APP_LDAP,
            { headers: { "Content-Type": "application/json", "username":this.uid,"password":this.upassword } })
            .then((response) => {

              // console.log("ok"+response);

              if (response.data.error) {
                this.errorMessage = "Authentication Failed";    
                this.isLoading=false;
                this.loading=false;
              } else {
                // console.log(response.data);
                localStorage.setItem(
                "username",
                response.data.fullname
                );
                localStorage.setItem(
                "fullname",
                response.data.fullname
                );
                localStorage.setItem(
                "email",
                response.data.email
                );
                localStorage.setItem(
                "country_code",
                response.data.country_code
                );
                localStorage.setItem(
                "userid",
                this.uid
                );

                params.append("username", response.data.fullname!=null?response.data.fullname:this.uid);
                params.append("email", response.data.email!=null?response.data.email:this.uid + "@novartis.com");
                params.append("country", response.data.country_name!=null?response.data.country_name:"NA");  
                params.append("country_name", response.data.country_name!=null?response.data.country_name:"NA");  
                params.append("country_code", response.data.country_code!=null?response.data.country_code:"NA");  
                params.append("division", response.data.country_code!=null?response.data.country_code:"NA");  
                params.append("department", response.data.dept!=null?response.data.dept:"NA"); 
                params.append("function", response.data.dept_function!=null?response.data.dept_function:"NA"); 
                params.append("group_lev1", response.data.group_lev1!=null?response.data.group_lev1:"NA"); 
                params.append("group_lev2", response.data.group_lev2!=null?response.data.group_lev2:"NA");       
                params.append("phone", response.data.phone!=null?response.data.phone:"NA");   
                params.append("title", response.data.title!=null?response.data.title:"NA");     
                params.append("employeeid", response.data.employee_id!=null?response.data.employee_id:"NA");  
                params.append("hire_dtc", response.data.hire_date!=null?response.data.hire_date:"NA");  
                params.append("opmid", response.data.supervisor!=null?response.data.supervisor:"NA");
                params.append("address", response.data.address!=null?response.data.address:"NA");
                params.append("cost_center", response.data.cost_center!=null?response.data.cost_center:"NA");
                params.append("uuid", response.data.supervisor!=null?response.data.supervisor:"NA");
9
                //generate the token if login successfully
                axios
                .post(`auth/login-nvs.php`, params)
                .then((response) => {
                    if (response.data.error) {
                    this.isLoading=false;
                    this.errorMessage="Token generation failed";
                    }else{            
                    this.isLoading=false;
                    this.loading=false;

                    // console.log(response.data);

                    localStorage.setItem(
                        "accessToken",
                        "Bearer " + response.data.token
                    );

                    localStorage.setItem(
                        "loginDateTime",
                        Date.now()
                    );

                    localStorage.setItem(
                      "email",
                      response.data.email
                    );

                    localStorage.setItem(
                      "username",
                      response.data.username
                    );

                    localStorage.setItem(
                      "fullname",
                      response.data.username
                    );

                    localStorage.setItem(
                      "userid",
                      this.uid
                    );

                    // console.log(this.$router);

                    var redirect = decodeURIComponent(
                        localStorage.getItem("currentHREF") || process.env.VUE_APP_baseURL
                    );
                    // console.log(this.$router.currentRoute.value.fullPath);
                    this.$router.push({ path: redirect });

                    }}
                    )       

                }
                }).catch((error) => {
                        console.log("failed:"+error);
                        this.errorMessage = "Authentication Failed";
                        this.isLoading=false;
                        this.loading=false;
                });

            } else {
                this.isLoading=false;
                this.loading=false;
                localStorage.setItem(
                  "accessToken",
                  "Bearer " + response.data.token
                );

                localStorage.setItem(
                  "loginDateTime",
                  Date.now()
                );
                
                localStorage.setItem(
                  "email",
                  response.data.email
                );

                localStorage.setItem(
                  "username",
                  response.data.username
                );

                localStorage.setItem(
                  "fullname",
                  response.data.username
                );

                localStorage.setItem(
                  "userid",
                  this.uid
                );

                if (localStorage.getItem('country_code')==null || localStorage.getItem('country_code')==''){
                  localStorage.setItem("country_code",'CN');
                };
                var redirect = decodeURIComponent(
                  this.$route.query.redirect || process.env.VUE_APP_baseURL
                );
                //console.log(this.$router.currentRoute.value.fullPath);
                this.$router.push({ path: redirect });    
  
          }
        }
        ).catch((error) => {
            // console.log(error);
            alert("Authorization failed");
            this.isLoading=false;
            this.loading=false;
        });
    },

    
  },
};
</script>


<style >

.login-form {
  width: 565px;
  height: 372px;
  margin: 0 auto;
  /* background: url("../assets/houTaiKuang.png"); */
  /* background: url('../assets/galaxy02.jpg') center center fixed no-repeat; */
  padding: 40px 110px;
}

/* 背景 */
.login-container {
  position: absolute;
  width: 100%;
  height: 100%;
  /* background: url('../assets/galaxy02.jpg') center center fixed no-repeat; */
  /* background: url("../assets/houTaiBg.png"); */
}

/* Log */
.login-title {
  color: rgba(155, 221, 188, 0.5);
  text-align: center;
  font-weight: bold;
  margin: 70px 0;
  font-size: 36px;
  font-family: Microsoft Yahei;
}

.login-foot {
  color: rgb(194, 255, 245,0.50);
  text-align: center;
  padding: 500px,0,120px,0;
  font-size: 18px;
  /* font-family: Microsoft Yahei; */
}

/* 登陆按钮 */
.submit{
  width: 100%;
  height: 45px;
  font-size: 16px;
}
/* 用户登陆标题 */
.title{
  margin-bottom: 50px;
  color: rgba(14, 211, 63, 0.65);
  font-weight: 700;
  font-size: 24px;
  text-align: center;
  font-family: Microsoft Yahei;
}
/* 输入框 */
.inputBox{
  height: 55px;
  font-size: 24px;
}
/* 输入框内左边距50px */
.ant-input-affix-wrapper .ant-input:not(:first-child) {
    padding-left: 15px;
}

p.errorMessage {
    background: #ffbaba;
    padding: 10px;
    text-align: center;
    font-weight: bold;
    border-left: 5px solid #f00;
}


.card {
   padding: 20px;
}

.login-page {
   align-items: center;
   display: flex;
   height: 100vh;
   }

.pageAll {
  width: 100vw;
  height: 100vh;
  background: url('../assets/galaxy03.jpg') center center fixed no-repeat;
  background-size: cover;
  background-color: black;
  display: flex;
  justify-content: center;
  align-items: center;
}

.loginForm {
  font-weight: bold;
  color: red;
  font-size: 24px;
  margin: 0px 0vw 30vh 0;
}

.logTitle {
  font-weight: bold;
  color: rgb(255, 255, 255);
  text-align: center;
  font-size: 18px;
}

.loginCard {
  border: none;
  border-color: #459bf0;
  box-shadow: -1px 1px 0px #a0a6ac;
  background-color: #3b5268;
  background: linear-gradient(to right bottom, #c3def5, hsl(209, 91%, 71%));
  border-radius: 8px;
  width: 380px;
  height: 200px;
  margin: 50px 0vw 5px 0;
}

.inputArea {
  margin: 5px 0 0px 0;
  padding: 5px 5px 5px 5px;
}
</style>


