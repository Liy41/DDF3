import axios from 'axios';

// Add a request interceptor
axios.interceptors.request.use(function (config) {
    // const token = store.getState().session.token;
    const token=localStorage.getItem("accessToken");
    config.headers.Authorization =  token;

    return config;
});

// Add a response interceptor
axios.interceptors.response.use(
    (response) => {
      return response;
    },
    (error) => {
      alert("Respomse interceptor" + error.response.status);
      if (error.response) {
        if (error.response.status === 401 ) {
        //   this.errorMessage = error.response.data.message;
          alert(error.response.data.message); //console.log(error.response);
          console.log(this.$router.currentRoute.value.fullPath);
          // this.$router.push({ path: this.$router.currentRoute.value.fullPath || "/login" });
        }
      }
    }
  );

export default axios.create({
    // baseURL: "http://nmpa-server.statwb.eu.novartis.net/api"
    baseURL: "https://dos-nmpa-api.apps.busdevocp.novartis.net"
    // baseURL: "https://data42.cn/api"
    // baseURL: "http://nmpa-api.statwb.eu.novartis.net"

})

// axios.defaults.headers.common['Authorization'] = localStorage.getItem("accessToken")?localStorage.getItem("accessToken"):null;