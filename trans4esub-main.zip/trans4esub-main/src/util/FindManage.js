// 查询组件管理
const findManage = () => {
    // 渲染查询条件，内容不会变，就不监控了
    const findWhere = {
      401: ' = "{k}"',
      402: ' <> "{k}"',
      403: ' like "%{k}%"',
      404: ' not like "%{k}%"',
      405: ' like "{k}%"',
      406: ' like "%{k}"',
      411: ' ={k}',
      412: ' <>{k}',
      413: ' >{k}',
      414: ' >={k}',
      415: ' <{k}',
      416: ' <={k}',
      421: ' ="{k}"',
      431: ' between {k1} and {k2}',
      432: ' between "{k1}" and "{k2}" ',
      433: ' in ({k})'
    }
    // 加载meta信息，json格式
    const json = require('../assets/demodata.json')
    const findMeta = ref({}) // 查询表单的meta信息
    const findItem = ref({}) // 表单需要的meta信息
    const modelValue = ref({}) // 放数据的model
    const quickFindKey = ref({}) // 存放快捷查询的key
    const findTable = ref([]) // 二维数组存放meta的ID
    // 把查询里的字段，变成多行多列的分布，二维数组
    const metaToTable = () => {
      var tdCount = 0
      var td = []
      findTable.value = []
      for (var index in findMeta.value.allFind) { // 遍历设定的meta的key的数组
        var key = findMeta.value.allFind[index]
        var meta = findItem.value[key]
        td.push(key)
        tdCount += 1 + meta.tdCount
        if (tdCount >= findMeta.value.colCount * 2) {
          findTable.value.push(td)
          td = []
          tdCount = 0
        }
      }
      if (td.length > 0) {
        findTable.value.push(td)
      }
    }
    // 更换个性化查询方案
    const changeQuickFind = (e) => {
      quickFindKey.value = findMeta.value.customer[e.key].keys
    }
    // 切换其他查询模块
    const myClick = (key) => {
      // 更换表单的meta
      findMeta.value = json[key].findMeta
      findItem.value = json[key].findItem
      // 加载快捷查询
      quickFindKey.value = json[key].findMeta.quickFind
      // 初始化
      modelValue.value = {}
      // 创建model
      modelValue.value = {}
      for (var k in findItem.value) {
        var item = findItem.value[k]
        modelValue.value[item.colName] = ''
      }
  
      metaToTable()
    }
  
    // 抽屉的事件
    const findVisible = ref(false)
    const moreFindShow = (isShow) => {
      findVisible.value = isShow
    }
    return {
      modelValue,
      findMeta,
      findItem,
      quickFindKey,
      findWhere,
      findTable,
      myClick,
      findVisible,
      moreFindShow
    }
  }